if(!isObject(VerGroup))
	new SimGroup(VerGroup);

function clearBlocklandVersions() {
	deleteVariables("$Launcher::Versions::*");
	while(VerGroup.getCount() != 0)
		VerGroup.getObject(0).delete();
	VerGroup.delete();
	new SimGroup(VerGroup);
}

function getDifferenceTags(%oldVer, %newVer)
{
	%oldVer = strReplace(%oldVer, ".", " ");
	%newVer = strReplace(%newVer, ".", " ");
	%oldVer = stripChars(%oldVer, stripChars(%oldVer, "0123456789 "));
	%newVer = stripChars(%newVer, stripChars(%newVer, "0123456789 "));
	%tags   = "same-version";
	
	// Compare major version
	if (getWord(%newVer, 0) > getWord(%oldVer, 0))
		return "outdated-version required-update";
	else if (getWord(%newVer, 0) < getWord(%oldVer, 0))
		return "newer-version";
	
	// Compare minor version
	if (getWord(%newVer, 1) > getWord(%oldVer, 1))
		return "outdated-version";
	else if (getWord(%newVer, 1) < getWord(%oldVer, 1))
		return "newer-version";
	
	return %tags;
}

function addInstall(%ver, %name, %path, %preferred, %patch)
{
	%so = new SimObject();
	
	%so.cName        = %name;
	%so.version      = %ver;
	%so.path         = %path;
	%so.installed    = !IsObject(versionManagerGui) ? 2 : (versionManagerGui.isInDownloadQueue(%ver) ? 1 : 2);
	%so.preferred    = %preferred;
	%so.patchVersion = %patch $= "" ? "1.0" : %patch;
	
	// Setup things determined with information gotten from the server
	%so.newPatchVersion = %patch;
	%so.updateRequired  = false;
	%so.updateAvailable = false;
	%so.updating        = getFieldPos($Launcher::Installing, %so.path) != -1;
	
	VerGroup.add(%so);
	VerGroup.object[%ver, -1 + VerGroup.count[%ver]++] = %so;
	VerGroup.pathLookup[%so.path]                      = %so;
	
	if (%so.preferred)
		VerGroup.preferredVersionSO[%ver] = %so;
	
	return %so;
}

function getInstallation(%ver)
{
	for(%i=0;%i<VerGroup.getCount();%i++)
	{
		%o = VerGroup.getObject(%i);
		if(%o.version !$= %ver) continue;
		return %o;
	}
	
	return -1;
}

function getPreferredInstallation(%ver)
{
	for(%i=0;%i<VerGroup.getCount();%i++)
	{
		%o = VerGroup.getObject(%i);
		if(%o.version !$= %ver || !%o.preferred)
			continue;
		return %o;
	}
	
	return -1;
}

function getBlocklandName(%ver)
{
	if (%ver $= "RTB")
		return "Return To Blockland";
	
	if (stripChars(%ver, "0123456789.") !$= "")
		return %ver;
	
	return "Blockland v" @ %ver;
}

function getBlocklandExe(%ver)
{
	if(%ver $= "20")
		return "Blocklandv20.exe";
	if(%ver $= "20-normal")
		return "Blockland.exe";
	
	return "Blockland.exe";
}

function getFileCountFromFolder(%path, %name)
{
	%count = 0;
	for (%file=getFirstDirectoryFile(%path);%file !$= "";%file=getNextDirectoryFile())
	{
		if (fileName(%file) !$= %name)
			continue;
		
		%count++;
	}
	return %count;
}

function getFancyByteString(%num)
{
	%suffix = "B";
	
	if(%num >= 1024)
	{
		%num /= 1024;
		%suffix = "KB";
	}
	if(%num >= 1024)
	{
		%num /= 1024;
		%suffix = "MB";
	}
	if(%num >= 1024)
	{
		%num /= 1024;
		%suffix = "GB";
	}
	
	return mFloatLength(%num, 2) SPC %suffix;
}

function fetchScreenshots() {
	%count = 0;
	launcherGui.clearSlides();
	
	for(%i=0;%i<VerGroup.getCount();%i++) {
		%o = VerGroup.getObject(%i);
		launcherGui.addDirectory(%o.path @ "screenshots\\");
	}
		
	for(%i=0;%i<$Launcher::Versions::Count;%i++) {
		%path = $Launcher::Versions::Ver[%ver = firstWord($Launcher::Versions::Table[%i])];
		%inst = $Launcher::Versions::Installed[%ver];
		
		if(%inst != 2) continue;
		
		launcherGui.addDirectory(%path @ "screenshots\\");
	}
	
	if(%count == 0) {
		// Failsafe
		launcherGui.addSlide("./launcher/ui/DefaultBackground.jpg");
	}
}

function fetchVersionListing()
{
	if (!$QuickLaunch)
	{
		versionManagerGui.findObjectByInternalName("RefreshBtn", true).setActive(0);
		versionManagerGui.findObjectByInternalName("VersionList", true).clear();
		updateIcon.setVisible(false);
		
		$Launcher::VersMgr::Selected = "";
		versionManagerGui.updateVersionInformation();
	}
	
	clearBlocklandVersions();
	
	// Get local installations first
	if(isFile(%verFile = ("launcher/verInfo.cfg")))
	{
		%SO = new FileObject();
		%SO.openForRead(%verFile);
		
		%count = 0;
		while(!%SO.isEOF())
		{
			%line       = %SO.readLine();
			%version    = getField(%line, 0);
			%verPath    = getField(%line, 1);
			%customName = getField(%line, 2);
			%preferred  = getField(%line, 3);
			%patch      = getField(%line, 4);
			
			// Sanity check
			if(getSubStr(%verPath, strLen(%verPath) - 1, 1) !$= "/" && getSubStr(%verPath, strLen(%verPath) - 1, 1) !$= "\\")
			{
				warn("Please don't mess with the verInfo.cfg file directly...");
				%verPath = %verPath @ "\\";
			}
			
			if(!isFile(%verPath @ getBlocklandExe(%version)))
			{
				error(getBlocklandName(%version) SPC "does not have a Blockland.exe -- probably deleted");
				continue;
			}
			
			if(!%got[%version])
			{
				%got[%version] = 1;
				$Launcher::Versions::Table[-1 + $Launcher::Versions::Count++] = %version;
			}
			
			%newSO = addInstall(%version, %customName, %verPath, %preferred, %patch);
			%newSO.listIndex = $Launcher::Versions::Count - 1;
			
			if (!$QuickLaunch)
			{
				%count++;
				%list = versionManagerGui.findObjectByInternalName("VersionList", true);
				%list.addRow(%newSO.getId(), (%newSO.cName $= "" ? getBlocklandName(%version) : "[" @ %newSO.version @ "]" SPC %newSO.cName) @ (%newSO.preferred ? "*" : "") SPC "(installed)" TAB %version TAB %newSO.getId());
			}
		}
		
		%SO.close();
		%SO.delete();
		
		if (!$QuickLaunch)
			fetchScreenshots();
	}
	else
	{
		if (!$QuickLaunch)
			launcherGui.addSlide("./launcher/ui/DefaultBackground.jpg");
	}
	
	// Now get a list from the B4v21 website
	if(isObject(%o = VersionsFetcherTCP))
		%o.delete();

	$QuickLaunchFail = "DOES_NOT_EXIST";
	if ($QuickLaunch)
		echo("QUICKLAUNCH: Checking for updates for " @ getBlocklandName($QuickLaunchVersion));
	
	%o      = new TCPObject(VersionsFetcherTCP);
	%o.site = "b4v21.block.land";
	%o.port = 80;
	%o.cmd  = "GET /api/newLauncher.php HTTP/1.1\r\nUser-Agent: B4v21Launcher-v" @ getLauncherVersion() @ "\r\nHost: " @ %o.site @ "\r\nConnection: close\r\n\r\n";
	%o.connect(%o.site @ ":" @ %o.port);
}

function VersionsFetcherTCP::onConnectFailed(%this)
{
	if ($QuickLaunch)
	{
		if (VerGroup.count[$QuickLaunchVersion] $= "" || VerGroup.count[$QuickLaunchVersion] == 0)
		{
			$QuickLaunchFail = "NOT_INSTALLED_DISCONNECTED";
			onQuickLaunchFail();
		}
		else
			onQuickLaunchSuccess();
	}
}

function VersionsFetcherTCP::onDNSFailed(%this)
{
	if ($QuickLaunch)
	{
		if (VerGroup.count[$QuickLaunchVersion] $= "" || VerGroup.count[$QuickLaunchVersion] == 0)
		{
			$QuickLaunchFail = "NOT_INSTALLED_DISCONNECTED";
			onQuickLaunchFail();
		}
		else
			onQuickLaunchSuccess();
	}
}

function VersionsFetcherTCP::onDisconnect(%this)
{
	if ($QuickLaunch)
	{
		echo($QuickLaunchFail);
		if ($QuickLaunchFail !$= "")
		{
			onQuickLaunchFail();
			return;
		}
			
		onQuickLaunchSuccess();
		return;
	}
	
	if (!$QuickLaunch && $Pref::Launcher::AutoUpdate)
	{
		for(%i=0;%i<VerGroup.getCount();%i++)
		{
			%so = VerGroup.getObject(%i);
			if(%so.updateAvailable)
				versionManagerGui.downloadVersion(%so.version, %so);
		}
	}

	versionManagerGui.findObjectByInternalName("RefreshBtn", true).setActive(1);
}

function VersionsFetcherTCP::onConnected(%this) {
	%this.send(%this.cmd);
}

function VersionsFetcherTCP::onLine(%this, %line)
{
	%act  = firstWord(%line);
	%line = restWords(%line);
	
	switch$(%act)
	{
		case "VER":
			%ver = getField(%line, 0);
			if ($QuickLaunch && $QuickLaunchFail $= "LAUNCHER_OUT_OF_DATE")
				return;
			
			$Launcher::Versions::Ver[%ver] 		= removeField(%line, 0);
			$Launcher::Versions::PatchVersion[%ver] = getField(%line, 4);
			
			if (%ver $= $QuickLaunchVersion)
			{
				$QuickLaunchHost = getField(%line, 1);
				$QuickLaunchPort = getField(%line, 2);
				$QuickLaunchPath = getField(%line, 3);
			}
			
			if (VerGroup.count[%ver] $= "" || VerGroup.count[%ver] == 0)
			{
				if(!$QuickLaunch)
				{
					$Launcher::Versions::Table[-1 + $Launcher::Versions::Count++] = %ver SPC removeField(%line, 0);
					$Launcher::Versions::Ver[%ver] 				      = removeField(%line, 0);
					$Launcher::Versions::PatchVersion[%ver]                       = getField(%line, 4);
					$Launcher::Versions::Installed[%ver]			      = 0;
					$Launcher::Versions::RowID[%ver, 0]                           = $Launcher::Versions::Count - 1;
				}
				
				if (%ver $= "21")
					return;

				if ($QuickLaunch && DoesQuickLaunchMatch(%ver) && $QuickLaunchFail $= "DOES_NOT_EXIST")
					$QuickLaunchFail = "";
				
				if (!$QuickLaunch)
					versionManagerGui.findObjectByInternalName("VersionList", true).addRow($Launcher::Versions::Count - 1, getBlocklandName(%ver) @ (versionManagerGui.isInDownloadQueue(%ver) ? " (Installing)" : "") TAB %ver);
				else if (DoesQuickLaunchMatch(%ver) && getField(%line, 4) $= "SPECIAL")
					$QuickLaunchFail = "SPECIAL";
				else if (DoesQuickLaunchMatch(%ver))
				{
					$QuickLaunchFail = "NOT_INSTALLED";
				}
			}
			else
			{
				for (%i = 0; %i < VerGroup.count[%ver]; %i++)
				{
					if (!isObject(%so = VerGroup.object[%ver, %i]))
						continue;
					
					// Update the SO
					%so.newPatchVersion = getField(%line, 4);
					
					// Determine fields
					%tags               = getDifferenceTags(%so.patchVersion, %so.newPatchVersion);
					%so.updateAvailable = (getWordPos(%tags, "outdated-version") != -1);
					%so.updateRequired  = (getWordPos(%tags, "required-update") != -1);
					
					if (!$QuickLaunch && %so.updateAvailable)
					{
						%list = versionManagerGui.findObjectByInternalName("VersionList", true);
						%list.setRowById(%so.getId(), "(!!!) " @ %list.getRowTextById(%so.getId()));
						
						if (!updateIcon.isVisible())
							updateIcon.setVisible(true);
					}
					
					if ($QuickLaunch && DoesQuickLaunchMatch(%ver, %so))
					{
						if ($QuickLaunchFail $= "DOES_NOT_EXIST")
							$QuickLaunchFail = "";
						
						if (%so.newPatchVersion $= "SPECIAL")
							$QuickLaunchFail = "SPECIAL";
						
						$QuickLaunchSO      = %so;
						$QuickLaunchName    = %so.cName;
						$QuickLaunchVersion = %ver;
						if (%so.updateRequired)
							$QuickLaunchFail = "UPDATE_REQUIRED";
						else if (%so.updateAvailable)
							$QuickLaunchFail = "UPDATE_AVAILABLE";
					}
				}
			}
		case "LAUNCHER_VERSION":
			%ourVer = getLauncherVersion();
			%gotVer = getField(%line, 0);
			
			%ourVer = strReplace(stripChars(%ourVer, stripChars(%ourVer, "0123456789.")), ".", " ");
			%gotVer = strReplace(stripChars(%gotVer, stripChars(%gotVer, "0123456789.")), ".", " ");
			
			%ourVer = (getWord(%ourVer, 0) * 100) + (getWord(%ourVer, 1) * 10) + getWord(%ourVer, 2);
			%gotVer = (getWord(%gotVer, 0) * 100) + (getWord(%gotVer, 1) * 10) + getWord(%gotVer, 2);
			
			if(%gotVer > %ourVer)
			{
				if (!$QuickLaunch)
					messageBoxOk("UPDATE - B4v21 Launcher", "There is a new version of B4v21 Launcher!\nClick OK to install it.", "launchLauncherUpdater();");
				else $QuickLaunchFail = "LAUNCHER_OUT_OF_DATE";
				
				$NewLauncherHost = getField(%line, 1);
				$NewLauncherPort = getField(%line, 2);
				$NewLauncherPath = getField(%line, 3);
				
				return;
			}
	}
}

function versionManagerGui::onWake(%this)
{
	%window = %this.findObjectByInternalName("VerWindow", true);
	%window.setPosition((getWord(getRes(), 0) / 2) - (getWord(%window.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%window.getExtent(), 1) / 2));
	
	$Launcher::VersMgr::Selected = "";
	%this.updateVersionInformation();
	%this.findObjectByInternalName("TabBook", true).selectPage(0);
}

function versionManagerGui::updateVersionInformation(%this)
{
	%sel = $Launcher::VersMgr::Selected;
	
	// Install path
	%infoTxt = "<font:Arial Bold:16>Installation Path:<font:Arial:16><br>";
	%infoTxt = %infoTxt TAB "N/A"; // Field 1
	%infoTxt = %infoTxt TAB "<br><font:Arial Bold:16>Add-On Count:<font:Arial:16><br>";
	%infoTxt = %infoTxt TAB "N/A"; // Field 3
	%infoTxt = %infoTxt TAB "<br><font:Arial Bold:16>Screenshot Count:<font:Arial:16><br>";
	%infoTxt = %infoTxt TAB "N/A"; // Field 5
	
	if (%sel $= "" || %sel < 0 || %sel > VerList.rowCount())
	{
		%this.findObjectByInternalName("InfoHeader", true).setText("<font:Impact:32>Select something!<font:Impact:18><br>");
		%this.findObjectByInternalName("LaunchBtn", true).setActive(0);
		%this.findObjectByInternalName("LaunchDediLanBtn", true).setActive(0);
		%this.findObjectByInternalName("LaunchDediBtn", true).setActive(0);
		%this.findObjectByInternalName("GameInstallBtn", true).setActive(0);
		%this.findObjectByInternalName("GameInstallBtn", true).setText("Install");
		%this.findObjectByInternalName("GameInstallBtn", true).color = "255 255 255 255";
		%this.findObjectByInternalName("TabBook", true).selectPage(0);
		%this.findObjectByInternalName("InfoText", true).setText(strReplace(%infoTxt, "\t", ""));
		%this.findObjectByInternalName("RenameBtn", true).setActive(0);
		%this.findObjectByInternalName("SetPreferBtn", true).setActive(0);
		return;
	}
	
	%SO         = $Launcher::VersMgr::SelectedSO;
	%cVer       = (%iObj = isObject(%SO)) ? %SO.version : firstWord(%data = $Launcher::Versions::Table[%sel]);
	%cPath      = %iObj ? %SO.path : restWords(%data);
	%installed  = %iObj ? %SO.installed : (%this.isInDownloadQueue(firstWord(%cVer)) ? 1 : $Launcher::Versions::Installed[%cVer]);
	%installing = $Launcher::VersionInstalling.version $= %cVer;
	%realInstl  = %iObj ? %SO.installed : $Launcher::Versions::Installed[%cVer];
	%pVer       = %iObj ? %SO.patchVersion : $Launcher::Versions::PatchVersion[%cVer];
	%updating   = %iObj ? %SO.updating : false;

	if (%iObj && !%installing && !%updating && (%SO.updateRequired || %SO.updateAvailable))
	{
		%needsUpdate = true;
		%updateTxt   = " | <color:" @ (%SO.updateRequired ? "ff6400" : "ffaf00") @ ">(Update " @ (%SO.updateRequired ? "Required" : "Available") @ "!)";
	}
	
	// Build the InfoHeader string
	%infoHStr = "<font:Impact:32>" @ (%SO.cName !$= "" ? getBlocklandName(%cVer) @ " - \"" @ %SO.cName @ "\"" : getBlocklandName(%cVer));
	%infoHStr = %infoHStr @ "<font:Impact:18><br>(";
	if (%installing)
	{
		%infoHStr = %infoHStr @ "Installing...";
	}
	else
	{
		if (%updating)
		{
			%infoHStr = %infoHStr @ "Updating...";
		}
		else if (%installed)
		{
			%infoHStr = %infoHStr @ "Patch v" @ %pVer @ " Installed";
		}
		else
		{
			%infoHStr = %infoHStr @ "Not Installed";
		}
	}
	
	%infoHStr = %infoHStr @ ")" @ %updateTxt;
	
	%this.findObjectByInternalName("InfoHeader", true).setText(%infoHStr);
	%this.findObjectByInternalName("LaunchBtn", true).setActive(!%updating && %installed == 2);
	%this.findObjectByInternalName("LaunchDediLanBtn", true).setActive(!%updating && %installed == 2);
	%this.findObjectByInternalName("LaunchDediBtn", true).setActive(!%updating && %installed == 2);
	%this.findObjectByInternalName("RenameBtn", true).setActive(!%updating && %installed == 2);
	%this.findObjectByInternalName("SetPreferBtn", true).setActive(!%updating && %installed == 2 && !%SO.preferred);
	
	%GIB = %this.findObjectByInternalName("GameInstallBtn", true);
	%GIB.setText(%needsUpdate ? "Update" : (%installed == 2 ? "De-associate" : (%installed == 1 ? "Extract" : "Install")));
	%GIB.setActive(!%updating && (!%this.isInDownloadQueue(%cVer)) || (%realInstl == 2));
	
	%GIB.color = (%needsUpdate ? "255 199 94 255" : "255 255 255 255");
	
	// Replace infoTxt with real information
	%infoTxt = setField(%infoTxt, 1, (!%installed ? "<color:CC0000>Not Installed<color:000000>" : (%installed == 1 ? "<color:888800>Installing...<color:000000>" : %cPath)));
	%infoTxt = setField(%infoTxt, 3, (%installed != 2 ? "N/A" : getDirectoryFileCount(strReplace(%cPath @ "Add-Ons\\", "\\", "/"), 0) + getFileCountFromFolder(strReplace(%cPath @ "Add-Ons\\", "\\", "/"), "description.txt")));
	%infoTxt = setField(%infoTxt, 5, (%installed != 2? "N/A" : getDirectoryFileCount(strReplace(%cPath @ "screenshots\\", "\\", "/"))));
	
	%this.findObjectByInternalName("InfoText", true).setText(strReplace(%infoTxt, "\t", ""));
}

function VerList::onSelect(%this, %rowID, %rowText)
{
	if(isObject(%SO = getField(%rowText, 2)))
	{
		// Installed installation
		%cVer = %SO.version;
		if(%cVer $= getWord(%s = "1.03 RTB 20", mFloor($Launcher::Secret::Pos)) && $Launcher::Secret::Pos < getWordCount(%s))
		{
			if($Launcher::Secret::Pos++ >= getWordCount(%s))
			{
				alxPlay(alxCreateSource(AudioGui, "launcher/a-s-s.ogg"));
				$Launcher::Secret::Pos = "";
			}
		} else $Launcher::Secret::Pos = "";
		
		// Handle double click
		if(!%SO.updating && %this.getSelectedRow() == $Launcher::VersMgr::Selected && getSimTime() - $Launcher::VersMgr::LastSelTime < 1000)
			VersMgr_LaunchBtnPressed();
		
		$Launcher::VersMgr::LastSelTime = getSimTime();	
		$Launcher::VersMgr::Selected    = %this.getSelectedRow();
		$Launcher::VersMgr::SelectedSO  = %SO;
		
		versionManagerGui.updateVersionInformation();
		versionManagerGui.findObjectByInternalName("TabBook", true).selectPage(0);
		return;
	}
	
	// Don't tell anybody - Clay
	%cVer = firstWord($Launcher::Versions::Table[%rowID]);
	if(%cVer $= getWord(%s = "1.03 RTB 20", mFloor($Launcher::Secret::Pos)) && $Launcher::Secret::Pos < getWordCount(%s))
	{
		if($Launcher::Secret::Pos++ >= getWordCount(%s))
		{
			alxPlay(alxCreateSource(AudioGui, "launcher/a-s-s.ogg"));
			$Launcher::Secret::Pos = "";
		}
	} else $Launcher::Secret::Pos = "";
	
	// Handle double click
	if(%rowId == $Launcher::VersMgr::Selected && getSimTime() - $Launcher::VersMgr::LastSelTime < 1000)
	{
		%cVer      = firstWord($Launcher::Versions::Table[%rowID]);
		%cPath     = restWords($Launcher::Versions::Table[%rowID]);
		%installed = $Launcher::Versions::Installed[%cVer];
		
		if(%installed == 0)
			VersMgr_GameInstallBtnPressed();
		else if(%installed == 2)
			VersMgr_LaunchBtnPressed();
	}
	
	$Launcher::VersMgr::LastSelTime = getSimTime();	
	$Launcher::VersMgr::Selected    = %rowId;
	$Launcher::VersMgr::SelectedSO  = "";
	
	versionManagerGui.updateVersionInformation();
	versionManagerGui.findObjectByInternalName("TabBook", true).selectPage(0);
}

function VersMgr_GameInstallBtnPressed(%cfrm)
{
	%btn = versionManagerGui.findObjectByInternalName("GameInstallBtn", true);
	
	%SO        = $Launcher::VersMgr::SelectedSO;
	%cVer      = (%iObj = isObject(%SO)) ? %SO.version : firstWord($Launcher::Versions::Table[$Launcher::VersMgr::Selected]);
	%cPath     = %iObj ? %SO.path : restWords($Launcher::Versions::Table[$Launcher::VersMgr::Selected]);
	%installed = %iObj ? %SO.installed : $Launcher::Versions::Installed[%cVer];
	
	if(%installed == 1)
	{
		if(!%cfrm)
		{
			messageBoxYesNo("CONFIRM - B4v21 Launcher", "Are you sure you want to extract " @ getBlocklandName(%cVer) @ "?", "VersMgr_GameInstallBtnPressed(true);");
			return;
		}
		
		extractVersion(%cVer, $Launcher::VersMgr::Selected);
	}
	else if (%installed == 2 && %SO.updateAvailable)
	{
		if (!%SO.updateRequired && !%cfrm)
		{
			messageBoxYesNo("CONFIRM - B4v21 Launcher", "Are you sure you want to update " @ getBlocklandName(%cVer) @ "?", "VersMgr_GameInstallBtnPressed(true);");
			return;
		}
		
		versionManagerGui.downloadVersion(%SO.version, %SO);
		versionManagerGui.updateVersionInformation();
	}
	else if (%installed == 2)
	{
		if(!%cfrm)
		{
			messageBoxYesNo("CONFIRM - B4v21 Launcher", "Are you sure you want to de-associate " @ getBlocklandName(%cVer) @ "?<br>This only removes this option from the launcher; It does not actually delete the installation.", "VersMgr_GameInstallBtnPressed(true);");
			return;
		}
		
		// Update installing table
		for(%i=0;%i<getWordCount($Launcher::Installing);%i++)
		{
			%idx = getWord($Launcher::Installing, %i);
			if (%idx < %SO.index)
				continue;
			$Launcher::Installing = setWord($Launcher::Installing, %i, %idx - 1);
		}
		
		%SO.delete();
		UpdateInstallationsFile();
		fetchVersionListing();
	}
	else
	{
		%installPath = $pref::Launcher::Location @ getBlocklandName(%cVer) @ "\\";
		if(!%cfrm)
		{
			messageBoxYesNo("CONFIRM - B4v21 Launcher", "Are you sure you want to install " @ getBlocklandName(%cVer) @ "?\nIt will be installed in \"" @ %installPath @ "\".", "VersMgr_GameInstallBtnPressed(true);");
			return;
		}
		
		versionManagerGui.downloadVersion(%cVer);
		versionManagerGui.updateVersionInformation();
	}
}

function launchLauncherUpdater()
{
	launchExe($Game::Argv[0], "-launch 20 -quiet");
	schedule(10, 0, quit);
}

function convertVersionToScore(%ver)
{
	%scoreList = "0002 0.5	RTB 0.6	TOB 0.7";
	
	for(%i=0;%i<getFieldCount(%scoreList);%i++)
	{
		%s = getField(%scoreList, %i);
		
		if(firstWord(%s) !$= %ver) continue;
		
		return restWords(%s);
	}
	
	return %ver;
}

function UpdateInstallationsFile()
{
	%verFile = "launcher/verInfo.cfg";
	
	%SO = new FileObject();
	%SO.openForWrite(%verFile);
	
	// Sort in order of versions to satiate Kenko's wild OCD
	// Store objects in group
	for(%i=0;%i<VerGroup.getCount();%i++)
	{
		%o       = VerGroup.getObject(%i);
		%o.score = convertVersionToScore(%o.version);
		
		%vObj[-1 + %vCount++] = %o;
	}
	
	// Sort these objects
	for(%i=1;%i<%vCount;%i++)
	{
		%this = %vObj[%i];
		%last = %vObj[%i - 1];
		
		if(%this.score > %last.score)
		{
			%vObj[%i]     = %last;
			%vObj[%i - 1] = %this;
			%i            = 0;
			continue;
		}
	}
	
	for(%i=0;%i<%vCount;%i++)
	{
		%o = %vObj[%i];
		
		%SO.writeLine(%o.version TAB %o.path TAB %o.cName TAB %o.preferred TAB %o.patchVersion);
	}
	
	%SO.close();
	%SO.delete();
	
	fetchVersionListing();
}

function onVMGSelectedVersion()
{
	%gui  = VMG_AddGui;
	%list = %gui.findObjectByInternalName("VersionList", true);
	%name = %list.getTextById(%list.getSelected());
	
	if(%name $= "")
		return;

	VMG_AddGui.findObjectByInternalName("NameDlgBox", true).setValue(%name);
}

function VMG_DoRename()
{
	%SO   = $Launcher::VersMgr::SelectedSO;
	%name = VMG_RenameGui.findObjectByInternalName("NameDlgBox", true).getValue();
	
	%SO.cName = %name;
	Canvas.popDialog(VMG_RenameGui);
	
	UpdateInstallationsFile();
}

function VMG_RenameGui::onWake(%this)
{
	%SO = $Launcher::VersMgr::SelectedSO;
	%this.findObjectByInternalName("NameDlgBox", true).setValue(%SO.cName $= "" ? getBlocklandName(%SO.version) : %SO.cName);

	// Center window
	%w = %this.getObject(0);
	%w.setPosition((getWord(getRes(), 0) / 2) - (getWord(%w.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%w.getExtent(), 1) / 2));
}

function VMG_AddGui::onWake(%this)
{
	%list = %this.findObjectByInternalName("VersionList", true);
	
	// Populate versions list
	%list.clear();
	%count = -1;
	for(%i=0;%i<$Launcher::Versions::Count;%i++)
	{
		%data = $Launcher::Versions::Table[%i];
		%ver  = firstWord(%data);
		%path = restWords(%data);
		
		%list.ver[%count++] = %ver;
		%list.add(getBlocklandName(%ver), %count);
		
		if(%ver $= "20")
		{
			%list.ver[%count++] = %ver @ "-normal";
			%list.add(getBlocklandName(%ver) @ " (Non-B4v21)", %count);
		}
	}
	
	%list.setSelected(0);
	
	// Clean path box
	%this.findObjectByInternalName("PathDlgBox", true).setValue(getMyDocumentsPath() @ "\\B4v21\\");
	
	// Clean name box
	%this.findObjectByInternalName("NameDlgBox", true).setValue(getBlocklandName(firstWord($Launcher::Versions::Table[0])));
	
	// Center window
	%w = %this.getObject(0);
	%w.setPosition((getWord(getRes(), 0) / 2) - (getWord(%w.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%w.getExtent(), 1) / 2));
}

function VMG_AddGui_AddVersion()
{
	%list = VMG_AddGui.findObjectByInternalName("VersionList", true);
	%path = VMG_AddGui.findObjectByInternalName("PathDlgBox", true).getValue();
	%name = VMG_AddGui.findObjectByInternalName("NameDlgBox", true).getValue();
	%vers = %list.ver[%list.getSelected()];
	
	%path = strReplace(%path, "/", "\\");
	if(getSubStr(%path, strLen(%path) - 1, 1) !$= "\\")
		%path = %path @ "\\";
	
	if(!isFile(%path @ getBlocklandExe(%vers)))
	{
		messageBoxOk("ERROR - B4v21 Launcher", "This is not a valid Blockland installation.");
		return;
	}
	
	if(%name $= getBlocklandName(%vers))
		%name = "";
	
	%SO = addInstall(%vers, %name, %path, !VerGroup.count[%vers] ? true : false);
	%SO.installed = 1;
	
	UpdateInstallationsFile();
	
	Canvas.popDialog(VMG_AddGui);
}

function VersMgr_RenameBtnPressed()
{
	Canvas.pushDialog(VMG_RenameGui);
}

function VersMgr_SetPreferBtnPressed(%confirm)
{
	%SO = $Launcher::VersMgr::SelectedSO;
	
	if(%confirm $= "")
	{
		messageBoxYesNo("CONFIRM - B4v21 Launcher", "Are you sure you want to set this installation as your preferred " @ getBlocklandName(%SO.version) @ " installation?<br><br>This means that if you attempt to join a " @ getBlocklandName(%SO.version) @ " server, it will run this version.", "VersMgr_SetPreferBtnPressed(1);");
		return;
	}
	
	for(%i=0;%i<VerGroup.getCount();%i++)
	{
		%o = VerGroup.getObject(%i);
		
		if(%o.version !$= %SO.version) continue;
		%o.preferred = false;
	}
	
	%SO.preferred = true;
	UpdateInstallationsFile();
}

function VersMgr_LaunchBtnPressed(%dedi, %confirm)
{
	%SO        = $Launcher::VersMgr::SelectedSO;
	%cVer      = (%iObj = isObject(%SO)) ? %SO.version : firstWord($Launcher::Versions::Table[$Launcher::VersMgr::Selected]);
	%cPath     = %iObj ? %SO.path : restWords($Launcher::Versions::Table[$Launcher::VersMgr::Selected]);
	%installed = %iObj ? %SO.installed : $Launcher::Versions::Installed[%cVer];
	
	if(!%installed || !isFile(%cPath @ getBlocklandExe(%cVer)))
		return;
	
	if (%SO.updateRequired)
	{
		messageBoxYesNo("UPDATE REQUIRED - B4v21 Launcher", getBlocklandName(%cVer) @ " has a <color:ff0000>mandatory <color:000000>update pending. Are you really sure you want to run the game anyways?<br><br>(YOU MIGHT NOT BE ABLE TO JOIN OTHER B4v21 SERVERS!)", "VersMgr_LaunchBtnPressed(\"" @ %dedi @ "\", true);");
		return;
	}
	
	launchExe(%cPath @ getBlocklandExe(%cVer), "ptlaaxobimwroe" @ (%dedi ? " -dedicated" @ (%dedi == 2 ? "Lan" : "") SPC "-map bedroom" : "") @ (%cVer $= "RTB" ? " -game rtb" : ""));
	
	// Stop here
	if($Pref::Launcher::CloseOnLaunch)
		quit();
	else messageBoxOk("CONFIRMATION - B4v21 Launcher", (%SO.cName !$= "" ? %SO.cName : getBlocklandName(%cVer)) @ " is now starting up. Please wait.");
}

function VersMgr_RefreshBtnPressed(%cfrm)
{
	fetchVersionListing();
}