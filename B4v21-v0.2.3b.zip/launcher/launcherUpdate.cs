function updateLauncher()
{
	%downloadID = tcpDownload("./archive.zip", $NewLauncherHost, $NewLauncherPath, $NewLauncherPort, "onLauncherDownloadDone", "onLauncherDownloadProgress", "onLauncherDownloadStart");
	if(%downloadID == -1) {
		messageBoxOk("ERROR - B4v21 Launcher", "Failed to download updator<br>(tcpDownload failed)");
		%queueObj.delete();
		return false;
	}
}

function onLauncherDownloadStart(%id)
{
	
}

function onLauncherDownloadProgress(%curr, %max)
{
	%pText = %pText @ (%curr >= %max ? getFancyByteString(%curr) : getFancyByteString(%curr) @ " / " @ getFancyByteString(%max));
	
	MiniLauncherDlg.findObjectByInternalName("ProgressText", true).setText("<font:Consolas:18><just:center>Downloading... (" @ %pText @ ")");
	MiniLauncherDlg.findObjectByInternalName("ProgressBar", true).setValue(%curr >= %max ? -1 : %curr / %max);
}

function onLauncherDownloadDone(%fileName)
{
	%ourPath = filePath(strReplace($Game::Argv[0], "\\", "/"));
	if (!exportZip(%ourPath @ "/archive.zip", %ourPath @ "/", false, true, "extractLauncher_Progress"))
	{
		realMessageBox("ERROR - B4v21 Launcher", "Unable to extract zip...");
		return;
	}
	
	%argList = "";
	for(%i=0;%i<$Game::Argc;%i++)
		%argList = trim(%argList SPC $Game::Argv[%i]);
	
	launchExe(strReplace(filePath(strReplace($Game::Argv[0], "\\", "/")), "/", "\\") @ "\\B4v21 Launcher.exe", %argList);
	schedule(500, 0, quit);
}

function extractLauncher_Progress(%curr, %max)
{
	%pText = (%curr >= %max ? getFancyByteString(%curr) : getFancyByteString(%curr) @ " / " @ getFancyByteString(%max));
	
	MiniLauncherDlg.findObjectByInternalName("ProgressText", true).setText("<font:Consolas:18><just:center>Extracting... (" @ %pText @ ")");
	MiniLauncherDlg.findObjectByInternalName("ProgressBar", true).setValue(%curr >= %max ? -1 : %curr / %max);
}

//--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=
//========-========-========-========-========-========-========-========-========-========-========-========-========-========-========-========-========-========-========-
//--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=

function updateVersion(%path)
{
	$installPath = %path;
	%downloadID  = tcpDownload(strReplace($installPath, "\\", "/") @ "archive.zip", $QuickLaunchHost, $QuickLaunchPath, $QuickLaunchPort, "onVersionDownloadDone", "onLauncherDownloadProgress", "onLauncherDownloadStart");
	if(%downloadID == -1) {
		messageBoxOk("ERROR - B4v21 Launcher", "Failed to download updater<br>(tcpDownload failed)");
		%queueObj.delete();
		return false;
	}
}

function onVersionDownloadDone(%fileName)
{
	%ourPath = filePath(strReplace($Game::Argv[0], "\\", "/"));
	if (!exportZip($installPath @ "archive.zip", $installPath, true, true, "extractLauncher_Progress"))
	{
		$QuickLaunchFail = "EXTRACT_ERROR";
		onQuickLaunchFail();
	}
	else
	{
		if (!isObject(%so = $QuickLaunchSO))
			addInstall($QuickLaunchVersion, "", strReplace(filePath(%fileName), "/", "\\"), !VerGroup.count[$QuickLaunchVersion], $Launcher::Versions::PatchVersion[$QuickLaunchVersion]);
		else
			%so.patchVersion = %so.newPatchVersion;
		
		UpdateInstallationsFile();
		onQuickLaunchSuccess();
	}
}