function versionManagerGui::isInDownloadQueue(%this, %ver) {
	%group = %this.findObjectByInternalName("NetworkQueue", true);
	
	for(%i=0;%i<%group.getCount();%i++) {
		%queueObj = %group.getObject(%i);
		
		if(%queueObj.version !$= %ver) continue;
		return true;
	}
	
	if(!%found) return false;
}

function versionManagerGui::downloadVersion(%this, %ver, %customSO) {
	%found = false;
	for(%i=0;%i<VerGroup.getCount();%i++)
	{
		%data = VerGroup.getObject(%i);
		if ((isObject(%customSO) && %customSO != %data) || %data.version !$= %ver)
			continue;
		
		%found = true;
		%cVer  = %data.version;
		%dPath = %data.path;
		%cPath = $Launcher::Versions::Ver[%cVer];
		%cDwnl = $Launcher::Versions::Installed[%cVer];
		%i     = %data.listIndex;
		break;
	}
	
	if(!%found)
	{
		for(%i=0;%i<$Launcher::Versions::Count;%i++)
		{
			%data  = $Launcher::Versions::Table[%i];
			%cVer  = firstWord(%data);
			%cPath = $Launcher::Versions::Ver[%cVer];
			%cDwnl = $Launcher::Versions::Installed[%cVer];
			
			if(%cVer !$= %ver)
				continue;
			
			%found = true;
			break;
		}
		
		%i = "";
	}
	
	if (!%found)
	{
		error("versionManagerGui::downloadVersion() - Failed to find Blockland v" @ %ver @ ".");
		return false;
	}
	
	%newObj = new GuiSwatchCtrl() {
		canSaveDynamicFields = "0";
		Profile = "GuiDefaultProfile";
		HorizSizing = "width";
		VertSizing = "bottom";
		position = "0 0";
		Extent = "389 47";
		canSave = "1";
		Visible = "1";
		hovertime = "1000";
		fill = "1";
		border = "1";
		fillColor = "200 200 200 255";
		borderColor = "0 0 0 255";
		versionIdx = %i;
		version = %ver;
		downloadId = -1;
		downloadInfo = %cPath;
		customDownloadPath = %dPath;
	
		new GuiBitmapButtonCtrl() {
			canSaveDynamicFields = "0";
			Profile = "BlockButtonProfile";
			HorizSizing = "left";
			VertSizing = "center";
			position = "327 10";
			Extent = "58 26";
			Command = "versionManagerGui.cancelDownload(" @ %ver @ ");";
			MinExtent = "8 2";
			canSave = "1";
			Visible = "1";
			hovertime = "1000";
			pitch = "1";
			text = "Cancel";
			groupNum = "-1";
			buttonType = "PushButton";
			bitmap = "./ui/Button2";
		};
		new GuiMLTextCtrl() {
			canSaveDynamicFields = "0";
			Profile = "DownloadQueueHeaderProfile";
			HorizSizing = "width";
			VertSizing = "bottom";
			position = "6 3";
			Extent = "317 24";
			MinExtent = "8 2";
			canSave = "1";
			Visible = "1";
			hovertime = "1000";
			lineSpacing = "2";
			allowColorChars = "0";
			maxChars = "-1";
			text = "<color:000000>" @ getBlocklandName(%ver);
		};
		new GuiMLTextCtrl() {
			canSaveDynamicFields = "0";
			Profile = "DownloadQueueHeaderProfile";
			HorizSizing = "width";
			VertSizing = "bottom";
			position = "6 24";
			Extent = "317 18";
			MinExtent = "8 2";
			canSave = "1";
			Visible = "1";
			hovertime = "1000";
			lineSpacing = "2";
			allowColorChars = "0";
			maxChars = "-1";
			text = "<color:000000><font:Palatino Linotype:18>QUEUED";
		};
	};
	
	if (isObject(%customSO))
	{
		$Launcher::Installing = trim($Launcher::Installing SPC %i);
		%customSO.updating    = true;
	}
	
	%group = %this.findObjectByInternalName("NetworkQueue", true);
	%group.add(%newObj);
	
	if (%group.getCount() == 1)
		return %this.nextDownload();
	
	return true;
}

function versionManagerGui::nextDownload(%this) {
	%group = %this.findObjectByInternalName("NetworkQueue", true);
	
	// All done
	if(%group.getCount() == 0) {
		versionManagerGui.findObjectByInternalName("ProgressBar", true).setValue(0);
		versionManagerGui.findObjectByInternalName("ProgressBar", true).getObject(0).setText("<font:Consolas:18><just:center>Ready");
		versionManagerGui.findObjectByInternalName("RefreshBtn", true).setActive(1);
		
		return false;
	}
	%queueObj = %group.getObject(0);
	
	%cVer  = %queueObj.version;
	%cPath = %queueObj.downloadInfo;
	
	%installPath = $pref::Launcher::Location @ getBlocklandName(%cVer) @ "\\";
	if((%customPath = %queueObj.customDownloadPath) !$= "")
		%installPath = %customPath;
	
	versionManagerGui.findObjectByInternalName("VersionList", true).setRowById(%queueObj.versionIdx, getBlocklandName(%cVer) @ " (installing)");
	
	%host = getField(%cPath, 0);
	%port = getField(%cPath, 1);
	%path = getField(%cPath, 2);
	
	$Launcher::VersMgr::CurrentlyDownloading = %queueObj;
	
	if(%cVer $= "21")
	{
		// Badspot gets a special condition
		InstallV21();
	}
	else
	{
		%downloadID = tcpDownload(strReplace(%installPath, "\\", "/") @ "archive.zip", %host, %path, %port, "onVersionDownloadDone", "onVersionDownloadProgress", "onVersionDownloadStart");
		if(%downloadID == -1) {
			messageBoxOk("ERROR - B4v21 Launcher", "Failed to download " @ getBlocklandName(%cVer) @ "<br>(tcpDownload failed)");
			%queueObj.delete();
			return false;
		}
	}
	
	%queueObj.downloadId = %downloadID;
	return true;
}

function versionManagerGui::cancelDownload(%this, %ver, %cfrm) {
	%group = %this.findObjectByInternalName("NetworkQueue", true);
	
	for(%i=0;%i<%group.getCount();%i++) {
		%child = %group.getObject(%i);
		
		if(%child.version !$= %ver) continue;
		
		if(!%cfrm) {
			messageBoxYesNo("STOP DOWNLOAD? - B4v21 Launcher", "Are you sure you want to stop downloading " @ getBlocklandName(%ver) @ "?", "versionManagerGui.cancelDownload(" @ %ver @ ", 1);");
			return true;
		}
		
		if(%ver $= "21") {
			if(isObject(v21BlobQuery)) {
				messageBoxOK("ERROR - B4v21 Launcher", "Please wait for the download to start before stopping it.");
				return;
			}
			
			CancelBlobs();
		}
		
		if(%child.downloadId !$= "-1") {
			tcpCancelDownload(%child.downloadId);
			%this.schedule(1, nextDownload);
		}
		
		$Launcher::Versions::Installed[%ver] = 0;
		%this.updateVersionInformation();
		
		%child.delete();
		return true;
	}
	
	return false;
}

function onVersionDownloadStart(%id)
{
	%queueObj = $Launcher::VersMgr::CurrentlyDownloading;
	
	%installPath = $pref::Launcher::Location @ getBlocklandName(%queueObj.version) @ "\\";
	createPath(strReplace(%installPath, "\\", "/"));
	$Launcher::Versions::Installed[%queueObj.version] = 1;
	
	%queueObj.getObject(2).setText("<color:000000><font:Palatino Linotype:18>DOWNLOADING");
	$Launcher::Installer::AvgTransferRate = 0;
}

function onVersionDownloadProgress(%curr, %max)
{
	%cVer = $Launcher::VersMgr::CurrentlyDownloading.version;
	%cIdx = $Launcher::VersMgr::CurrentlyDownloading.versionIdx;
	
	if(getSimTime() - $Launcher::Installer::LastAvgTime >= 1000)
	{
		$Launcher::Installer::LastAvgTime = getSimTime();
		$Launcher::VersionInstallingCurr = %curr;
		
		if($Launcher::Installer::AvgSize !$= "")
		{
			for(%i=0;%i<$Launcher::Installer::AvgSize;%i++) %sum += $Launcher::Installer::Avg[%i];
			%sum /= $Launcher::Installer::AvgSize;
			
			deleteVariables("$Launcher::Installer::Avg*");
			$Launcher::Installer::AvgTransferRate = %sum;
		}
	}
	
	// Little detail
	%dotTime = 600;
	%dots = getSubStr("...", 0, mFloor((getSimTime() % (%dotTime * 4)) / %dotTime));
	$Launcher::VersMgr::CurrentlyDownloading.getObject(2).setText("<color:000000><font:Palatino Linotype:18>DOWNLOADING" @ %dots);
	
	%pBar = (!versionManagerGui.isAwake() ? PortableProgressWindow.getObject(0) : versionManagerGui.findObjectByInternalName("ProgressBar", true));
	
	if(!versionManagerGui.isAwake() && PortableProgressWindow.getGroup() != Canvas.getObject(Canvas.getCount() - 1))
	{
		Canvas.getObject(Canvas.getCount() - 1).add(PortableProgressWindow);
		
		if(!PortableProgressWindow.isVisible()) {
			PortableProgressWindow.setVisible(1);
			PortableProgressWindow.setPosition(getWord(getRes(), 0) - getWord(PortableProgressWindow.getExtent(), 0), getWord(getRes(), 1) - getWord(PortableProgressWindow.getExtent(), 1));
		}
	}
	else if(versionManagerGui.isAwake() && PortableProgressWindow.getGroup() != versionManagerGui.getId())
	{
		versionManagerGui.add(PortableProgressWindow);
		PortableProgressWindow.setVisible(0);
	}
	
	$Launcher::Installer::Avg[-1 + $Launcher::Installer::AvgSize++] = %curr - $Launcher::VersionInstallingCurr;
	
	%pText = "<font:Consolas:18><just:center>";
	%pText = %pText @ (%curr >= %max ? getFancyByteString(%curr) : getFancyByteString(%curr) @ " / " @ getFancyByteString(%max));
	%pText = %pText SPC "@ " @ getFancyByteString($Launcher::Installer::AvgTransferRate) @ "/s";
	
	%pBar.setValue((%curr >= %max ? -1 : %curr /  %max));
	%pBar.getObject(0).setText(%pText);
	
	// Update row
//	if(versionManagerGui.isAwake()) {
//		if(%curr >= %max)
//			versionManagerGui.findObjectByInternalName("VersionList", true).setRowById(%cIdx, getBlocklandName(%cVer));
//		else
//			versionManagerGui.findObjectByInternalName("VersionList", true).setRowById(%cIdx, getBlocklandName(%cVer) SPC "(" @ mFloor((%curr / %max) * 100) @ "%)");
//	}
}

function onVersionDownloadDone(%fileName) {
	if(!isObject($Launcher::VersMgr::CurrentlyDownloading))
	{
		error("onVersionDownloadDone() - No object is set in ::CurrentlyDownloading!");
		return;
	}
	
	versionManagerGui.findObjectByInternalName("ProgressBar", true).setValue(0);
	versionManagerGui.findObjectByInternalName("ProgressBar", true).getObject(0).setText("<font:Consolas:18><just:center>Ready");
	versionManagerGui.findObjectByInternalName("RefreshBtn", true).setActive(1);
	
	%cVer = $Launcher::VersMgr::CurrentlyDownloading.version;
	%cIdx = $Launcher::VersMgr::CurrentlyDownloading.versionIdx;
	%dlId = $Launcher::VersMgr::CurrentlyDownloading.downloadId;
	
	%path = $Launcher::VersMgr::CurrentlyDownloading.customDownloadPath;
	if (%path !$= "" && isObject(%SO = VerGroup.pathLookup[%path]))
	{
		$Launcher::Installing = removeWord($Launcher::Installing, removeWord);
		%SO.updating          = false;
		%SO.patchVersion      = %SO.newPatchVersion;
		if (%cVer !$= "21")
			extractVersion(%cVer, %cIdx, $Launcher::VersMgr::CurrentlyDownloading, %path);
	}
	else
	{
		addInstall(%cVer, "", strReplace(filePath(%fileName), "/", "\\"), !VerGroup.count[%cVer], $Launcher::Versions::PatchVersion[%cVer]);
		if(%cVer !$= "21")
			extractVersion(%cVer, %cIdx, $Launcher::VersMgr::CurrentlyDownloading);
	}
	
	$Launcher::VersMgr::CurrentlyDownloading.delete();
	deleteVariables("$Launcher::Installer::Avg*");
	
	UpdateInstallationsFile();
	versionManagerGui.schedule(1, "nextDownload");
}

function extractVersion_Progress(%curr, %max) {
	%pBar = (!versionManagerGui.isAwake() ? PortableProgressWindow.getObject(0) : versionManagerGui.findObjectByInternalName("ProgressBar", true));
	
	%pBar.setValue(%curr / %max);
	%pBar.getObject(0).setText("<font:Consolas:18><just:center>Extracting " @ %curr @ " / " @ %max @ " (" @ mFloor((%curr / %max) * 100) @ "%)");
}

function extractVersion(%cVer, %cIdx, %queueObj, %customPath) {
	if(isObject(%queueObj) && isObject(%queueObj.getObject(2)))
		%queueObj.getObject(2).setText("<color:000000><font:Palatino Linotype:18>EXTRACTING...");
	
	versionManagerGui.findObjectByInternalName("ProgressBar", true).getObject(0).setText("<font:Consolas:18><just:center>Extracting...");
	Canvas.repaint();
	
	%installPath = $pref::Launcher::Location @ getBlocklandName(%cVer) @ "\\";
	
	if (%customPath !$= "")
		%result = exportZip(strReplace(%customPath @ "archive.zip", "\\", "/"), strReplace(%customPath, "\\", "/"), true, true, "extractVersion_Progress", "prefs.cs\tprefs-trustList.txt\tFavorites.cs\tconfig.cs\tavatarColors.cs\t0.cs\t1.cs\t2.cs\t3.cs\t4.cs\t5.cs\t6.cs\t7.cs\tcolorSet.txt\tADD_ON_LIST.cs\tmusicList.cs");
	else
		%result = exportZip(strReplace(%installPath @ "archive.zip", "\\", "/"), strReplace(%installPath, "\\", "/"), true, true, "extractVersion_Progress");
	
	if(%result) {
		$Launcher::Versions::Table[%cIdx] = %cVer SPC %installPath;
		
		UpdateInstallationsFile();
		fetchVersionListing();
	}
	else
	{
		messageBoxOK("FAIL - B4v21 Launcher", "The zip archive \"" @ %installPath @ "archive.zip\" is missing or corrupted.");
	}
	
	versionManagerGui.findObjectByInternalName("ProgressBar", true).getObject(0).setText("<font:Consolas:18><just:center>Ready");
	versionManagerGui.add(PortableProgressWindow);
	PortableProgressWindow.setVisible(false);
	
	if(!isObject($Launcher::VersMgr::CurrentlyDownloading)) return;
}