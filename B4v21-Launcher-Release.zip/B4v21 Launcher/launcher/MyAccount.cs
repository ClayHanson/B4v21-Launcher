function MyAccountGui::onWake(%this)
{
	// Center the window
	%object = %this.getObject(0);
	%object.setPosition((getWord(getRes(), 0) / 2) - (getWord(%object.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%object.getExtent(), 1) / 2));
	QueryMyAccount();
}

//================================//

function QueryMyAccount()
{
	if (isObject(MyAccountGui.SO))
	{
		MyAccountGui.SO.deleteAll();
		MyAccountGui.SO.delete();
	}
	
	if (isObject(MyAccountTCPobj))
		return;
	
	MessagePopup("PLEASE WAIT...", "Contacting B4v21 services...");
	
	// Find.
	%BL_IDList     = MyAccountGui.findObjectByInternalName("BL_IDList", true);
	%BanList       = MyAccountGui.findObjectByInternalName("BanList", true);
	%SessionList   = MyAccountGui.findObjectByInternalName("GameSessionList", true);
	%TrustList     = MyAccountGui.findObjectByInternalName("TrustList", true);
	%MainName      = MyAccountGui.findObjectByInternalName("MainName", true);
	%MainBLID      = MyAccountGui.findObjectByInternalName("MainBLID", true);
	%NoBanScreen   = MyAccountGui.findObjectByInternalName("NoBanScreen", true);
	%NoSesScreen   = MyAccountGui.findObjectByInternalName("NoSessionScreen", true);
	%NoTrustScreen = MyAccountGui.findObjectByInternalName("NoTrustScreen", true);
	%TabBook       = MyAccountGui.findObjectByInternalName("Tabs", true);
	
	// Reset.
	%BL_IDList.clear();
	%BanList.clear();
	%SessionList.clear();
	%TrustList.clear();
	
	// Setup.
	%MainName.setText("Please wait...");
	%MainBLID.setText("Please wait...");
	%NoBanScreen.setVisible(true);
	%NoSesScreen.setVisible(true);
	%NoTrustScreen.setVisible(true);
	%TabBook.selectPage(0);
	
	// Create the SO
	MyAccountGui.SO = new SimGroup(AccountDetails)
	{
		AccountCount = 0;
		RecordCount  = 0;
		BanCount     = 0;
		TrustCount   = 0;
	};
	
	// Create the TCP obj
	new TCPObject(MyAccountTCPobj);
	
	// Configure.
	MyAccountTCPobj.SO             = MyAccountGui.SO;
	MyAccountTCPobj.gotMainAccount = false;
	
	// Connect.
	MyAccountTCPobj.connect("b4v21.block.land:80");
}

function MyAccountTCPobj::onDNSFailure(%this)
{
	CloseMessagePopup();
	messageBoxOk("ERROR", "Could not connect to B4v21 services at this current time! Please try again later.", "Canvas.popDialog(MyAccountGui);");
}

function MyAccountTCPobj::onConnectFailed(%this)
{
	CloseMessagePopup();
	messageBoxOk("ERROR", "Could not connect to B4v21 services at this current time! Please try again later.", "Canvas.popDialog(MyAccountGui);");
}

function MyAccountTCPobj::onConnected(%this)
{
	%this.send("GET /api/v1/getMyProfile.php HTTP/1.1\r\nHost: b4v21.block.land\r\nConnection: close\r\n\r\n");
}

function MyAccountTCPobj::onDisconnect(%this)
{
	// Find.
	%BL_IDList     = MyAccountGui.findObjectByInternalName("BL_IDList", true);
	%BanList       = MyAccountGui.findObjectByInternalName("BanList", true);
	%SessionList   = MyAccountGui.findObjectByInternalName("GameSessionList", true);
	%TrustList     = MyAccountGui.findObjectByInternalName("TrustList", true);
	%MainName      = MyAccountGui.findObjectByInternalName("MainName", true);
	%MainBLID      = MyAccountGui.findObjectByInternalName("MainBLID", true);
	%NoBanScreen   = MyAccountGui.findObjectByInternalName("NoBanScreen", true);
	%NoSesScreen   = MyAccountGui.findObjectByInternalName("NoSessionScreen", true);
	%NoTrustScreen = MyAccountGui.findObjectByInternalName("NoTrustScreen", true);
	
	// Populate.
	for (%i = 0; %i < %this.SO.AccountCount; %i++)
	{
		%acc = %this.SO.Accounts[%i];
		%BL_IDList.addRow(%i, %acc.bl_id TAB %acc.name TAB %acc.joinDate TAB %acc.lastAuthDate);
	}
	
	for (%i = 0; %i < %this.SO.BanCount; %i++)
	{
		%ban = %this.SO.Bans[%i];
		%BanList.addRow(%i, %ban.type TAB %ban.createDate TAB %ban.expireDate TAB %ban.reason);
	}
	
	for (%i = 0; %i < %this.SO.RecordCount; %i++)
	{
		%rec = %this.SO.Records[%i];
		%SessionList.addRow(%i, %rec.bl_id TAB restWords(getBlocklandName(%rec.version)) TAB %rec.authTime TAB %rec.ip);
	}

	for (%i = 0; %i < %this.SO.TrustCount; %i++)
	{
		%trst = %this.SO.Trusts[%i];
		%TrustList.addRow(%i, %trst.account TAB %trst.target TAB %trst.addTime TAB (%trst.mutualTime $= "" ? "<Not Mutual>" : %trst.mutualTime) TAB %trst.trustLevel);
	}
	
	// Visualize
	if (%this.SO.BanCount)
		%NoBanScreen.setVisible(false);
	
	if (%this.SO.RecordCount)
		%NoSesScreen.setVisible(false);

	if (%this.SO.TrustCount)
		%NoTrustScreen.setVisible(false);
	
	if (!%this.SO.AccountCount)
	{
		%MainName.setText("N/A");
		%MainBLID.setText("N/A");
	}
	else
	{
		%MainName.setText(%this.SO.Accounts[0].name);
		%MainBLID.setText("Blockland ID" SPC %this.SO.Accounts[0].bl_id);
	}
	
	// Close the popup
	CloseMessagePopup();
	
	// Done with this.
	%this.schedule(1, delete);
}

function MyAccountTCPobj::onLine(%this, %line)
{
	%action = getField(%line, 0);
	%args   = removeField(%line, 0);
	
	switch$(%action)
	{
		case "ACCOUNT":
			%name       = getField(%args, 0);
			%bl_id      = getField(%args, 1);
			%joinDate   = getField(%args, 2);
			%lastTime   = getField(%args, 3);
			
			%SO = new ScriptObject()
			{
				name         = %name;
				bl_id        = %bl_id;
				joinDate     = %joinDate;
				lastAuthDate = %lastTime;
			};
			
			%this.SO.Accounts[-1 + %this.SO.AccountCount++] = %SO;
			%this.SO.add(%SO);
			
		case "BAN":
			%created = getField(%args, 0);
			%expire  = getField(%args, 1);
			%type    = getField(%args, 2);
			%reason  = getField(%args, 3);
			
			%SO = new ScriptObject()
			{
				expireDate = %expire;
				createDate = %created;
				type       = %type;
				reason     = %reason;
			};
			
			%this.SO.Bans[-1 + %this.SO.BanCount++] = %SO;
			%this.SO.add(%SO);
		
		case "RECORD":
			%id   = getField(%args, 0);
			%time = getField(%args, 1);
			%ip   = getField(%args, 2);
			%vers = getField(%args, 3);
			
			%SO = new ScriptObject()
			{
				bl_id    = %id;
				authTime = %time;
				ip       = %ip;
				version  = %vers;
			};
			
			%this.SO.Records[-1 + %this.SO.RecordCount++] = %SO;
			%this.SO.add(%SO);
		
		case "TRUST":
			%accountBL_ID = getField(%args, 0);
			%targetBL_ID  = getField(%args, 1);
			%addTime      = getField(%args, 2);
			%mutualTime   = getField(%args, 3);
			%trustLevel   = getField(%args, 4);
			
			%SO = new ScriptObject()
			{
				account    = %accountBL_ID;
				target     = %targetBL_ID;
				addTime    = %addTime;
				mutualTime = %mutualTime;
				trustLevel = %trustLevel;
			};
			
			%this.SO.Trusts[-1 + %this.SO.TrustCount++] = %SO;
			%this.SO.add(%SO);
			
		case "ERROR":
			messageBoxOk("ERROR", "This B4v21 service returned an error:\n\n\"" @ %args @ "\"", "Canvas.popDialog(MyAccountGui);");
	}
}