function updateLauncher()
{
	%downloadID = tcpDownload("./archive.zip", $NewLauncherHost, $NewLauncherPath, $NewLauncherPort, "onLauncherDownloadDone", "onLauncherDownloadProgress", "onLauncherDownloadStart");
	if(%downloadID == -1) {
		messageBoxOk("ERROR - B4v21 Launcher", "Failed to download updator<br>(tcpDownload failed)");
		%queueObj.delete();
		return false;
	}
}

function onLauncherDownloadStart(%id)
{
	
}

function onLauncherDownloadProgress(%curr, %max)
{
	%pText = (%curr >= %max ? getFancyByteString(%curr) : getFancyByteString(%curr) @ " / " @ getFancyByteString(%max));
	
	MiniLauncherDlg.findObjectByInternalName("ProgressText", true).setText("<font:Consolas:18><just:center>Downloading... (" @ %pText @ ")");
	MiniLauncherDlg.findObjectByInternalName("ProgressBar", true).setValue(%curr >= %max ? -1 : %curr / %max);
}

function onLauncherDownloadDone(%fileName)
{
	if (!exportZip(GetLauncherAbsolutePath() @ "archive.zip", GetLauncherContainerPath(), false, true, "extractLauncher_Progress", "prefs.cs\tverInfo.cfg"))
	{
		realMessageBox("ERROR - B4v21 Launcher", "Unable to extract zip to \"" @ GetLauncherContainerPath() @ "\"...");
		return;
	}
	
	launchExe(strReplace(filePath(strReplace($Game::Argv[0], "\\", "/")), "/", "\\") @ "\\B4v21 Launcher.exe", "");
	schedule(500, 0, quit);
}

function onLauncherDownloadFailed(%failReason)
{
	realMessageBox("ERROR - B4v21 Launcher", "Download failed (Error code \"" @ %failReason @ "\")!");
}

function extractLauncher_Progress(%curr, %max)
{
	%pText = (%curr >= %max ? getFancyByteString(%curr) : getFancyByteString(%curr) @ " / " @ getFancyByteString(%max));
	
	MiniLauncherDlg.findObjectByInternalName("ProgressText", true).setText("<font:Consolas:18><just:center>Extracting... (" @ %pText @ ")");
	MiniLauncherDlg.findObjectByInternalName("ProgressBar", true).setValue(%curr >= %max ? -1 : %curr / %max);
}

//--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=
//========-========-========-========-========-========-========-========-========-========-========-========-========-========-========-========-========-========-========-
//--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=--------=

function updateVersion(%path)
{
	if ($QuickLaunchVersion $= "20")
	{
		exec("launcher/v20install.cs");
		$QuickLaunch_20_Path = %path;
		InstallV20();
		return;
	}
	else if ($QuickLaunchVersion $= "rebuilt")
	{
		exec("launcher/rebuiltinstall.cs");
		$QuickLaunch_Rebuilt_Path = %path;
		InstallRebuilt();
		return;
	}
	
	$installPath = %path;
	%downloadID  = downloadFile(($QuickLaunchPort == "443" ? "https://" : "http://") @ $QuickLaunchHost @ $QuickLaunchPath, strReplace($installPath, "\\", "/") @ "archive.zip", "onVersionDownloadDone", "onLauncherDownloadProgress", "onLauncherDownloadStart", "onLauncherDownloadFailed");
	if (%downloadID == -1)
	{
		messageBoxOk("ERROR - B4v21 Launcher", "Failed to download updater<br>(tcpDownload failed)");
		%queueObj.delete();
		return false;
	}
}

function onVersionDownloadDone(%fileName)
{
	%ourPath = filePath(strReplace($Game::Argv[0], "\\", "/"));
	if ($QuickLaunchVersion $= "rebuilt" || $QuickLaunchVersion $= "21" || $QuickLaunchVersion $= "20")
	{
		if (!isObject(%so = $QuickLaunchSO))
		{
			addInstall($QuickLaunchVersion, "", strReplace(filePath(%fileName), "/", "\\"), !VerGroup.count[$QuickLaunchVersion], $Launcher::Versions::PatchVersion[$QuickLaunchVersion]);
		}
		else
		{
			%so.patchVersion = %so.newPatchVersion;
		}
		
		UpdateInstallationsFile(true);
		onQuickLaunchSuccess();
		return;
	}
	
	if (!exportZip($installPath @ "archive.zip", $installPath, true, true, "extractLauncher_Progress", "prefs.cs\tprefs-trustList.txt\tFavorites.cs\tconfig.cs\tavatarColors.cs\t0.cs\t1.cs\t2.cs\t3.cs\t4.cs\t5.cs\t6.cs\t7.cs\tcolorSet.txt\tADD_ON_LIST.cs\tmusicList.cs"))
	{
		$QuickLaunchFail = "EXTRACT_ERROR";
		onQuickLaunchFail();
	}
	else
	{
		if (!isObject(%so = $QuickLaunchSO))
		{
			addInstall($QuickLaunchVersion, "", strReplace(filePath(%fileName), "/", "\\"), !VerGroup.count[$QuickLaunchVersion], $Launcher::Versions::PatchVersion[$QuickLaunchVersion]);
		}
		else
		{
			%so.patchVersion = %so.newPatchVersion;
		}
		
		UpdateInstallationsFile(true);
		onQuickLaunchSuccess();
	}
}