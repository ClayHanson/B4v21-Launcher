function ColorsetGui::onWake(%this)
{
	// Center the window
	%this.getObject(0).schedule(32, placeInCenter);
	
	// Set defaults
	if ($Pref::ColorsetEditor::DefaultColorType $= "")
		$Pref::ColorsetEditor::DefaultColorType = 0;
	
	// Find elements
	%this.e_ColorPreview = %this.findObjectByInternalName("ColorPreview", true);
	%this.e_ColorList    = %this.findObjectByInternalName("ColorList", true);
	%this.e_TabBook      = %this.findObjectByInternalName("ColorTabs", true);
	
	// Select their preferred color editing method
	%this.e_TabBook.selectPage($Pref::ColorsetEditor::DefaultColorType);
	
	// Set the color
	%this.setColor("255 255 255 255");
}

function ColorsetGui::onSleep(%this)
{
	%this.reset();
}

function ColorsetGui::onSelectColorTab(%this, %tab)
{
	// Set the new preference
	$Pref::ColorsetEditor::DefaultColorType = %tab;
	
	// Save prefs
	export("$pref::*", "launcher/prefs.cs");
	
	// Change references
	switch(%tab)
	{
		case 0:  %prefix = "RGB";
		case 1:  %prefix = "HSV";
		default: %prefix = "RGB";
	}
	
	// Cache elements
	%this.e_ColorSel_R = %this.findObjectByInternalName(%prefix @ "_R", true);
	%this.e_ColorSel_G = %this.findObjectByInternalName(%prefix @ "_G", true);
	%this.e_ColorSel_B = %this.findObjectByInternalName(%prefix @ "_B", true);
	%this.e_ColorSel_A = %this.findObjectByInternalName(%prefix @ "_A", true);
	%this.e_ColorVal_R = %this.findObjectByInternalName(%prefix @ "_RValue", true);
	%this.e_ColorVal_G = %this.findObjectByInternalName(%prefix @ "_GValue", true);
	%this.e_ColorVal_B = %this.findObjectByInternalName(%prefix @ "_BValue", true);
	%this.e_ColorVal_A = %this.findObjectByInternalName(%prefix @ "_AValue", true);
	%this.e_HexColor   = %this.findObjectByInternalName(%prefix @ "_HexColor", true);
	
	// Update ourself
	%this.updatePreview();
}

//------------------------------------------------------------------

function ColorsetGui::cancel(%this)
{
	echo("::cancel() - wip");
	Canvas.popDialog(%this);
}

function ColorsetGui::done(%this)
{
	%List                = %this.e_ColorList;
	$Colorset::NumColors = 0;
	
	for (%i = 0; %i < %List.getCount(); %i++)
	{
		%child = %List.getObject(%i);
		$Colorset::Color[-1 + $Colorset::NumColors++] = %child.fillColor;
	}
	
	if (%this.callback !$= "")
		eval(%this.callback);
	
	Canvas.popDialog(%this);
}

function ColorsetGui::reset(%this)
{
	%this.e_ColorList.deleteAll();
}

//------------------------------------------------------------------

function ColorsetGui::setColor(%this, %color)
{
	%this.currentColor[0] = mFloor(atoi(getWord(%color, 0)));
	%this.currentColor[1] = mFloor(atoi(getWord(%color, 1)));
	%this.currentColor[2] = mFloor(atoi(getWord(%color, 2)));
	%this.currentColor[3] = mFloor(atoi(getWord(%color, 3)));
	
	if (isObject(%this.colorObject))
		%this.colorObject.fillColor = %this.currentColor[0] SPC %this.currentColor[1] SPC %this.currentColor[2] SPC %this.currentColor[3];
	
	if ($Pref::ColorsetEditor::DefaultColorType == 1)
	{
		// Calculate for HSB
		%HSV             = mRGB2HSV(%color);
		%this.hue        = getWord(%HSV, 0);
		%this.saturation = getWord(%HSV, 1);
		%this.brightness = getWord(%HSV, 2);
	}
	
	%this.updatePreview();
}

function ColorsetGui::getCurrentHexColor(%this)
{
	%tab = "0123456789ABCDEF";
	%ret = "";
	
	for (%i = 0 ; %i < 3; %i++)
	{
		%value = %this.currentColor[%i];
		%ret   = %ret @ getSubStr(%tab, mFloor(%value / 16), 1) @ getSubStr(%tab, %value % 16, 1);
	}
	
	return %ret;
}

//------------------------------------------------------------------

function ColorsetGui::updatePreview(%this)
{
	// Set update state
	%this.updating = true;
	
	// Set hex color
	%this.e_HexColor.setValue(%this.getCurrentHexColor());
	
	// Set preview
	%this.e_ColorPreview.fillColor = %this.currentColor[0] SPC %this.currentColor[1] SPC %this.currentColor[2] SPC %this.currentColor[3];
	
	if ($Pref::ColorsetEditor::DefaultColorType == 1)
	{
		// HSB
		// Update elements
		%this.e_ColorSel_R.setSelectorPos(mFloor(%this.e_ColorSel_R.getWidth() * (%this.hue / 360)) SPC "0");
		%this.e_ColorSel_G.setSelectorPos(mFloor(%this.e_ColorSel_G.getWidth() * (%this.saturation / 100)) SPC "0");
		%this.e_ColorSel_B.setSelectorPos(mFloor(%this.e_ColorSel_B.getWidth() * (%this.brightness / 100)) SPC "0");
		%this.e_ColorSel_A.setSelectorPos(mFloor(%this.e_ColorSel_A.getWidth() * (%this.currentColor[3] / 255)) SPC "0");
		%this.e_ColorVal_R.setValue(%this.hue);
		%this.e_ColorVal_G.setValue(%this.saturation);
		%this.e_ColorVal_B.setValue(%this.brightness);
		%this.e_ColorVal_A.setValue(%this.currentColor[3]);
		
		// Mix colors
		%R = %this.currentColor[0] / 255;
		%G = %this.currentColor[1] / 255;
		%B = %this.currentColor[2] / 255;
		%this.e_ColorSel_G.BaseColor = "1 1 1 1";
		%this.e_ColorSel_G.PickColor = %R SPC %G SPC %B SPC "1";
		%this.e_ColorSel_B.BaseColor = "0 0 0 1";
		%this.e_ColorSel_B.PickColor = %R SPC %G SPC %B SPC "1";
	}
	else
	{
		// RGB
		// Update elements
		%this.e_ColorSel_R.setSelectorPos(mFloor(%this.e_ColorSel_R.getWidth() * (%this.currentColor[0] / 255)) SPC "0");
		%this.e_ColorSel_G.setSelectorPos(mFloor(%this.e_ColorSel_G.getWidth() * (%this.currentColor[1] / 255)) SPC "0");
		%this.e_ColorSel_B.setSelectorPos(mFloor(%this.e_ColorSel_B.getWidth() * (%this.currentColor[2] / 255)) SPC "0");
		%this.e_ColorSel_A.setSelectorPos(mFloor(%this.e_ColorSel_A.getWidth() * (%this.currentColor[3] / 255)) SPC "0");
		%this.e_ColorVal_R.setValue(%this.currentColor[0]);
		%this.e_ColorVal_G.setValue(%this.currentColor[1]);
		%this.e_ColorVal_B.setValue(%this.currentColor[2]);
		%this.e_ColorVal_A.setValue(%this.currentColor[3]);
		
		// Mix colors
		%R = %this.currentColor[0] / 255;
		%G = %this.currentColor[1] / 255;
		%B = %this.currentColor[2] / 255;
		%this.e_ColorSel_R.BaseColor = "0" SPC %G SPC %B SPC "1";
		%this.e_ColorSel_R.PickColor = "1" SPC %G SPC %B SPC "1";
		%this.e_ColorSel_G.BaseColor = %R SPC "0" SPC %B SPC "1";
		%this.e_ColorSel_G.PickColor = %R SPC "1" SPC %B SPC "1";
		%this.e_ColorSel_B.BaseColor = %R SPC %G SPC "0 1";
		%this.e_ColorSel_B.PickColor = %R SPC %G SPC "1 1";
	}
	
	// Clear update state
	%this.updating = false;
}

function ColorsetGui::updateColorList(%this)
{
	%List = %this.e_ColorList;
	%w    = 192;
	%h    = 32 * mCeil(%List.getCount() / 6);
	
	%List.getGroup().scrollToTop();
	
	// Resize the list
	%List.resize(0, 0, %w, %h);
	
	// Position all of the colors
	for (%i = 0; %i < %List.getCount(); %i++)
	{
		%child = %List.getObject(%i);
		%child.setPosition((%i % 6) * 32, mFloor(%i / 6) * 32);
	}
}

function ColorsetGui::addColor(%this, %color)
{
	%List = %this.e_ColorList;
	
	%newCtrl = new GuiSwatchCtrl()
	{
		profile   = "BlockDefaultProfile";
		position  = "0 0";
		extent    = "32 32";
		fill      = "1";
		border    = "0";
		fillColor = %color;
		index     = %List.getCount();
		
		new GuiBitmapButtonCtrl()
		{
			profile = "BlockButtonProfile";
			position = "0 0";
			extent   = "32 32";
			command  = "ColorsetGui.onColorSelected(" @ %List.getCount() @ ");";
			bitmap   = "launcher/ui/btnColor";
		};
	};
	
	%List.add(%newCtrl);
}

function ColorsetGui::deleteColor(%this)
{
	if (!isObject(%this.colorObject))
		return;
	
	%index = %this.colorObject.index;
	
	%this.colorObject.delete();
	%this.updateColorList();
	%this.updatePreview();
	
	%this.colorObject = "";
	%this.onColorSelected((%index >= %this.e_ColorList.getCount() ? %this.e_ColorList.getCount() - 1 : %index));
	
	%this.e_ColorList.getGroup().scrollToBottom();

	// Re-index
	for (%i = %index; %i < %this.e_ColorList.getCount(); %i++)
		%this.e_ColorList.getObject(%i).index--;
}

//------------------------------------------------------------------

function ColorsetGui::newColor(%this)
{
	%this.addColor(%this.currentColor[0] SPC %this.currentColor[1] SPC %this.currentColor[2] SPC %this.currentColor[3]);
	%this.updateColorList();
	
	%this.onColorSelected(%this.e_ColorList.getCount() - 1);
	%this.e_ColorList.getGroup().scrollToBottom();
}

function ColorsetGui::onColorSelected(%this, %index)
{
	%this.selectedColor = %index;
	%this.colorObject   = %this.e_ColorList.getObject(%index);
	
	%this.setColor(%this.colorObject.fillColor);
	
	%this.updatePreview();
}

function ColorsetGui::onValueChanged(%this, %index)
{
	if (%this.updating)
		return;
	
	switch(%index)
	{
		case 0: // Hex Color
			%text = strUpr(%this.e_HexColor.getValue());
			%tbl  = "0123456789ABCDEF";
			
			if (stripChars(%text, "0123456789ABCDEF") !$= "")
			{
				messageBoxOk("ERROR - B4v21 Launcher", "Invalid hex color!");
				%this.e_HexColor.setValue(%this.getCurrentHexColor());
				return;
			}
			
			%R = (strPos(%tbl, getSubStr(%text, 0, 1)) * 16) + (strPos(%tbl, getSubStr(%text, 1, 1)));
			%G = (strPos(%tbl, getSubStr(%text, 2, 1)) * 16) + (strPos(%tbl, getSubStr(%text, 3, 1)));
			%B = (strPos(%tbl, getSubStr(%text, 4, 1)) * 16) + (strPos(%tbl, getSubStr(%text, 5, 1)));
			%A = (strPos(%tbl, getSubStr(%text, 6, 1)) * 16) + (strPos(%tbl, getSubStr(%text, 7, 1)));
			
			if (%A $= "0")
				%A = 255;
			
			%this.setColor(%R SPC %G SPC %B SPC %A);
			
		case 1: // First color
			if ($Pref::ColorsetEditor::DefaultColorType == 1)
			{
				%this.hue = 300 - ((360 * (getWord(%this.e_ColorSel_R.getSelectorPos(), 0) / (%this.e_ColorSel_R.getWidth() - 4))) - 1);
				%this.calculateHSB();
				return;
			}
			
			%value = (255 * (getWord(%this.e_ColorSel_R.getSelectorPos(), 0) / (%this.e_ColorSel_R.getWidth() - 4))) - 1;
			%this.setColor(%value SPC %this.currentColor[1] SPC %this.currentColor[2] SPC %this.currentColor[3]);
		case 2: // Second color
			if ($Pref::ColorsetEditor::DefaultColorType == 1)
			{
				%this.saturation = (100 * (getWord(%this.e_ColorSel_G.getSelectorPos(), 0) / (%this.e_ColorSel_G.getWidth() - 4))) - 1;
				%this.calculateHSB();
				return;
			}
			
			%value = (255 * (getWord(%this.e_ColorSel_G.getSelectorPos(), 0) / (%this.e_ColorSel_G.getWidth() - 4))) - 1;
			%this.setColor(%this.currentColor[0] SPC %value SPC %this.currentColor[2] SPC %this.currentColor[3]);
		case 3: // Third color
			if ($Pref::ColorsetEditor::DefaultColorType == 1)
			{
				%this.brightness = (100 * (getWord(%this.e_ColorSel_B.getSelectorPos(), 0) / (%this.e_ColorSel_B.getWidth() - 4))) - 1;
				%this.calculateHSB();
				return;
			}
			
			%value = (255 * (getWord(%this.e_ColorSel_B.getSelectorPos(), 0) / (%this.e_ColorSel_B.getWidth() - 4))) - 1;
			%this.setColor(%this.currentColor[0] SPC %this.currentColor[1] SPC %value SPC %this.currentColor[3]);
		case 4: // Alpha
			%value = (255 * (getWord(%this.e_ColorSel_A.getSelectorPos(), 0) / (%this.e_ColorSel_A.getWidth() - 4))) - 1;
			
			%this.setColor(%this.currentColor[0] SPC %this.currentColor[1] SPC %this.currentColor[2] SPC %value);
		case 5: // First color value
			%this.setColor(mClamp(atoi(%this.e_ColorVal_R.getValue()), 0, 255) SPC %this.currentColor[1] SPC %this.currentColor[2] SPC %this.currentColor[3]);
		case 6: // Second color value
			%this.setColor(%this.currentColor[0] SPC mClamp(atoi(%this.e_ColorVal_G.getValue()), 0, 255) SPC %this.currentColor[2] SPC %this.currentColor[3]);
		case 7: // Third color value
			%this.setColor(%this.currentColor[0] SPC %this.currentColor[1] SPC mClamp(atoi(%this.e_ColorVal_B.getValue()), 0, 255) SPC %this.currentColor[3]);
		case 8: // Alpha Value
			%this.setColor(%this.currentColor[0] SPC %this.currentColor[1] SPC %this.currentColor[2] SPC mClamp(atoi(%this.e_ColorVal_A.getValue()), 0, 255));
	}
}

function ColorsetGui::calculateHSB(%this)
{
	%Alpha = (255 * (getWord(%this.e_ColorSel_A.getSelectorPos(), 0) / (%this.e_ColorSel_A.getWidth() - 4))) - 1;
	%this.setColor(mHSV2RGB(%this.hue SPC %this.saturation SPC %this.brightness) SPC %Alpha);
}