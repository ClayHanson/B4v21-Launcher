function FileBrowser::GoBack(%this)
{
	%this.currentPage = %this.history[%this.historyIndex--];
	%this.LoadPage(%this.currentPage);
}

function FileBrowser::GoForward(%this)
{
	%this.currentPage = %this.history[%this.historyIndex++];
	%this.LoadPage(%this.currentPage);
}

function FileBrowser::GoHome(%this)
{
	%this.LoadPage("landing-page");
}

function FileBrowser::Refresh(%this)
{
	%this.LoadPage(%this.currentPage);
}

//----------------------------------------------------------------------------------------------------

function FileBrowser::OnOpen(%this)
{
	%this.UI_BTN_HOME      = versionManagerGui.findObjectByInternalName("FBrowserHomeBtn", true);
	%this.UI_BTN_REFRESH   = versionManagerGui.findObjectByInternalName("FBrowserRefreshBtn", true);
	%this.UI_BTN_NEXT_PAGE = versionManagerGui.findObjectByInternalName("FBrowserNextBtn", true);
	%this.UI_BTN_PREV_PAGE = versionManagerGui.findObjectByInternalName("FBrowserPrevBtn", true);
	%this.UI_PAGE_CONTENT  = versionManagerGui.findObjectByInternalName("FBrowserContent", true);
	
	if (%this.currentPage $= "")
		%this.LoadPage("landing-page");
}

function FileBrowser::LoadPage(%this, %url)
{
	// Url-enc the URL
	%url = strReplace(%url, " ", "%20");
	
	// Disconnect any existing TCP
	if (isObject(%this.TCP))
	{
		%this.TCP.disconnect();
		%this.TCP.delete();
	}
	
	// Setup some things
	if (%url !$= %this.currentPage)
	{
		%this.currentPage = %url;
		if (!%this.historyCount || %this.historyIndex == %this.historyCount - 1)
		{
			%this.history[-1 + %this.historyCount++] = %url;
			%this.historyIndex                       = %this.historyCount - 1;
		}
		else
		{
			%this.history[%this.historyIndex++] = %url;
			%this.historyCount                  = %this.historyIndex + 1;
		}
	}
	
	// Create the new TCP
	%o          = (%this.TCP = new TCPObject(FileBrowserTCP));
	%o.headers  = true;
	%o.site     = "b4v21.block.land";
	%o.port     = 80;
	%o.cmd      = "GET /api/files.php?page=" @ %url @ " HTTP/1.1\r\nUser-Agent: B4v21Launcher-v" @ getLauncherVersion() @ "\r\nHost: " @ %o.site @ "\r\nConnection: close\r\n\r\n";
	%o.connect(%o.site @ ":" @ %o.port);
	
	// Set connecting
	%o.setIsConnecting(true);
}

//----------------------------------------------------------------------------------------------------

function FileBrowserTCP::startObject(%this, %objType, %x, %y, %w, %h)
{
	// Determine the class name
	switch$ (%objType)
	{
		case "DIV": %cName = "GuiSwatchCtrl"; %cProfile = "BlockDefaultProfile"; %oName = "";
		case "BTN": %cName = "GuiButtonCtrl"; %cProfile = "BlockButtonProfile"; %oName = "";
		case "BMP": %cName = "GuiBitmapCtrl"; %cProfile = "BlockDefaultProfile"; %oName = "";
		case "TXT": %cName = "GuiMLTextCtrl"; %cProfile = "GuiMLTextProfile"; %oName = "FileBrowserText";
		default:
			error("FileBrowser ERROR [::startObject()]: Invalid object type \"" @ %objType @ "\"!");
			return;
	}
	
	// Determine new rect values
	%size_x = getWord(FileBrowser.UI_PAGE_CONTENT.getGroup().getExtent(), 0) - 17;
	%size_y = getWord(FileBrowser.UI_PAGE_CONTENT.getGroup().getExtent(), 1) - 17;
	%rel_w  = 411;
	%rel_h  = 344;
	%x      = %size_x * (%x / %rel_w);
	%y      = %size_y * (%y / %rel_h);
	%w      = %size_x * (%w / %rel_w);
	%h      = %size_y * (%h / %rel_h);
	
	// Create the object
	%obj      = eval("return new " @ %cName @ "(\"" @ %oName @ "\") { profile = " @ %cProfile @ "; };");
	%obj.rect = %x SPC %y SPC %w SPC %h;
	
	if (!isObject(%obj))
	{
		error("Internal error: Invalid class \"" @ %cName @ "\"!");
	}
	
	// Set rect
	%obj.setPosition(%x, %y);
	%obj.setExtent(%w, %h);
	
	// Set this object's parent
	if (isObject(%last = %this.getCurrentObject()))
		%last.add(%obj);
	else
		FileBrowser.UI_PAGE_CONTENT.add(%obj);
	
	// Add this object to the object list
	%this.objectList[-1 + %this.objectCount++] = %obj;
}

function FileBrowserTCP::endObject(%this)
{
	if (!%this.objectCount)
		return;
	
	// Remove it from our list!
	%this.objectList[1 + %this.objectCount--] = "";
}

function FileBrowserTCP::getCurrentObject(%this)
{
	return %this.objectList[%this.objectCount - 1];
}

function FileBrowserTCP::constructPage(%this)
{
	// Delete existing page contents
	FileBrowser.UI_PAGE_CONTENT.deleteAll();
	FileBrowser.UI_PAGE_CONTENT.fillColor = "255 255 255 255";
	
	// Build the page
	for (%i = 0; %i < %this.lineCount; %i++)
	{
		%action = getWord(%this.lines[%i], 0);
		%data   = removeWord(%this.lines[%i], 0);
		
		// Parse this action
		switch$ (%action)
		{
			case "ERROR":
				error("FileBrowser ERROR: " @ %data);
			
			case "BACKCOLOR":
				FileBrowser.UI_PAGE_CONTENT.fillColor = %data;
				
			case "AUTOHEIGHT":
				if (!isObject(%cObj = %this.getCurrentObject()))
					continue;
				
				Canvas.repaint();
				%size = 8;
				for (%j = 0; %j < %cObj.getCount(); %j++)
				{
					%child  = %cObj.getObject(%j);
					%bottom = getWord(%child.getPosition(), 1) + getWord(%child.getExtent(), 1);
					
					if (%bottom > %size)
						%size = %bottom;
				}
				
				%cObj.setExtent(getWord(%cObj.getExtent(), 0), %size);
			
			case "START":
				%objType = getWord(%data, 0);
				%pos_x   = getWord(%data, 1);
				%pos_y   = getWord(%data, 2);
				%ext_x   = getWord(%data, 3);
				%ext_y   = getWord(%data, 4);
				
				// Create the new object
				%this.startObject(%objType, %pos_x, %pos_y, %ext_x, %ext_y);
				
			case "PROPERTY":
				%fieldName  = getField(%data, 0);
				%fieldValue = getField(%data, 1);
				
				if (!isObject(%cObj = %this.getCurrentObject()) || strLwr(%fieldName) $= "command" || strLwr(%fieldName) $= "altcommand" || strLwr(%fieldName) $= "accelerator")
					continue;
				
				%cObj.setFieldValue(%fieldName, %fieldValue);
				
			case "TEXT":
				if (!isObject(%cObj = %this.getCurrentObject()) || !isFunction(%cObj.getClassName(), "SetText"))
					continue;
				
				%cObj.setText(%data);
				
			case "END":
				%this.endObject();
				
			default:
				error("FileBrowser ERROR: Invalid action \"" @ %action @ "\"");
		}
	}
	
	// Resize control
	%size    = FileBrowser.UI_PAGE_CONTENT.getGroup().getExtent();
	%scrSize = %size;
	%lowestY = getWord(%size, 1);
	%size    = (getWord(%size, 0) - 15) SPC (getWord(%size, 1) - 15);
	
	for (%i = 0; %i < FileBrowser.UI_PAGE_CONTENT.getCount(); %i++)
	{
		%child  = FileBrowser.UI_PAGE_CONTENT.getObject(%i);
		%top    = getWord(%child.getPosition(), 1);
		%right  = getWord(%child.getPosition(), 0) + getWord(%child.getExtent(), 0);
		%bottom = %top + getWord(%child.getExtent(), 1);
		
		if (%top < %lowestY)
			%lowestY = (%top < 0 ? 0 : %top);
		
		if (%right > getWord(%size, 0))
			%size = setWord(%size, 0, %right);
		
		if (%bottom > getWord(%size, 1))
			%size = setWord(%size, 1, %bottom);
	}
	
	FileBrowser.UI_PAGE_CONTENT.setExtent(getWord(%size, 0), (getWord(%size, 1) == getWord(%scrSize, 1) ? getWord(%scrSize, 1) : getWord(%size, 1) + %lowestY));
}

function FileBrowserTCP::parsePage(%this)
{
	%TOK_SYMBOLS    = "\\\t/\t<\t>\t\"\t=\t";
	%TOK_WHITESPACE = " \t\r\n";
	
	// Tokenize everything
	for (%i = 0; %i < %this.lineCount; %i++)
	{
		%line = %this.lines[%i];
		
		// Parse line
		for (%j = 0; %j < strLen(%line); %j++)
		{
			%chr  = getSubStr(%line, %j, 1);
			%type = "NAME";
			
			// Find this chr among tables
			%SYMBOL_POS     = getFieldPos(%TOK_SYMBOLS, %chr);
			%WHITESPACE_POS = strPos(%TOK_WHITESPACE, %chr);
			
			// Determine this chr's type
			if (%SYMBOL_POS != -1)
				%type = "CHAR";
			else if (%inElement && %WHITESPACE_POS != -1)
			{
				%token[-1 + %tokenCount++] = "PLACEHOLDER";
				continue;
			}
			
			// Parsing here
			if (%inElement)
			{
				if (%type $= "CHAR" && getField(%TOK_SYMBOLS, %SYMBOL_POS) $= "\"")
				{
					// Get all text
					%text = "";
					for (%j++; %j < strLen(%line); %j++)
					{
						if (getSubStr(%line, %j, 1) $= "\\")
						{
							if (getSubStr(%line, %j + 1, 1) $= "\"")
								%text = %text @ "\"";
							else if (getSubStr(%line, %j + 1, 1) $= "\\")
								%text = %text @ "\\";
							
							continue;
						}
						else if (getSubStr(%line, %j, 1) $= "\"")
						{
							break;
						}
						
						%text = %text @ getSubStr(%line, %j, 1);
					}
					
					%type = "NAME";
					%chr  = %text;
				}
			}
			else if (%type $= "CHAR" && getField(%TOK_SYMBOLS, %SYMBOL_POS) !$= "<")
				%type = "NAME";
			
			if (%type $= "CHAR" && getField(%TOK_SYMBOLS, %SYMBOL_POS) $= "<")
				%inElement = true;
			else if (%type $= "CHAR" && getField(%TOK_SYMBOLS, %SYMBOL_POS) $= "<")
				%inElement = false;
			
			// Determine what to do with it
			if (getWord(%token[%tokenCount - 1], 0) $= "PLACEHOLDER")
				%token[%tokenCount - 1] = %type SPC %chr;
			else if (getWord(%token[%tokenCount - 1], 0) $= "NAME" && %type $= "NAME")
				%token[%tokenCount - 1] = %token[%tokenCount - 1] @ %chr;
			else
				%token[-1 + %tokenCount++] = %type SPC %chr;
		}
	}
	
	// Reset vars
	%this.instCount = 0;
	%inElement      = false;
	%closeElement   = false;
	%elementName    = "";
	%yOffset        = 0;
	
	// Parse tokens
	for (%i = 0; %i < %tokenCount; %i++)
	{
		%tokType  = getWord(%token[%i], 0);
		%tokValue = removeWord(%token[%i], 0);
		
		if (%inElement)
		{
			if (%tokType $= "CHAR" && %tokValue $= ">")
			{
				%this.inst[-1 + %this.instCount++] = (%closeElement ? "END" : "START" SPC strUpr(%elementName));
				
				%inElement    = false;
				%elementName  = "";
				%closeElement = false;
				continue;
			}
			
			if (%tokType $= "CHAR" && %tokValue $= "/" && %elementName $= "")
				%closeElement = true;
			else if (%tokType $= "NAME" && %elementName $= "")
				%elementName = %tokValue;
		}
		else if (%tokType $= "CHAR" && %tokValue $= "<")
		{
			%inElement = true;
		}
		else if (%tokType $= "NAME")
		{
			
		}
	}
	
	// Done!
	%this.constructPage();
}

function FileBrowser::update(%this)
{
	%connecting = !isObject(%this.TCP) ? false : %this.TCP.connecting;
	%this.UI_BTN_REFRESH.setActive(!%val);
	%this.UI_BTN_NEXT_PAGE.setActive(%val ? false : (%this.historyCount && %this.historyIndex != %this.historyCount - 1));
	%this.UI_BTN_PREV_PAGE.setActive(%val ? false : (%this.historyCount && %this.historyIndex != 0));
}

//----------------------------------------------------------------------------------------------------

function FileBrowserText::onURL(%this, %url)
{
	FileBrowser.LoadPage(%url);
}

//----------------------------------------------------------------------------------------------------

function FileBrowserTCP::setIsConnecting(%this, %val)
{
	%this.connecting = %val;
	FileBrowser.Update();
}

function FileBrowserTCP::onConnectFailed(%this)
{
	%this.setIsConnecting(false);
}

function FileBrowserTCP::onDNSFailed(%this)
{
	%this.setIsConnecting(false);
}

function FileBrowserTCP::onDisconnect(%this)
{
	%this.setIsConnecting(false);
	//%this.parsePage();
	%this.constructPage();
}

function FileBrowserTCP::onConnected(%this)
{
	%this.send(%this.cmd);
}

function FileBrowserTCP::onLine(%this, %line)
{
	if (%this.headers)
	{
		if (%line $= "")
			%this.headers = false;
		
		return;
	}
	
	if (trim(%line) $= "")
		return;
	
	%this.lines[-1 + %this.lineCount++] = ltrim(%line);
}

//----------------------------------------------------------------------------------------------------

if (!isObject(FileBrowser))
	new ScriptObject(FileBrowser);