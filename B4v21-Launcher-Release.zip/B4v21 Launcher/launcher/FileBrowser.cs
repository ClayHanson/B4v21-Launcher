function FileBrowser_Clear()
{
	versionManagerGui.fileList.deleteAll();
}

function FileBrowser_AddFile(%fileId, %fileTitle, %fileName, %fileUploader, %fileCompatibleVersions)
{
	%statusIndex  = 5;
	%installCount = 0;
	
	// Determine all the installations that have this file installed
	for (%i = 0; %i < VerGroup.getCount(); %i++)
	{
		%ver = VerGroup.getObject(%i);
		if (!isFile(strReplace(%ver.path, "\\", "/") @ "Add-Ons/" @ %fileName))
			continue;
		
		echo(%ver.version SPC %fileCompatibleVersions);
		%install[-1 + %installCount++] = %ver;
	}
	
	// Create the entry
	%obj = new GuiBitmapBorderCtrl()
	{
		canSaveDynamicFields = "0";
		Profile = "GuiBitmapBorderProfile";
		HorizSizing = "right";
		VertSizing = "bottom";
		position = "0 0";
		Extent = "388 44";
		MinExtent = "8 44";
		canSave = "1";
		Visible = "1";
		hovertime = "1000";
		bitmap = "launcher/ui/content-box.png";
		index = "0";
		stretch = "0";
		flip = "0";
		color = "240 240 240 255";
		spin = "0";
		file_id       = %fileId;
		file_name     = %fileName;
		file_title    = %fileTitle;
		file_uploader = %fileUploader;
		file_versions = strReplace(%fileCompatibleVersions, ", ", " ");
		file_status   = %statusIndex;
		
		new GuiTextCtrl()
		{
			canSaveDynamicFields = "0";
			Profile     = "FileBrowserTextHeaderProfile";
			HorizSizing = "width";
			VertSizing  = "bottom";
			position    = "26 6";
			Extent      = "328 18";
			MinExtent   = "8 2";
			canSave     = "1";
			Visible     = "1";
			hovertime   = "1000";
			text        = %fileTitle;
			maxLength   = "1024";
			scroll      = "1";
		};
		new GuiBitmapArrayCtrl()
		{
			canSaveDynamicFields = "0";
			Profile     = "GuiDefaultProfile";
			HorizSizing = "right";
			VertSizing  = "bottom";
			position    = "6 6";
			Extent      = "16 16";
			MinExtent   = "8 2";
			canSave     = "1";
			Visible     = "1";
			hovertime   = "1000";
			bitmap      = "launcher/ui/file-mgr-icons.png";
			index       = "7";
			stretch     = "1";
			flip        = "0";
			color       = "255 255 255 255";
			spin        = "0";
		};
		new GuiTextCtrl()
		{
			canSaveDynamicFields = "0";
			Profile     = "FileBrowserTextHeaderProfile";
			HorizSizing = "width";
			VertSizing  = "top";
			position    = "10 22";
			Extent      = "206 18";
			MinExtent   = "8 2";
			canSave     = "1";
			Visible     = "1";
			hovertime   = "1000";
			text        = "Uploaded by" SPC %fileUploader;
			maxLength   = "1024";
			scroll      = "1";
		};
		new GuiBitmapArrayCtrl()
		{
			canSaveDynamicFields = "0";
			Profile     = "GuiDefaultProfile";
			HorizSizing = "left";
			VertSizing  = "top";
			position    = "365 22";
			Extent      = "16 16";
			MinExtent   = "8 2";
			canSave     = "1";
			Visible     = "1";
			hovertime   = "1000";
			bitmap      = "launcher/ui/file-mgr-icons.png";
			index       = %statusIndex;
			stretch     = "1";
			flip        = "0";
			color       = "255 255 255 255";
			spin        = "0";

			new GuiMouseEventCtrl()
			{
				canSaveDynamicFields = "0";
				class = "FileBrowserMiniButton";
				Profile = "GuiDefaultProfile";
				HorizSizing = "right";
				VertSizing = "bottom";
				position = "0 0";
				Extent = "16 16";
				MinExtent = "8 2";
				canSave = "1";
				command = "FileBrowser_GetStatus(\"" @ %fileId @ "\");";
				Visible = "1";
				hovertime = "1000";
				lockMouse = "0";
			};
		};
		new GuiBitmapArrayCtrl()
		{
			canSaveDynamicFields = "0";
			Profile = "GuiDefaultProfile";
			HorizSizing = "left";
			VertSizing = "bottom";
			position = "365 6";
			Extent = "16 16";
			MinExtent = "8 2";
			canSave = "1";
			Visible = "1";
			hovertime = "1000";
			bitmap = "launcher/ui/file-mgr-icons.png";
			index = "4";
			stretch = "1";
			flip = "0";
			color = "255 255 255 255";
			spin = "0";

			new GuiMouseEventCtrl()
			{
				canSaveDynamicFields = "0";
				class = "FileBrowserMiniButton";
				Profile = "GuiDefaultProfile";
				HorizSizing = "right";
				VertSizing = "bottom";
				position = "0 0";
				Extent = "16 16";
				MinExtent = "8 2";
				canSave = "1";
				Visible = "1";
				hovertime = "1000";
				lockMouse = "0";
			};
		};
		new GuiSwatchCtrl()
		{
			canSaveDynamicFields = "0";
			Profile = "GuiDefaultProfile";
			internalName = "resizeme";
			HorizSizing = "right";
			VertSizing = "bottom";
			position = "360 6";
			Extent = "1 32";
			MinExtent = "1 1";
			canSave = "1";
			Visible = "1";
			hovertime = "1000";
			fill = "1";
			border = "0";
			fillColor = "219 219 219 255";
			borderColor = "0 0 0 255";
		};
		new GuiTextCtrl()
		{
			canSaveDynamicFields = "0";
			Profile = "FileBrowserTextVersionProfile";
			HorizSizing = "left";
			VertSizing = "top";
			position = "213 22";
			Extent = "142 18";
			MinExtent = "8 2";
			canSave = "1";
			Visible = "1";
			hovertime = "1000";
			text = %fileCompatibleVersions;
			maxLength = "1024";
			scroll = "1";
		};
		new GuiButtonBaseCtrl()
		{
			canSaveDynamicFields = "0";
			Profile = "GuiDefaultProfile";
			HorizSizing = "width";
			VertSizing = "height";
			position = "0 0";
			Extent = "357 44";
			MinExtent = "8 2";
			canSave = "1";
			Visible = "1";
			hovertime = "1000";
			pitch = "1";
			text = " ";
			groupNum = "-1";
			buttonType = "PushButton";
		};
	};
	
	%obj.findObjectByInternalName("resizeme", true).resize(360, 6, 1, 32);
	
	versionManagerGui.fileList.add(%obj);
}

//=====================================================================================================================================================================//

function findFileById(%id)
{
	for (%i = 0; %i < versionManagerGui.fileList.getCount(); %i++)
	{
		%file = versionManagerGui.fileList.getObject(%i);
		if (%file.file_id != %id)
			continue;
		
		return %file;
	}
	
	return -1;
}

//=====================================================================================================================================================================//

function FileBrowserMiniButton::onMouseEnter(%this)
{
	%this.getGroup().color = "255 255 255 255";
}

function FileBrowserMiniButton::onMouseLeave(%this)
{
	%this.getGroup().color = "230 230 230 255";
}

function FileBrowserMiniButton::onMouseUp(%this)
{
	%this.getGroup().color = "255 255 255 255";
	eval(strReplace(%this.command, "\"", "\\\""));
}

function FileBrowserMiniButton::onMouseDown(%this)
{
	%this.getGroup().color = "243 243 243 255";
}

//=====================================================================================================================================================================//

function FileBrowser_QueryFiles()
{
	if (isObject(FilesTcpObj))
		return;
	
	MessagePopup("Please Wait - B4v21 Launcher", "Querying B4v21 services...");
	
	%tcp     = new TCPObject(FilesTcpObj);
	%tcp.cmd = "POST /api/v1/getFiles.php HTTP/1.0\r\nHost: b4v21.block.land\r\nConnection: close\r\n\r\n";
	%tcp.connect("b4v21.block.land:80");
}

function FilesTcpObj::onDNSFailed(%this)
{
	CloseMessagePopup();
	%this.schedule(1, delete);
}

function FilesTcpObj::onConnectFailed(%this)
{
	CloseMessagePopup();
	%this.schedule(1, delete);
}

function FilesTcpObj::onConnected(%this)
{
	MessagePopup("Please Wait - B4v21 Launcher", "Awaiting response...");
	FileBrowser_Clear();
	%this.send(%this.cmd);
}

function FilesTcpObj::onDisconnect(%this)
{
	CloseMessagePopup();
	%this.schedule(1, delete);
}

function FilesTcpObj::onLine(%this, %line)
{
	%action = getField(%line, 0);
	%args   = removeField(%line, 0);
	
	switch$(%action)
	{
		case "ERROR":
			CloseMessagePopup();
			messageBoxOk("ERROR - B4v21 Launcher", "This service returned an error:\n\n\"" @ %args @ "\"");
		
		case "FILE":
			%file_id        = getField(%args, 0);
			%file_title     = getField(%args, 1);
			%file_uploader  = getField(%args, 2);
			%file_downloads = getField(%args, 3);
			%file_name      = getField(%args, 4);
			%file_verList   = getField(%args, 5);
			
			FileBrowser_AddFile(%file_id, %file_title, %file_name, %file_uploader, %file_verList);
	}
}