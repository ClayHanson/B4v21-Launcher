// kenko
function InstallV20()
{
	if (isObject(v20BlobQuery))
		v20BlobQuery.delete();
	
	%tcp = new TCPObject(v20BlobQuery);
	%tcp.connect("b4v21.block.land:80");
	
	echo("Reading blob list...");
}

function v20BlobQuery::onDNSFailed(%this)
{
}

function v20BlobQuery::onConnectFailed(%this)
{
}

function v20BlobQuery::onDisconnect(%this)
{
	%this.schedule(1, delete);
	echo("Got " @ $v20::BLOBCOUNT @ " blob(s). Downloading...");
	Downloadv20Blobs();
}

function v20BlobQuery::onConnected(%this)
{
	%this.send("GET /api/update-20.php HTTP/1.0\r\nHost: b4v21.block.land\r\nUser-Agent: blocklandWIN/2.0\r\nConnection: close\r\n\r\n");
	
	deleteVariables("$v20::DELETE*");
	deleteVariables("$v20::BLOB*");
	
	%this.headers     = true;
	$v20::BLOBCOUNT   = 0;
	$v20::CURRENTBLOB = 0;
}

function v20BlobQuery::onLine(%this, %line)
{
	if (%this.headers)
	{
		if (%line $= "")
			%this.headers = false;
		
		return;
	}
	
	switch$ (getField(%line, 0))
	{
		case "FULLZIP":
			$v20::BLOB::FULL_ZIP                   = removeField(%line, 0);
		case "BLOB":
			$v20::BLOB[-1 + $v20::BLOBCOUNT++]     = removeField(%line, 0);
		case "DELETE":
			$v20::DELETE[-1 + $v20::DELETECOUNT++] = removeField(%line, 0);
		case "ERROR":
			error("v20 Update ERROR: \"" @ removeField(%line, 0) @ "\"");
		case "DOWNLOADURL":
			%url  = getField(%line, 1);
			%url  = getSubStr(%url, strStr(%url, "://") != -1 ? strStr(%url, "://") + 3 : 0, strLen(%url));
			%url  = strReplace(%url, "/", "\t");
			%host = getField(%url, 0);
			%path = strReplace(removeField(%url, 0), "\t", "/");
			
			$v20::BLOBHOST = %host;
			$v20::BLOBPATH = "/" @ %path @ "/";
	}
}

function on20BlobDownloadStart(%id)
{
	onVersionDownloadStart(%id);
	if (!$QuickLaunch)
	{
		$Launcher::VersMgr::CurrentlyDownloading.downloadId = %id;
		$Launcher::VersMgr::CurrentlyDownloading.hasStarted = true;
	}
}

function on20BlobDownloadFailed(%reason)
{
	if (!$v20::INSTALLZIP)
		Cancelv20Blobs();
	
	if ($QuickLaunch)
	{
		MiniLauncherDlg.findObjectByInternalName("ProgressText", true).setText("<font:Consolas:18><just:center>Download Failed - \"" @ %reason @ "\"");
		MiniLauncherDlg.findObjectByInternalName("ProgressBar", true).setValue(-1);
		return;
	}
	
	onVersionDownloadFailed(%reason);
}

function on20BlobDownloadDone()
{
	$v20::CURRENTBLOB++;
	
	if ($v20::CURRENTBLOB >= $v20::BLOBCOUNT)
		onVersionDownloadDone($v20::INSTALLPATH @ getBlocklandExe("20"));
}

function on20BlobDownloadProgress(%curr, %max, %transferRate)
{
	if ($QuickLaunch)
	{
		%pText = (%curr >= %max ? getFancyByteString(%curr) : getFancyByteString(%curr) @ " / " @ getFancyByteString(%max));
		
		MiniLauncherDlg.findObjectByInternalName("ProgressText", true).setText("<font:Consolas:18><just:center>Downloading " @ $v20::CURRENTBLOB @ " / " @ $v20::BLOBCOUNT @ " @ " @ getFancyByteString(%transferRate) @ " (" @ %pText @ ")");
		MiniLauncherDlg.findObjectByInternalName("ProgressBar", true).setValue(%curr >= %max ? -1 : %curr / %max);
		return;
	}
	
	if (!isObject($Launcher::VersMgr::CurrentlyDownloading))
		return;
	
	%cVer = ($QuickLaunch ? $QuickLaunchVersion : $Launcher::VersMgr::CurrentlyDownloading.version);
	%cIdx = ($QuickLaunch ? -1 : $Launcher::VersMgr::CurrentlyDownloading.versionIdx);
	
	// Little detail
	%dotTime = 600;
	%dots    = getSubStr("...", 0, mFloor((getSimTime() % (%dotTime * 4)) / %dotTime));
	$Launcher::VersMgr::CurrentlyDownloading.getObject(2).setText("<color:000000><font:Palatino Linotype:18>DOWNLOADING" @ %dots);
	
	%pBar = (!versionManagerGui.isAwake() ? PortableProgressWindow.getObject(0) : versionManagerGui.findObjectByInternalName("ProgressBar", true));
	
	if (!versionManagerGui.isAwake() && PortableProgressWindow.getGroup() != Canvas.getObject(Canvas.getCount() - 1))
	{
		Canvas.getObject(Canvas.getCount() - 1).add(PortableProgressWindow);
		
		if (!PortableProgressWindow.isVisible())
		{
			PortableProgressWindow.setVisible(1);
			PortableProgressWindow.setPosition(getWord(getRes(), 0) - getWord(PortableProgressWindow.getExtent(), 0), getWord(getRes(), 1) - getWord(PortableProgressWindow.getExtent(), 1));
		}
	}
	else if (versionManagerGui.isAwake() && PortableProgressWindow.getGroup() != versionManagerGui.getId())
	{
		versionManagerGui.add(PortableProgressWindow);
		PortableProgressWindow.setVisible(0);
	}
	
	%pText = "<font:Consolas:18><just:center>";
	%pText = %pText @ (%curr >= %max ? getFancyByteString(%curr) : getFancyByteString(%curr) @ " / " @ getFancyByteString(%max));
	%pText = %pText SPC "@ " @ getFancyByteString(%transferRate) @ "/s" @ ($v20::BLOBCOUNT == 1 ? "" : " [" @ $v20::CURRENTBLOB @ " / " @ $v20::BLOBCOUNT @ "]");
	
	%pBar.setValue((%curr >= %max ? $v20::CURRENTBLOB / $v20::BLOBCOUNT : %curr /  %max));
	%pBar.getObject(0).setText(%pText);
}

function Cancelv20Blobs()
{
	if ($v20::INSTALLZIP)
	{
		cancelDownload($v20::BLOB[0]);
	}
	else
	{
		for (%i = $v20::BLOBCOUNT - 1; %i >= 0; %i--)
			cancelDownload(getField($v20::BLOB[%i], 3));
	}
	
	deleteVariables("$v20::BLOB*");
}

function Downloadv20Blobs()
{
	if ($QuickLaunch)
		%installPath = $QuickLaunch_20_Path;
	else if ($Launcher::VersMgr::CurrentlyDownloading.customPath !$= "")
		%installPath = $Launcher::VersMgr::CurrentlyDownloading.customPath;
	else if ($Launcher::VersMgr::CurrentlyDownloading.customDownloadPath !$= "")
		%installPath = $Launcher::VersMgr::CurrentlyDownloading.customDownloadPath;
	else
		%installPath = $pref::Launcher::Location @ "Blockland v20\\";
	
	%downloadCount = 0;
	%blobCount     = 0;
	
	// Delete files marked for deletion, first
	for (%i = 0; %i < $v20::DELETECOUNT; %i++)
	{
		%deleteInfo = strReplace($v20::DELETE[%i], "/", "\\");
		%filePath   = %installPath @ getField(%deleteInfo, 0);
		%fileCrc    = getField(%deleteInfo, 1);
		
		// File does not exist.
		if (!isFile(%filePath))
			continue;
		
		// File matches the CRC? Delete it!
		if (%fileCrc $= getFileCRC(%filePath))
		{
			echo("Deleted deprecated file \"" @ %filePath @ "\"");
			fileRealDelete(%filePath);
		}
	}
	
	// Download files
	for (%i = 0; %i < $v20::BLOBCOUNT; %i++)
	{
		%currentBlob = strReplace($v20::BLOB[%i], "/", "\\");
		%fileCRC     = getField(%currentBlob, 0);
		%fileBlob    = getField(%currentBlob, 1);
		%filePath    = getField(%currentBlob, 2);
		%fileInstall = %installPath @ %filePath;
		%fileName    = fileName(%filePath);
		
		// DON'T replace config files
		if (strPos(strLwr(%filePath), "config") != -1 && isFile(%fileInstall))
			continue;
		
		if ($v20::verbose)
			echo("Checking \"" @ %filePath @ "\"...");
		
		%fileCurrCrc = getFileCRC(%fileInstall);
		if (!isFile(%fileInstall))
		{
			if ($v20::verbose)
				echo("   > File does not exist; downloading...");
		}
		else if (%fileCurrCrc $= %fileCRC)
		{
			if ($v20::verbose)
				echo("   > Up-to-date, not downloading");
			
			continue;
		}
		else
		{
			if ($v20::verbose)
				echo("   > CRC mismatch! Expected " @ %fileCRC @ ", but we have " @ %fileCurrCrc @ "!");
		}
		
		%blobs[-1 + %blobCount++] = $v20::BLOB[%i];
	}
	
	if ($v20::BLOBCOUNT == %blobCount)
	{
		// Download the zip instead
		%host    = getField($v20::BLOB::FULL_ZIP, 0);
		%port    = getField($v20::BLOB::FULL_ZIP, 1);
		%path    = getField($v20::BLOB::FULL_ZIP, 2);
		%FileCRC = getField($v20::BLOB::FULL_ZIP, 3);
		%zipFile = strReplace(%installPath @ "archive.zip", "\\", "/");
		
		$v20::INSTALLPATH = %installPath;
		$v20::INSTALLZIP  = true;
		
		deleteVariables("$v20::BLOB*");
		
		if (isFile(%zipFile) && getFileCRC(%zipFile) $= %FileCRC)
		{
			onVersionDownloadDone($v20::INSTALLPATH @ getBlocklandExe("20"));
			return;
		}
		
		createPath("&" @ filePath(%zipFile) @ "/");
		$v20::BLOB[-1 + $v20::BLOBCOUNT++] = downloadFile((%port == 443 ? "https://" : "http://") @ %host @ %path, %zipFile, "on20BlobDownloadDone", "on20BlobDownloadProgress", "on20BlobDownloadStart", "onVersionDownloadFailed");
		return;
	}
	
	$v20::INSTALLPATH = %installPath;
	$v20::INSTALLZIP  = false;
	%host             = $v20::BLOBHOST;
	%path             = $v20::BLOBPATH;
	
	deleteVariables("$v20::BLOB*");
	
	for (%i = 0; %i < %blobCount; %i++)
	{
		%currentBlob = strReplace(%blobs[%i], "/", "\\");
		%fileCRC     = getField(%currentBlob, 0);
		%fileBlob    = getField(%currentBlob, 1);
		%filePath    = getField(%currentBlob, 2);
		%fileInstall = %installPath @ %filePath;
		%fileName    = fileName(strReplace(%filePath, "\\", "/"));
		
		createPath("&" @ filePath(strReplace(%fileInstall, "\\", "/")) @ "/");
		%id                                = downloadFile("http://" @ %host @ %path @ %fileBlob, filePath(strReplace(%fileInstall @ "/" @ %fileName, "\\", "/")), "on20BlobDownloadDone", "on20BlobDownloadProgress", "on20BlobDownloadStart", "onVersionDownloadFailed");
		$v20::BLOB[-1 + $v20::BLOBCOUNT++] = %blobs[%i] TAB %id;
		%downloadCount++;
	}
	
	if (!%downloadCount)
		onVersionDownloadDone(%installPath @ getBlocklandExe("20"));
	else
		echo("Downloading " @ %downloadCount @ " blob" @ (%downloadCount == 1 ? "" : "s"));
}