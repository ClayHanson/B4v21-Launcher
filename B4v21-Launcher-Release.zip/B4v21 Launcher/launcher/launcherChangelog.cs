function fetchLauncherChangelog()
{
	lChangeGui.catList.clearEntries();
	
	if (isObject(%o = LauncherChangelogTCP))
		%o.delete();
	
	%toPost = "VERSION=" @ $lChangeGui::UpdateVersion;
	%o      = new TCPObject(LauncherChangelogTCP);
	%o.site = "b4v21.block.land";
	%o.port = 80;
	%o.cmd  = "POST /api/changeLogs.php HTTP/1.1\r\nUser-Agent: B4v21Launcher-v" @ getLauncherVersion() @ "\r\nHost: " @ %o.site @ "\r\nConnection: close\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: " @ strLen(%toPost) @ "\r\n\r\n" @ %toPost @ "\r\n";
	%o.connect(%o.site @ ":" @ %o.port);
}

function LauncherChangelogTCP::onConnectFailed(%this)
{
	error("ERROR: Launcher Changelog TCP General Connection Failure!");
	lChangeGui.loadBanner.setVisible(false);
}

function LauncherChangelogTCP::onDNSFailed(%this)
{
	error("ERROR: Launcher Changelog TCP DNS Lookup Failed!");
	lChangeGui.loadBanner.setVisible(false);
}

function LauncherChangelogTCP::onDisconnect(%this)
{
	lChangeGui.catList.stopTransition();
	lChangeGui.loadBanner.setVisible(false);
}

function LauncherChangelogTCP::onConnected(%this)
{
	%this.send(%this.cmd);
}

function LauncherChangelogTCP::onLine(%this, %line)
{
	%act  = getField(%line, 0);
	%line = removeField(%line, 0);
	
	if ($ChangeLog::CLog)
	{
		if (%act $= "END")
		{
			$ChangeLog::CLog = false;
			return;
		}
		
		$ChangeLog::Line[-1 + $ChangeLog::Count++] = %act;
		return;
	}
	
	switch$(%act)
	{
		case "NONE":
		case "FAIL":
			error("Launcher Changelog Error: \"" @ %line @ "\"");
			messageBoxOk("ERROR", "This service reported an error:<br><br>\"" @ %line @ "\"", "Canvas.popDialog(lChangeGui);");
			
		case "START":
			deleteVariables("$ChangeLog*");
			$ChangeLog::CLog = true;
			
		case "CLOG":
			%date    = getField(%line, 0);
			%version = getField(%line, 1);
			%verID   = "--ver-" @ %version;
			%first   = lChangeGui.catList.getEntryCount() == 0;
			
			lChangeGui.catList.addEntry(%verID, getBlocklandName($lChangeGui::UpdateVersion) SPC "v" @ %version @ " @ " @ %date);
			lChangeGui.catList.setEntryColors(%verID, "255 255 255 255", "105 106 106 255");
			
			for (%i = 0; %i < $ChangeLog::Count; %i++)
			{
				lChangeGui.catList.addEntry(%verID @ "-" @ %i, $ChangeLog::Line[%i], %verID);
				lChangeGui.catList.setEntryColors(%verID @ "-" @ %i, "0 0 0 255", "0 0 0 0", "255 255 255 255");
			}
			
			if (!%first)
				lChangeGui.catList.setEntryExpanded(%verID, false);
			
			// Stop the transition
			lChangeGui.catList.stopTransition();
	}
}

function lChangeGui::onWake(%this)
{
	%this.catList    = %this.findObjectByInternalName("CatList", true);
	%this.scroll     = %this.catList.getGroup();
	%this.loadBanner = %this.findObjectByInternalName("loadBanner", true);
	%this.updateBtn  = %this.findObjectByInternalName("UpdateBtn", true);
	%this.quitBtn    = %this.findObjectByInternalName("QuitBtn", true);
	%this.window     = %this.findObjectByInternalName("Wind", true);
	
	%forced                  = $lChangeGui::ForceUpdate;
	%this.window.canClose    = !%forced;
	%this.window.Command     = %forced ? "" : "Canvas.popDialog(lChangeGui);";
	%this.window.Accelerator = %forced ? "" : "escape";
	%this.quitBtn.text       = !$lChangeGui::CanBackOut ? "<< Quit" : "<< Back";
	%this.loadBanner.setVisible(true);
	%this.window.setValue(%forced ? "Update Available for " @ getBlocklandName($lChangeGui::UpdateVersion) @ "!" : getBlocklandName($lChangeGui::UpdateVersion) @ " Changelogs");
	%this.updateBtn.setVisible(%forced);
	%this.quitBtn.setVisible(%forced);
	%this.loadBanner.setExtent(getWord(%this.scroll.getExtent(), 0), (getWord(%this.window.getExtent(), 1) - (%forced ? 100 : 50)));
	%this.scroll.setExtent(getWord(%this.scroll.getExtent(), 0), (getWord(%this.window.getExtent(), 1) - (%forced ? 100 : 50)));
	
	// Center the window
	%this.window.setPosition((getWord(getRes(), 0) / 2) - (getWord(%this.window.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%this.window.getExtent(), 1) / 2));
	
	fetchLauncherChangelog();
}

function lChangeGui::onSleep(%this)
{
	if (isObject(%o = LauncherChangelogTCP))
		%o.delete();
}

function lChangeGui::Exit(%this)
{
	if ($lChangeGui::CanBackOut)
		Canvas.popDialog(lChangeGui);
	else
		messageBoxYesNo("Confirmation", "Are you sure you want to quit?", "quit();");
}

function lChangeGui::Update(%this)
{
	Canvas.popDialog(%this);
	eval($lChangeGui::UpdateEval);
}