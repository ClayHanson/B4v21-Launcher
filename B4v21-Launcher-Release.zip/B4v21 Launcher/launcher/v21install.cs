// kenko
function InstallV21() {
	if(isObject(v21BlobQuery)) v21BlobQuery.delete();
	%tcp = new TCPObject(v21BlobQuery);
	%tcp.connect("update.blockland.us:80");
	
	echo("Reading blob list...");
}

function v21BlobQuery::onDNSFailed(%this) {
}

function v21BlobQuery::onConnectFailed(%this) {
}

function v21BlobQuery::onDisconnect(%this) {
	%this.schedule(1, delete);
	echo("Got " @ $V21::BLOBCOUNT @ " blob(s). Downloading...");
	DownloadBlobs();
}

function v21BlobQuery::onConnected(%this) {
	%this.send("GET /latestVersion.php HTTP/1.0\r\nHost: update.blockland.us\r\nUser-Agent: blocklandWIN/2.0\r\nConnection: close\r\n\r\n");
	
	deleteVariables("$V21::BLOB*");
	
	%this.headers     = true;
	$V21::BLOBCOUNT   = 0;
	$V21::CURRENTBLOB = 0;
}

function v21BlobQuery::onLine(%this, %line) {
	if(%this.headers) {
		if(%line $= "") %this.headers = false;
		return;
	}
	
	if(getField(%line, 0) $= "DOWNLOADURL") {
		%url  = getField(%line, 1);
		%url  = getSubStr(%url, strStr(%url, "://") != -1 ? strStr(%url, "://") + 3 : 0, strLen(%url));
		%url  = strReplace(%url, "/", "\t");
		%host = getField(%url, 0);
		%path = strReplace(removeField(%url, 0), "\t", "/");
		
		$V21::BLOBHOST = %host;
		$V21::BLOBPATH = "/" @ %path @ "/";
		return;
	}
	
	$V21::BLOB[-1 + $V21::BLOBCOUNT++] = %line; // "name" TAB "hash"
}

function onBlobDownloadStart(%id) {
	onVersionDownloadStart(%id);
	$Launcher::VersMgr::CurrentlyDownloading.downloadId = %id;
}

function onBlobDownloadDone() {
	%queryObj = $Launcher::VersMgr::CurrentlyDownloading;
	$V21::CURRENTBLOB++;
	
	if($V21::CURRENTBLOB >= $V21::BLOBCOUNT) onVersionDownloadDone("lol");
}

function onBlobDownloadProgress(%curr, %max) {
	%cVer = $Launcher::VersMgr::CurrentlyDownloading.version;
	%cIdx = $Launcher::VersMgr::CurrentlyDownloading.versionIdx;
	
	if(getSimTime() - $Launcher::Installer::LastAvgTime >= 1000) {
		$Launcher::Installer::LastAvgTime = getSimTime();
		$Launcher::VersionInstallingCurr = %curr;
		
		if($Launcher::Installer::AvgSize !$= "") {
			for(%i=0;%i<$Launcher::Installer::AvgSize;%i++) %sum += $Launcher::Installer::Avg[%i];
			%sum /= $Launcher::Installer::AvgSize;
			
			deleteVariables("$Launcher::Installer::Avg*");
			$Launcher::Installer::AvgTransferRate = %sum;
		}
	}
	
	// Little detail
	%dotTime = 600;
	%dots = getSubStr("...", 0, mFloor((getSimTime() % (%dotTime * 4)) / %dotTime));
	$Launcher::VersMgr::CurrentlyDownloading.getObject(2).setText("<color:000000><font:Palatino Linotype:18>DOWNLOADING" @ %dots);
	
	%pBar = (!versionManagerGui.isAwake() ? PortableProgressWindow.getObject(0) : versionManagerGui.findObjectByInternalName("ProgressBar", true));
	
	if(!versionManagerGui.isAwake() && PortableProgressWindow.getGroup() != Canvas.getObject(Canvas.getCount() - 1)) {
		Canvas.getObject(Canvas.getCount() - 1).add(PortableProgressWindow);
		
		if(!PortableProgressWindow.isVisible()) {
			PortableProgressWindow.setVisible(1);
			PortableProgressWindow.setPosition(getWord(getRes(), 0) - getWord(PortableProgressWindow.getExtent(), 0), getWord(getRes(), 1) - getWord(PortableProgressWindow.getExtent(), 1));
		}
	} else if(versionManagerGui.isAwake() && PortableProgressWindow.getGroup() != versionManagerGui.getId()) {
		versionManagerGui.add(PortableProgressWindow);
		PortableProgressWindow.setVisible(0);
	}
	
	$Launcher::Installer::Avg[-1 + $Launcher::Installer::AvgSize++] = %curr - $Launcher::VersionInstallingCurr;
	
	%pText = "<font:Consolas:18><just:center>";
	%pText = %pText @ (%curr >= %max ? getFancyByteString(%curr) : getFancyByteString(%curr) @ " / " @ getFancyByteString(%max));
	%pText = %pText SPC "@ " @ getFancyByteString($Launcher::Installer::AvgTransferRate) @ "/s [Blob # " @ $V21::CURRENTBLOB @ " out of " @ $V21::BLOBCOUNT @ "]";
	
	%pBar.setValue((%curr >= %max ? $V21::CURRENTBLOB / $V21::BLOBCOUNT : %curr /  %max));
	%pBar.getObject(0).setText(%pText);
	
	// Update row
	if(versionManagerGui.isAwake()) {
		if(%curr >= %max)
			versionManagerGui.findObjectByInternalName("VersionList", true).setRowById(%cIdx, getBlocklandName(%cVer));
		else
			versionManagerGui.findObjectByInternalName("VersionList", true).setRowById(%cIdx, getBlocklandName(%cVer) SPC "(" @ mFloor((%curr / %max) * 100) @ "%)");
	}
}

function CancelBlobs() {
	for(%i=$V21::BLOBCOUNT - 1;%i>=0;%i--) tcpCancelDownload(getField($V21::BLOB[%i], 2));
	deleteVariables("$V21::BLOB*");
}

function DownloadBlobs() {
	%installPath = $pref::Launcher::Location @ "Blockland v21\\";
	
	for(%i=0;%i<$V21::BLOBCOUNT;%i++) {
		%currentBlob = $V21::BLOB[%i];
		createPath(filePath(strReplace(%installPath, "\\", "/")) @ getSubStr(%name = getField(%currentBlob, 0), 1, strLen(%name) - 1));
		%id = tcpDownload(strReplace(%installPath, "\\", "/") @ getSubStr(%name = getField(%currentBlob, 0), 1, strLen(%name) - 1), $V21::BLOBHOST, $V21::BLOBPATH @ getField(%currentBlob, 1), "80", "onBlobDownloadDone", "onBlobDownloadProgress", "onBlobDownloadStart");
		$V21::BLOB[%i] = setField($V21::BLOB[%i], 2, %id);
	}
}