if(!isObject(VerGroup))
	new SimGroup(VerGroup);

function clearBlocklandVersions() {
	deleteVariables("$Launcher::Versions::*");
	while(VerGroup.getCount() != 0)
		VerGroup.getObject(0).delete();
	VerGroup.delete();
	new SimGroup(VerGroup);
	
	if (isObject(vCatList))
		vCatList.clearEntries();
}

function getDifferenceTags(%oldVer, %newVer)
{
	%oldVer = strReplace(%oldVer, ".", " ");
	%newVer = strReplace(%newVer, ".", " ");
	%oldVer = stripChars(%oldVer, stripChars(%oldVer, "0123456789 "));
	%newVer = stripChars(%newVer, stripChars(%newVer, "0123456789 "));
	%tags   = "same-version";
	
	// Compare major version
	if (getWord(%newVer, 0) > getWord(%oldVer, 0))
		return "outdated-version required-update";
	else if (getWord(%newVer, 0) < getWord(%oldVer, 0))
		return "newer-version";
	
	// Compare minor version
	if (getWord(%newVer, 1) > getWord(%oldVer, 1))
		return "outdated-version";
	else if (getWord(%newVer, 1) < getWord(%oldVer, 1))
		return "newer-version";
	
	return %tags;
}

function createIdentID()
{
	%IdentTable = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()_+-=";
	
	// Create a unique identifier ID
	while (true)
	{
		%Length = GetRandom(6, 10);
		%Result = "";
		for (%i = 0; %i < %Length; %i++)
			%Result = %Result @ getSubStr(%IdentTable, GetRandom(0, strLen(%IdentTable) - 1), 1);
		
		// Check against other Ident IDs
		%found = false;
		for (%i = 0; %i < VerGroup.GetCount(); %i++)
		{
			%ver = VerGroup.GetObject(%i);
			if (%ver.identID !$= %Result)
				continue;
			
			// Found it! Try again.
			%found = true;
			break;
		}
		
		if (!%found)
			break;
	}
	
	return %Result;
}

function canLaunchInstall(%SO)
{
	%ExePath = (strReplace(%SO.path, "\\", "/") @ getBlocklandExe(%SO.version));
	return (isFile(%ExePath) && fileSize(%ExePath) > 40);
}

function addInstall(%ver, %name, %path, %preferred, %patch, %identID, %customIndex)
{
	%so = new SimObject();
	
	%so.cName        = %name;
	%so.version      = %ver;
	%so.path         = %path;
	%so.preferred    = %preferred;
	%so.identID      = %identID $= "" ? createIdentID() : %identID;
	%so.installed    = !IsObject(versionManagerGui) ? 2 : (versionManagerGui.isInDownloadQueue(%ver, %so) ? 1 : 2);
	%so.patchVersion = %patch;
	%so.canLaunch    = versionManagerGui.isInDownloadQueue(%ver, %so) ? false : canLaunchInstall(%so);
	%so.customIndex  = %customIndex;
	
	// Setup things determined with information gotten from the server
	%so.newPatchVersion = %patch;
	%so.updateRequired  = false;
	%so.updateAvailable = false;
	%so.newerVersion    = false;
	%so.updating        = getFieldPos($Launcher::Installing, %so.path) != -1;
	
	VerGroup.add(%so);
	VerGroup.object[%ver, -1 + VerGroup.count[%ver]++] = %so;
	VerGroup.pathLookup[%so.path]                      = %so;
	VerGroup.identIDLookup[%so.identID]                = %so;
	
	if (%so.preferred)
		VerGroup.preferredVersionSO[%ver] = %so;
	
	return %so;
}

function removeInstall(%SO)
{
	if (!isObject(%SO))
		return;
	
	// Update installing table
	for (%i = 0; %i < getWordCount($Launcher::Installing); %i++)
	{
		%idx = getWord($Launcher::Installing, %i);
		if (%idx < %SO.index)
			continue;
		
		$Launcher::Installing = setWord($Launcher::Installing, %i, %idx - 1);
	}
	
	// Delete the launch batches
	if (isFile(%SO.launchBatch))
		fileRealDelete(strReplace(%SO.launchBatch, "/", "\\"));
	
	if (isFile(%SO.launchDediBatch))
		fileRealDelete(strReplace(%SO.launchDediBatch, "/", "\\"));
	
	if (isFile(%SO.launchDediLanBatch))
		fileRealDelete(strReplace(%SO.launchDediLanBatch, "/", "\\"));
	
	setModPaths("launcher");
	
	%SO.delete();
	UpdateInstallationsFile();
	fetchVersionListing();
}

function getInstallation(%ver)
{
	for(%i=0;%i<VerGroup.getCount();%i++)
	{
		%o = VerGroup.getObject(%i);
		if(%o.version !$= %ver) continue;
		return %o;
	}
	
	return -1;
}

function getPreferredInstallation(%ver)
{
	for(%i=0;%i<VerGroup.getCount();%i++)
	{
		%o = VerGroup.getObject(%i);
		if(%o.version !$= %ver || !%o.preferred)
			continue;
		return %o;
	}
	
	return -1;
}

function getBlocklandName(%ver)
{
	if (%ver $= "RTB")
		return "Return To Blockland";
	else if (%ver $= "launcher")
		return "B4v21 Launcher";
	else if (%ver $= "20-normal")
		return "Blockland v20 (Non-B4v21)";
	
	if (stripChars(%ver, "0123456789.") !$= "")
		return %ver;
	
	return "Blockland v" @ %ver;
}

function getBlocklandExe(%ver)
{
	if(%ver $= "20")
		return "blocklandv20.exe";
	if(%ver $= "20-normal")
		return "Blockland.exe";
	
	return "Blockland.exe";
}

function getFileCountFromFolder(%path, %name)
{
	%count = 0;
	for (%file=getFirstDirectoryFile(%path);%file !$= "";%file=getNextDirectoryFile())
	{
		if (fileName(%file) !$= %name)
			continue;
		
		%count++;
	}
	return %count;
}

function getFancyByteString(%num)
{
	%suffix = "B";
	
	if(%num >= 1024)
	{
		%num /= 1024;
		%suffix = "KB";
	}
	if(%num >= 1024)
	{
		%num /= 1024;
		%suffix = "MB";
	}
	if(%num >= 1024)
	{
		%num /= 1024;
		%suffix = "GB";
	}
	
	return mFloatLength(%num, 2) SPC %suffix;
}

function fetchScreenshots() {
	%count = 0;
	launcherGui.clearSlides();
	
	for (%i=0;%i<VerGroup.getCount();%i++)
	{
		%o = VerGroup.getObject(%i);
		launcherGui.addDirectory(%o.path @ "screenshots\\");
	}
		
	for (%i=0;%i<$Launcher::Versions::Count;%i++)
	{
		%path = $Launcher::Versions::Ver[%ver = firstWord($Launcher::Versions::Table[%i])];
		%inst = $Launcher::Versions::Installed[%ver];
		
		if(%inst != 2) continue;
		
		launcherGui.addDirectory(%path @ "screenshots\\");
	}
	
	if (%count == 0)
	{
		// Failsafe
		launcherGui.addSlide("./launcher/ui/DefaultBackground.jpg");
	}
	
	launcherGui.applyDefaultState();
}

function fetchQuickLaunchers()
{
	%typeList = "NORM DEDI DEDILAN";
	%SO       = new FileObject();
	
	for(%file = getFirstDirectoryFile(getLaunchBatchPath());%file !$= "";%file = getNextDirectoryFile())
	{
		if (fileExt(%file) !$= ".bat")
			continue;
		
		// Get batch launcher ID
		%type    = "NORM";
		%identID = "";
		if (!%SO.openForRead(%file))
			continue;
		
		while (!%SO.isEOF())
		{
			%line = %SO.readLine();
			if (getWordCount(%line) == 0 || getWord(%line, 0) !$= "REM")
				continue;
			
			if (getWord(%line, 1) $= "ID")
				%identID = removeWord(removeWord(%line, 0), 0);
			else if (getWord(%line, 1) $= "TYPE")
				%type = getWordPos(%typeList, getWord(%line, 2));
		}
		
		// Done with the file
		%SO.close();
		
		if (%identID $= "")
			continue;
		
		// Setup the SO
		%VerSO = VerGroup.identIDLookup[%identID];
		
		if (%type == 0)
			%VerSO.launchBatch = getLaunchBatchPath() @ fileName(strReplace(%file, "\\", "/"));
		else if (%type == 1)
			%VerSO.launchDediBatch = getLaunchBatchPath() @ fileName(strReplace(%file, "\\", "/"));
		else if (%type == 2)
			%VerSO.launchDediLanBatch = getLaunchBatchPath() @ fileName(strReplace(%file, "\\", "/"));
	}
	
	%SO.delete();
}

function fetchVersionListing()
{
	if (!$QuickLaunch)
	{
		versionManagerGui.findObjectByInternalName("RefreshBtn", true).setActive(0);
		updateIcon.setVisible(false);
		
		$Launcher::VersMgr::Selected = "";
		versionManagerGui.updateVersionInformation();
	}
	
	clearBlocklandVersions();
	
	// Get local installations first
	if(isFile(%verFile = ("launcher/verInfo.cfg")))
	{
		%SO = new FileObject();
		%SO.openForRead(%verFile);
		
		%save  = false;
		%count = 0;
		while(!%SO.isEOF())
		{
			%line       = %SO.readLine();
			%version    = getField(%line, 0);
			%verPath    = getField(%line, 1);
			%customName = getField(%line, 2);
			%preferred  = getField(%line, 3);
			%patch      = getField(%line, 4);
			%identID    = getField(%line, 5);
			%customIdx  = mClamp(getField(%line, 6), 0, 1);
			%customCat  = getField(%line, 7);
			
			// Sanity check
			if(getSubStr(%verPath, strLen(%verPath) - 1, 1) !$= "/" && getSubStr(%verPath, strLen(%verPath) - 1, 1) !$= "\\")
			{
				warn("Please don't mess with the verInfo.cfg file directly...");
				%verPath = %verPath @ "\\";
			}
			
			if(!isFile(%verPath @ getBlocklandExe(%version)))
			{
				error(getBlocklandName(%version) SPC "does not have a Blockland.exe -- probably deleted");
				continue;
			}
			
			if(%identID $= "")
				%save = true;
			
			if(!%got[%version])
			{
				%got[%version] = 1;
				$Launcher::Versions::Table[-1 + $Launcher::Versions::Count++] = %version;
			}
			
			%newSO           = addInstall(%version, %customName, %verPath, %preferred, %patch, %identID, %customIdx);
			%newSO.listIndex = $Launcher::Versions::Count - 1;
			
			if (%patch !$= "")
				updateInstallationPatchVersion(%newSO);
			else
			{
				%newSO.patchVersion = getInstallationPatchVersion(%newSO);
				if (%newSO.patchVersion $= "")
				{
					%newSO.patchVersion = "1.0";
					%save               = true;
				}
			}
			
			if (!$QuickLaunch)
			{
				%count++;
				if (%customCat !$= "")
					vCatList.addEntry((%catID = "catcustom-" @ strLwr(strReplace(%customCat, " ", "_"))), %customCat);
				else
					vCatList.addEntry((%catID = "cat-" @ %version), getBlocklandName(%version));
				
				vCatList.setEntryColors(%catID, "255 255 255 255", "105 106 106 255");
				vCatList.addEntry(%newSO.identID, (%newSO.cName $= "" ? getBlocklandName(%version) : "[" @ %newSO.version @ "]" SPC %newSO.cName) @ (%newSO.preferred ? "*" : "") SPC (versionManagerGui.isInDownloadQueue(%version, %newSO) ? "" : "(installed)"), %catID);
			}
		}
		
		%SO.close();
		%SO.delete();
		
		vCatList.stopTransition();
		
		if (%save)
			UpdateInstallationsFile(true);
		
		if (!$QuickLaunch)
		{
			versionManagerGui.formatVerList();
			fetchScreenshots();
			fetchQuickLaunchers();
		}
	}
	else
	{
		if (!$QuickLaunch)
			launcherGui.addSlide("./launcher/ui/DefaultBackground.jpg");
	}
	
	// Now get a list from the B4v21 website
	if(isObject(%o = VersionsFetcherTCP))
		%o.delete();

	$QuickLaunchFail = "DOES_NOT_EXIST";
	if ($QuickLaunch)
		echo("QUICKLAUNCH: Checking for updates for " @ getBlocklandName($QuickLaunchVersion));
	
	%o      = new TCPObject(VersionsFetcherTCP);
	%o.site = "b4v21.block.land";
	%o.port = 80;
	%o.cmd  = "GET /api/newLauncher.php HTTP/1.1\r\nUser-Agent: B4v21Launcher-v" @ getLauncherVersion() @ "\r\nHost: " @ %o.site @ "\r\nConnection: close\r\n\r\n";
	%o.connect(%o.site @ ":" @ %o.port);
}

function VersionsFetcherTCP::onConnectFailed(%this)
{
	if ($QuickLaunch)
	{
		if (VerGroup.count[$QuickLaunchVersion] $= "" || VerGroup.count[$QuickLaunchVersion] == 0)
		{
			$QuickLaunchFail = "NOT_INSTALLED_DISCONNECTED";
			onQuickLaunchFail();
		}
		else
			onQuickLaunchSuccess();
	}
}

function VersionsFetcherTCP::onDNSFailed(%this)
{
	if ($QuickLaunch)
	{
		if (VerGroup.count[$QuickLaunchVersion] $= "" || VerGroup.count[$QuickLaunchVersion] == 0)
		{
			$QuickLaunchFail = "NOT_INSTALLED_DISCONNECTED";
			onQuickLaunchFail();
		}
		else
			onQuickLaunchSuccess();
	}
}

function VersionsFetcherTCP::onDisconnect(%this)
{
	if ($QuickLaunch)
	{
		echo($QuickLaunchFail);
		if ($QuickLaunchFail !$= "")
		{
			onQuickLaunchFail();
			return;
		}
			
		onQuickLaunchSuccess();
		return;
	}
	
	if (!$QuickLaunch && $Pref::Launcher::AutoUpdate)
	{
		for(%i=0;%i<VerGroup.getCount();%i++)
		{
			%so = VerGroup.getObject(%i);
			if (%so.updateAvailable && !versionManagerGui.isInDownloadQueue(%so.version, %so))
				versionManagerGui.downloadVersion(%so.version, %so);
		}
	}

	versionManagerGui.findObjectByInternalName("RefreshBtn", true).setActive(1);
}

function VersionsFetcherTCP::onConnected(%this)
{
	%this.send(%this.cmd);
}

function VersionsFetcherTCP::onLine(%this, %line)
{
	%act  = firstWord(%line);
	%line = restWords(%line);
	
	switch$(%act)
	{
		case "VER":
			%ver = getField(%line, 0);
			if ($QuickLaunch && $QuickLaunchFail $= "LAUNCHER_OUT_OF_DATE")
				return;
			
			$Launcher::Versions::Ver[%ver] 		= removeField(%line, 0);
			$Launcher::Versions::PatchVersion[%ver] = getField(%line, 4);
			
			if (DoesQuickLaunchMatch(%ver))
			{
				$QuickLaunchHost = getField(%line, 1);
				$QuickLaunchPort = getField(%line, 2);
				$QuickLaunchPath = getField(%line, 3);
			}
			
			if (VerGroup.count[%ver] $= "" || VerGroup.count[%ver] == 0)
			{
				if(!$QuickLaunch)
				{
					$Launcher::Versions::Table[-1 + $Launcher::Versions::Count++] = %ver SPC removeField(%line, 0);
					$Launcher::Versions::Ver[%ver] 				      = removeField(%line, 0);
					$Launcher::Versions::PatchVersion[%ver]                       = getField(%line, 4);
					$Launcher::Versions::Installed[%ver]			      = 0;
					$Launcher::Versions::RowID[%ver, 0]                           = $Launcher::Versions::Count - 1;
				}
				
				if (%ver $= "21")
					return;
				
				if ($QuickLaunch && DoesQuickLaunchMatch(%ver) && $QuickLaunchFail $= "DOES_NOT_EXIST")
					$QuickLaunchFail = "";
				
				if (!$QuickLaunch)
				{
					if (versionManagerGui.isInDownloadQueue(%ver))
					{
						vCatList.addEntry("cat-installing", "Installing");
						vCatList.setEntryColors("cat-installing", "255 255 255 255", "105 106 106 255");
						vCatList.addEntry($Launcher::Versions::Count - 1, getBlocklandName(%ver) @ " (Installing)", "cat-installing");
						vCatList.stopTransition();
					}
					else
					{
						vCatList.addEntry("cat-uninstalled", "Not Installed");
						vCatList.setEntryColors("cat-uninstalled", "255 255 255 255", "105 106 106 255");
						vCatList.addEntry($Launcher::Versions::Count - 1, getBlocklandName(%ver), "cat-uninstalled");
						vCatList.stopTransition();
					}
				}
				else if (DoesQuickLaunchMatch(%ver) && getField(%line, 4) $= "SPECIAL")
					$QuickLaunchFail = "SPECIAL";
				else if (DoesQuickLaunchMatch(%ver))
				{
					$QuickLaunchFail = "NOT_INSTALLED";
				}
			}
			else
			{
				for (%i = 0; %i < VerGroup.count[%ver]; %i++)
				{
					if (!isObject(%so = VerGroup.object[%ver, %i]))
						continue;
					
					// Update the SO
					%so.newPatchVersion = getField(%line, 4);
					
					// Determine fields
					%tags               = getDifferenceTags(%so.patchVersion, %so.newPatchVersion);
					%so.updateAvailable = (getWordPos(%tags, "outdated-version") != -1);
					%so.updateRequired  = (getWordPos(%tags, "required-update") != -1);
					%so.newerVersion    = (getWordPos(%tags, "newer-version") != -1);
					
					if (!$QuickLaunch && %so.updateAvailable)
					{
						vCatList.setEntryText(%so.identID, "(!!!)" @ vCatList.getEntryText(%so.identID));
						
						if (!updateIcon.isVisible())
							updateIcon.setVisible(true);
					}
					
					if ($QuickLaunch && DoesQuickLaunchMatch(%ver, %so))
					{
						$QuickLaunchHost = getField(%line, 1);
						$QuickLaunchPort = getField(%line, 2);
						$QuickLaunchPath = getField(%line, 3);
						if ($QuickLaunchFail $= "DOES_NOT_EXIST")
							$QuickLaunchFail = "";
						
						if (%so.newPatchVersion $= "SPECIAL")
							$QuickLaunchFail = "SPECIAL";
						
						$QuickLaunchSO      = %so;
						$QuickLaunchName    = %so.cName;
						$QuickLaunchVersion = %ver;
						if (%so.updateRequired)
							$QuickLaunchFail = "UPDATE_REQUIRED";
						else if (%so.updateAvailable)
							$QuickLaunchFail = "UPDATE_AVAILABLE";
						else if (%so.newerVersion)
							$QuickLaunchFail = "NEWER_VERSION";
					}
				}
			}
		case "LAUNCHER_VERSION":
			%ourVer = getLauncherVersion();
			%gotVer = getField(%line, 0);
			
			%ourVer = strReplace(stripChars(%ourVer, stripChars(%ourVer, "0123456789.")), ".", " ");
			%gotVer = strReplace(stripChars(%gotVer, stripChars(%gotVer, "0123456789.")), ".", " ");
			
			%ourVer = (getWord(%ourVer, 0) * 100) + (getWord(%ourVer, 1) * 10) + getWord(%ourVer, 2);
			%gotVer = (getWord(%gotVer, 0) * 100) + (getWord(%gotVer, 1) * 10) + getWord(%gotVer, 2);
			
			if(%gotVer > %ourVer)
			{
				if (!$QuickLaunch)
				{
					openChangelog(true, "B4v21 Launcher", "launchLauncherUpdater();");
					messageBoxOK("UPDATE AVAILABLE", "B4v21 Launcher needs to be updated! Review the changelog, then hit 'UPDATE' to continue.");
				}
				else $QuickLaunchFail = "LAUNCHER_OUT_OF_DATE";
				
				$NewLauncherHost = getField(%line, 1);
				$NewLauncherPort = getField(%line, 2);
				$NewLauncherPath = getField(%line, 3);
				
				return;
			}
	}
}

function versionManagerGui::formatVerList(%this)
{
	for (%i=0;%i<vCatList.getEntryCount();%i++)
	{
		%eId = vCatList.getEntryId(%i);
		if (strStr(%eId, "cat-") != 0)
			continue;
		
		if (vCatList.getEntryChildrenCount(%eId) == 1)
		{
			%i = -1;
			vCatList.removeEntry(%eId);
			continue;
		}
	}
	
	vCatList.addEntry("cat-installed", "Installed");
	vCatList.addEntry("cat-uninstalled", "Not Installed");
	vCatList.addEntry("cat-installing", "Installing");
	vCatList.setEntryColors("cat-installed", "255 255 255 255", "105 106 106 255");
	vCatList.setEntryColors("cat-uninstalled", "255 255 255 255", "105 106 106 255");
	vCatList.setEntryColors("cat-installing", "255 255 255 255", "105 106 106 255");
	for (%i=0;%i<vCatList.getEntryCount();%i++)
	{
		%eId = vCatList.getEntryId(%i);
		if (strStr(%eId, "cat-") == 0 || strStr(%eId, "catcustom-") == 0 || vCatList.getEntryParent(%eId) !$= "")
			continue;
		
		if (strPos(vCatList.getEntryText(%eId), "(installed)") != -1)
			vCatList.setEntryParent(%eId, "cat-installed");
		else if (strPos(vCatList.getEntryText(%eId), "(Installing)") != -1 || strPos(vCatList.getEntryText(%eId), "(installing)") != -1)
			vCatList.setEntryParent(%eId, "cat-installing");
		else
			vCatList.setEntryParent(%eId, "cat-uninstalled");
	}
	
	if (vCatList.getEntryChildrenCount("cat-installed") == 0)
		vCatList.removeEntry("cat-installed");
	if (vCatList.getEntryChildrenCount("cat-uninstalled") == 0)
		vCatList.removeEntry("cat-uninstalled");
	if (vCatList.getEntryChildrenCount("cat-installing") == 0)
		vCatList.removeEntry("cat-installing");
}

function versionManagerGui::onWake(%this)
{
	%window = %this.findObjectByInternalName("VerWindow", true);
	%window.setPosition((getWord(getRes(), 0) / 2) - (getWord(%window.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%window.getExtent(), 1) / 2));
	
	$Launcher::VersMgr::Selected = "";
	
	%this.updateVersionInformation();
	%this.findObjectByInternalName("TabBook", true).selectPage(0);
}

function versionManagerGui::onSleep(%this)
{
	if (isObject(%this.contextMenu))
		%this.contextMenu.delete();
}

function versionManagerGui::updateVersionInformation(%this)
{
	%sel = $Launcher::VersMgr::Selected;
	
	// Install path
	%infoTxt = "<font:Arial Bold:16>Installation Path:<font:Arial:16><br>";
	%infoTxt = %infoTxt TAB "N/A"; // Field 1
	%infoTxt = %infoTxt TAB "<br><font:Arial Bold:16>Add-On Count:<font:Arial:16><br>";
	%infoTxt = %infoTxt TAB "N/A"; // Field 3
	%infoTxt = %infoTxt TAB "<br><font:Arial Bold:16>Screenshot Count:<font:Arial:16><br>";
	%infoTxt = %infoTxt TAB "N/A"; // Field 5
	
	if ((%sel $= "" || %sel < 0 || %sel > $Launcher::Versions::Count) && !isObject(VerGroup.IdentIDLookup[$Launcher::VersMgr::Selected]))
	{
		%this.findObjectByInternalName("InfoHeaderName", true).setText("Select something!");
		%this.findObjectByInternalName("InfoHeaderSubText", true).setText("(N/A)");
		%this.findObjectByInternalName("LaunchBtn", true).setActive(0);
		%this.findObjectByInternalName("LaunchDediLanBtn", true).setActive(0);
		%this.findObjectByInternalName("LaunchDediBtn", true).setActive(0);
		%this.findObjectByInternalName("GameInstallBtn", true).setActive(0);
		%this.findObjectByInternalName("GameInstallBtn", true).setText("Install");
		%this.findObjectByInternalName("GameInstallBtn", true).color = "255 255 255 255";
		%this.findObjectByInternalName("TabBook", true).selectPage(0);
		%this.findObjectByInternalName("InfoText", true).setText(strReplace(%infoTxt, "\t", ""));
		%this.findObjectByInternalName("RenameBtn", true).setActive(0);
		%this.findObjectByInternalName("SetPreferBtn", true).setActive(0);
		%this.findObjectByInternalName("ChangelogBtn", true).setActive(0);
		return;
	}
	
	%SO         = VerGroup.IdentIDLookup[$Launcher::VersMgr::Selected];
	%cVer       = (%iObj = isObject(%SO)) ? %SO.version : firstWord(%data = $Launcher::Versions::Table[%sel]);
	%cPath      = %iObj ? %SO.path : restWords(%data);
	%installed  = %iObj ? (%SO.canLaunch ? %SO.installed : 0) : (%this.isInDownloadQueue(firstWord(%cVer)) ? 1 : $Launcher::Versions::Installed[%cVer]);
	%installing = $Launcher::VersionInstalling.version $= %cVer;
	%realInstl  = %iObj ? %SO.installed : $Launcher::Versions::Installed[%cVer];
	%pVer       = %iObj ? %SO.patchVersion : $Launcher::Versions::PatchVersion[%cVer];
	%updating   = %iObj ? %SO.updating : false;

	if (%iObj && !%installing && !%updating && (%SO.updateRequired || %SO.updateAvailable))
	{
		%needsUpdate = true;
		%updateTxt   = " | " @ (%SO.updateRequired ? "\c1" : "\c2") @ "(Update " @ (%SO.updateRequired ? "Required" : "Available") @ "!)";
	}
	
	%this.findObjectByInternalName("InfoHeaderName", true).setText(%SO.cName !$= "" ? getBlocklandName(%cVer) SPC "- \"" @ %SO.cName @ "\"" : getBlocklandName(%cVer));
	%this.findObjectByInternalName("InfoHeaderSubText", true).setText("(" @ (%installing ? "Installing..." : (%updating ? "Updating..." : (%installed ? "Patch v" @ %pVer @ " Installed" : "Not Installed"))) @ ")" @ %updateTxt);
	%this.findObjectByInternalName("LaunchBtn", true).setActive(!%updating && %installed == 2);
	%this.findObjectByInternalName("LaunchDediLanBtn", true).setActive(!%updating && %installed == 2);
	%this.findObjectByInternalName("LaunchDediBtn", true).setActive(!%updating && %installed == 2);
	%this.findObjectByInternalName("RenameBtn", true).setActive(!%updating && %installed == 2);
	%this.findObjectByInternalName("SetPreferBtn", true).setActive(!%updating && %installed == 2 && !%SO.preferred);
	%this.findObjectByInternalName("ChangelogBtn", true).setActive(true);
	
	%GIB = %this.findObjectByInternalName("GameInstallBtn", true);
	%GIB.setText(%needsUpdate ? "Update" : (%installed == 2 ? "De-associate" : (%installed == 1 ? "Extract" : "Install")));
	%GIB.setActive(!%updating && (!%this.isInDownloadQueue(%cVer, %SO)) || (%realInstl == 2));
	
	%GIB.color = (%needsUpdate ? "255 199 94 255" : "255 255 255 255");
	
	// Replace infoTxt with real information
	%infoTxt = setField(%infoTxt, 1, (!%installed ? "<color:CC0000>Not Installed<color:000000>" : (%installed == 1 ? "<color:888800>Installing...<color:000000>" : %cPath)));
	%infoTxt = setField(%infoTxt, 3, (%installed != 2 ? "N/A" : getDirectoryFileCount(strReplace(%cPath @ "Add-Ons\\", "\\", "/"), 0) + getFileCountFromFolder(strReplace(%cPath @ "Add-Ons\\", "\\", "/"), "description.txt")));
	%infoTxt = setField(%infoTxt, 5, (%installed != 2? "N/A" : getDirectoryFileCount(strReplace(%cPath @ "screenshots\\", "\\", "/"))));
	
	%this.findObjectByInternalName("InfoText", true).setText(strReplace(%infoTxt, "\t", ""));
}

function vCatList::onDragStart(%this, %rowID, %rowText, %startIndex)
{
}

function vCatList::onDragEnd(%this, %rowID, %rowText, %oldIndex, %newIndex)
{
	if (!isObject(VerGroup.IdentIDLookup[%rowID]) || %oldIndex $= %newIndex)
		return;
	
	// Get a list of installations
	for (%i = 0; %i < VerGroup.getCount(); %i++)
		%o[-1 + %oC++] = VerGroup.getObject(%i);
	
	// Remove all objects from VerGroup
	while (VerGroup.getCount())
		VerGroup.remove(VerGroup.getObject(0));
	
	// Setup some stuff
	%ignore   = %o[%oldIndex];
	%newIndex = mClamp(%newIndex, 0, %oC - 1);
	
	// Update the ignore object
	%ignore.customIndex = true;
	
	// Re-add everything
	for (%i = 0; %i < %oC; %i++)
	{
		%o = %o[%i];
		
		// Skip ignore
		if (%ignore == %o)
			continue;
		
		// Add the ignored object at the new index
		if (%i == %newIndex)
			VerGroup.add(%ignore);
		
		VerGroup.add(%o);
	}
	
	// Update the installations file
	updateInstallationsFile(true);
}

function vCatList::onRightClicked(%this, %rowID, %rowText)
{
	if (%rowID !$= $Launcher::VersMgr::Selected)
		%this.onSelect(%rowID, %rowText);
	
	if (!isObject(%rMenu = versionManagerGui.contextMenu))
	{
		%rMenu = new GuiContextMenuCtrl(vCatListContextMenu)
		{
			profile   = "LauncherContextMenuProfile";
			minExtent = "0 0";
			extent    = "1 0";
			autoSize  = "1";
		};
		
		versionManagerGui.contextMenu = %rMenu;
	}
	
	%SO         = VerGroup.IdentIDLookup[%rowID];
	%iObj       = isObject(%SO);
	%cVer       = (%iObj ? %SO.version : firstWord($Launcher::Versions::Table[%rowID]));
	%installing = versionManagerGui.isInDownloadQueue(%cVer, %SO);
	
	%rMenu.clearItems();
	
	// Populate the context menu
	if (!%installing && %iObj)
	{
		if (!%SO.updateRequired)
		{
			%subMenu = %rMenu.addMenu("Launch", -1);
			%subMenu.addItem("Launch Game", 0);
			%subMenu.addItem("Launch Dedicated Server", 7);
			%subMenu.addItem("Launch Dedicated-LAN Server", 8);
		}
		
		if (%SO.updateAvailable)
			%rMenu.addItem("Update", 4);
	}
	else if (%installing)
		%rMenu.addItem("Cancel" SPC (%iObj ? "Update" : "Installation"), 3);
	else
		%rMenu.addItem("Install", 5);

	%rMenu.addSeperator();
	%rMenu.addItem("View Changelog", 1);
	
	if (!%installing && %iObj)
	{
		%rMenu.addSeperator();
		
		%rMenu.addItem("Open in Explorer", 10);
		
		if (%SO.launchBatch $= "")
			%rMenu.addItem("Create QuickLaunch .bat files", 6);
		if (!%SO.preferred)
			%rMenu.addItem("Make Preferred Installation", 9);
		
		%rMenu.addItem("Disassociate", 2);
	}
	
	// Done!
	versionManagerGui.add(versionManagerGui.contextMenu = %rMenu);
	%rMenu.setVisible(true);
	%rMenu.forceRefit();
	%rMenu.setPosition(getWord(Canvas.getCursorPos(), 0), getWord(Canvas.getCursorPos(), 1));
}

function vCatListContextMenu::onSelect(%this, %rowID, %rowText)
{
	%SO         = VerGroup.IdentIDLookup[vCatList.getSelectedRow()];
	%iObj       = isObject(%SO);
	%cVer       = (%iObj ? %SO.version : firstWord($Launcher::Versions::Table[vCatList.getSelectedRow()]));
	%installing = versionManagerGui.isInDownloadQueue(%cVer, %SO);
	
	switch(%rowID)
	{
		case 0: // Launch
			VersMgr_LaunchBtnPressed(false);
			
		case 1: // View Changelog
			VersMgr_ChangelogBtnPressed();
			
		case 2: // Disassociate
			VersMgr_GameInstallBtnPressed(-1);
			
		case 3: // Cancel Installation
			versionManagerGui.cancelDownload(%cVer);
			
		case 4: // Update
			VersMgr_GameInstallBtnPressed();
		
		case 5: // Install
			VersMgr_GameInstallBtnPressed();
		
		case 6: // Create QuickLaunch .bat files
			messageBoxYesNo("LAUNCH BATCH", "Are you sure you want to create a .bat file in the B4v21 Launcher directory to automatically start " @ (%SO.cName $= "" ? getBlocklandName(%cVer) : %SO.cName) @ "?<br><br>It will be created at:<br>" @ getLaunchBatchPath(%SO), "createVersionLaunchBatch(" @ %SO @ ");UpdateInstallationsFile();");
		
		case 7: // Launch dedi
			VersMgr_LaunchBtnPressed(1);
			
		case 8: // Launch dedi-LAN
			VersMgr_LaunchBtnPressed(2);
		
		case 9: // Make preferred installation
			VersMgr_SetPreferBtnPressed();
		
		case 10: // Open in Explorer
			openInExplorer(strReplace(filePath(strReplace(%SO.path, "\\", "/")), "/", "\\") @ "\\");
	}
}

function vCatList::onSelect(%this, %rowID, %rowText)
{
	if (isObject(%SO = VerGroup.IdentIDLookup[%rowID]))
	{
		// Installed installation
		%cVer = %SO.version;
		if (%cVer $= getWord(%s = "1.03 RTB 20", mFloor($Launcher::Secret::Pos)) && $Launcher::Secret::Pos < getWordCount(%s))
		{
			if ($Launcher::Secret::Pos++ >= getWordCount(%s))
			{
				alxPlay(alxCreateSource(AudioGui, "launcher/a-s-s.ogg"));
				$Launcher::Secret::Pos = "";
			}
		} else $Launcher::Secret::Pos = "";
		
		// Handle double click
		if (!%SO.updating && %this.getSelectedRow() $= $Launcher::VersMgr::Selected && getSimTime() - $Launcher::VersMgr::LastSelTime < 1000)
			VersMgr_LaunchBtnPressed();
		
		$Launcher::VersMgr::LastSelTime = getSimTime();	
		$Launcher::VersMgr::Selected    = %this.getSelectedRow();
		$Launcher::VersMgr::SelectedSO  = %SO;
		
		versionManagerGui.updateVersionInformation();
		versionManagerGui.findObjectByInternalName("TabBook", true).selectPage(0);
		return;
	}
	
	// Don't tell anybody - Clay
	%cVer = firstWord($Launcher::Versions::Table[%rowID]);
	if (%cVer $= getWord(%s = "1.03 RTB 20", mFloor($Launcher::Secret::Pos)) && $Launcher::Secret::Pos < getWordCount(%s))
	{
		if ($Launcher::Secret::Pos++ >= getWordCount(%s))
		{
			alxPlay(alxCreateSource(AudioGui, "launcher/a-s-s.ogg"));
			$Launcher::Secret::Pos = "";
		}
	} else $Launcher::Secret::Pos = "";
	
	// Hide the context menu
	if (isObject(%cMenu = versionManagerGui.contextMenu) && %cMenu.isVisible())
		%cMenu.setVisible(false);
	
	// Handle double click
	if (%rowId $= $Launcher::VersMgr::Selected && getSimTime() - $Launcher::VersMgr::LastSelTime < 1000)
	{
		%cVer      = firstWord($Launcher::Versions::Table[%rowID]);
		%cPath     = restWords($Launcher::Versions::Table[%rowID]);
		%installed = $Launcher::Versions::Installed[%cVer];
		
		if (%installed == 0)
			VersMgr_GameInstallBtnPressed();
		else if(%installed == 2)
			VersMgr_LaunchBtnPressed();
	}
	
	$Launcher::VersMgr::LastSelTime = getSimTime();	
	$Launcher::VersMgr::Selected    = %rowId;
	$Launcher::VersMgr::SelectedSO  = "";
	
	versionManagerGui.updateVersionInformation();
	versionManagerGui.findObjectByInternalName("TabBook", true).selectPage(0);
}

function VersMgr_GameInstallBtnPressed(%cfrm)
{
	%btn = versionManagerGui.findObjectByInternalName("GameInstallBtn", true);
	
	%SO        = $Launcher::VersMgr::SelectedSO;
	%cVer      = (%iObj = isObject(%SO)) ? %SO.version : firstWord($Launcher::Versions::Table[$Launcher::VersMgr::Selected]);
	%cPath     = %iObj ? %SO.path : restWords($Launcher::Versions::Table[$Launcher::VersMgr::Selected]);
	%installed = %iObj ? %SO.installed : $Launcher::Versions::Installed[%cVer];
	
	if(%installed == 1)
	{
		if(!%cfrm)
		{
			messageBoxYesNo("CONFIRM - B4v21 Launcher", "Are you sure you want to extract " @ getBlocklandName(%cVer) @ "?", "VersMgr_GameInstallBtnPressed(true);");
			return;
		}
		
		extractVersion(%cVer, $Launcher::VersMgr::Selected);
	}
	else if (%installed == 2 && %SO.updateAvailable && %cfrm != -1)
	{
		if (!%SO.updateRequired && !%cfrm)
		{
			messageBoxYesNo("CONFIRM - B4v21 Launcher", "Are you sure you want to update " @ getBlocklandName(%cVer) @ "?", "VersMgr_GameInstallBtnPressed(true);", "VersMgr_GameInstallBtnPressed(-1);");
			return;
		}
		
		versionManagerGui.downloadVersion(%SO.version, %SO);
		versionManagerGui.updateVersionInformation();
		versionManagerGui.formatVerList();
	}
	else if (%installed == 2)
	{
		if (%cfrm != true)
		{
			messageBoxYesNo("CONFIRM - B4v21 Launcher", "Are you sure you want to de-associate " @ getBlocklandName(%cVer) @ "?<br>This only removes this option from the launcher; It does not actually delete the installation.", "removeInstall(" @ %SO.getId() @ ");");
			return;
		}
		
		removeInstall(%SO);
	}
	else
	{
		%installPath = $pref::Launcher::Location @ getBlocklandName(%cVer) @ "\\";
		if(!%cfrm)
		{
			messageBoxYesNo("CONFIRM - B4v21 Launcher", "Are you sure you want to install " @ getBlocklandName(%cVer) @ "?\nIt will be installed in \"" @ %installPath @ "\".", "VersMgr_GameInstallBtnPressed(true);");
			return;
		}
		
		versionManagerGui.downloadVersion(%cVer);
		versionManagerGui.updateVersionInformation();
	}
}

function launchLauncherUpdater()
{
	launchExe($Game::Argv[0], "-launch 20 -quiet");
	schedule(10, 0, quit);
}

function convertVersionToScore(%ver)
{
	%scoreList = "0002 0.5	RTB 0.6	TOB 0.7";
	
	for(%i=0;%i<getFieldCount(%scoreList);%i++)
	{
		%s = getField(%scoreList, %i);
		
		if(firstWord(%s) !$= %ver) continue;
		
		return restWords(%s);
	}
	
	return %ver;
}

function UpdateInstallationsFile(%dontReload)
{
	%verFile = "launcher/verInfo.cfg";
	
	for (%i = 0; %i < VerGroup.getCount(); %i++)
	{
		%ver = VerGroup.getObject(%i);
		if (%ver.patchVersion $= "")
			continue;
		
		updateInstallationPatchVersion(VerGroup.getObject(%i));
	}
	
	%SO = new FileObject();
	%SO.openForWrite(%verFile);
	
	// Sort in order of versions to satiate Kenko's wild OCD
	// Store objects in group
	for(%i=0;%i<VerGroup.getCount();%i++)
	{
		%o       = VerGroup.getObject(%i);
		%o.score = convertVersionToScore(%o.version);
		
		%vObj[-1 + %vCount++] = %o;
	}
	
	// Sort these objects
	for(%i = 1; %i < %vCount; %i++)
	{
		%this = %vObj[%i];
		%last = %vObj[%i - 1];
		
		if (%last.customIndex)
			continue;
		
		if (%this.score > %last.score)
		{
			%vObj[%i]     = %last;
			%vObj[%i - 1] = %this;
			%i            = 0;
			continue;
		}
	}
	
	for(%i=0;%i<%vCount;%i++)
	{
		%o = %vObj[%i];
		
		%SO.writeLine(%o.version TAB %o.path TAB %o.cName TAB %o.preferred TAB "" TAB %o.identID TAB %o.customIndex);
	}
	
	%SO.close();
	%SO.delete();
	
	if (!%dontReload)
		fetchVersionListing();
}

function onVMGSelectedVersion()
{
	%gui  = VMG_AddGui;
	%name = getBlocklandName(%gui.findObjectByInternalName("VersionList", true).ver[%gui.findObjectByInternalName("VersionList", true).getSelected()]);
	
	if (%name $= "")
		return;
	
	%gui.findObjectByInternalName("NameDlgBox", true).setValue(%name);
}

function VMG_AddGui_AutoSearch(%cfm)
{
	// Search for an installation
	%gui  = VMG_AddGui;
	%ver  = %gui.findObjectByInternalName("VersionList", true).ver[%gui.findObjectByInternalName("VersionList", true).getSelected()];
	%path = filePath(strReplace(%gui.findObjectByInternalName("PathDlgBox", true).getValue(), "\\", "/")) @ "/";
	
	if (getSubstr(%path, strLen(%path) - 1, 1) $= "/" || getSubstr(%path, strLen(%path) - 1, 1) $= "\\")
		%path = getSubStr(%path, 0, strLen(%path) - 1);
	
	if (%ver $= "RTB" || %ver $= "0002")
	{
		messageBoxOk("ERROR", getBlocklandName(%ver) SPC "cannot be searched for automatically.");
		return;
	}
	
	if (!%cfm)
	{
		messageBoxYesNo("CONFIRMATION", "Do you want the launcher to search for a" @ (strPos("aeiouAEIOU", getSubStr(getBlocklandName(%ver), 0, 1)) == -1 ? "" : "n") SPC getBlocklandName(%ver) SPC "installation in \"" @ %path @ "\"?<br><br>WARNING:<br>This may freeze the launcher for several minutes.", "VMG_AddGui_AutoSearch(1);");
		return;
	}
	
	findFirstAllFiles(%path, "*.exe");
	for (%file = findFirstAllFiles(%path, "*"); %file !$= ""; %file = findNextAllFiles())
	{
		if (strLwr(fileName(%file)) !$= strLwr(getBlocklandExe(%ver)))
			continue;
		
		// Check to see if this EXE is currently installed
		%found = false;
		for (%i = 0; %i < VerGroup.count[%ver]; %i++)
		{
			%vObj = VerGroup.object[%ver, %i];
			
			if (filePath(strReplace(%vObj.path, "\\", "/")) !$= filePath(strReplace(%file, "\\", "/")))
				continue;
			
			%found = true;
			break;
		}
		
		// Skip this if it's already installed
		if (%found || getBlocklandVersion(%file) !$= %ver)
			continue;
		
		%changedIt = true;
		%path      = filePath(strReplace(%file, "\\", "/")) @ "/";
		break;
	}
	
	if (%changedIt)
	{
		%gui.findObjectByInternalName("PathDlgBox", true).setValue(%path);
		messageBoxOk("FOUND", "Found a" @ (strPos("aeiouAEIOU", getSubStr(getBlocklandName(%ver), 0, 1)) == -1 ? "" : "n") SPC getBlocklandName(%ver) SPC "installation!");
	}
	else
		messageBoxOk("NOT FOUND", "The launcher was unable to find any " @ getBlocklandName(%ver) @ " installations in \"" @ %path @ "\"");
}

function VMG_DoRename()
{
	%SO   = $Launcher::VersMgr::SelectedSO;
	%name = VMG_RenameGui.findObjectByInternalName("NameDlgBox", true).getValue();
	
	%SO.cName = %name;
	Canvas.popDialog(VMG_RenameGui);
	
	// Rename the download queue entry
	if (isObject(%dqObj = versionManagerGui.dQueueEntry[%SO.identID]))
		%dqObj.getObject(1).text = "<color:000000>" @ (%SO.cName $= "" ? getBlocklandName(%SO.version) : %SO.cName);
	
	if (%SO.launchBatch $= "")
		messageBoxYesNo("LAUNCH BATCH", "Do you want to create a .bat file in the B4v21 Launcher directory to automatically start " @ (%SO.cName $= "" ? getBlocklandName(%vers) : %SO.cName) @ "?<br><br>It will be created at:<br>" @ getLaunchBatchPath(%SO), "createVersionLaunchBatch(" @ %SO @ ");UpdateInstallationsFile();", "UpdateInstallationsFile();");
	else
	{
		fileRename(%SO.launchBatch, fileName(getLaunchBatchPath(%SO)));
		fileRename(%SO.launchDediBatch, fileName(getLaunchBatchPath(%SO, 1)));
		fileRename(%SO.launchDediLanBatch, fileName(getLaunchBatchPath(%SO, 2)));
		UpdateInstallationsFile();
	}
}

function VMG_RenameGui::onWake(%this)
{
	%SO = $Launcher::VersMgr::SelectedSO;
	%this.findObjectByInternalName("NameDlgBox", true).setValue(%SO.cName $= "" ? getBlocklandName(%SO.version) : %SO.cName);

	// Center window
	%w = %this.getObject(0);
	%w.setPosition((getWord(getRes(), 0) / 2) - (getWord(%w.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%w.getExtent(), 1) / 2));
}

function VMG_AddGui::onWake(%this)
{
	%list = %this.findObjectByInternalName("VersionList", true);
	
	// Populate versions list
	%list.clear();
	%count = -1;
	for(%i=0;%i<$Launcher::Versions::Count;%i++)
	{
		%data = $Launcher::Versions::Table[%i];
		%ver  = firstWord(%data);
		%path = restWords(%data);
		
		%list.ver[%count++] = %ver;
		%list.add(getBlocklandName(%ver), %count);
		
		if(%ver $= "20")
		{
			%list.ver[%count++] = %ver @ "-normal";
			%list.add(getBlocklandName(%ver) @ " (Non-B4v21)", %count);
		}
	}
	
	// Clean path box
	%this.findObjectByInternalName("PathDlgBox", true).setValue($Pref::Launcher::Location);
	%list.setSelected(0);
	
	// Clean name box
	%this.findObjectByInternalName("NameDlgBox", true).setValue(getBlocklandName(firstWord($Launcher::Versions::Table[0])));
	
	// Center window
	%w = %this.getObject(0);
	%w.setPosition((getWord(getRes(), 0) / 2) - (getWord(%w.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%w.getExtent(), 1) / 2));
}

function InstallGame(%cVer, %path)
{
	// Validate the path
	%path = strReplace(%path, "\\", "/");
	%path = (getSubStr(%path, strLen(%path) - 1, 1) !$= "/" ? %path @ "/" : %path);
	
	// Create a temp file
	%SO = new FileObject();
	if (!%SO.openForWrite(%ExePath = (%path @ getBlocklandExe(%cVer))))
	{
		error("InstallGame() - Unable to open \"" @ %ExePath @ "\" for writing!");
		messageBoxOk("ERROR", "We were unable to install " @ getBlocklandName(%cVer) @ " to \"" @ %path @ "\":<br><br>\"Unable to create fake EXE\"");
		%SO.delete();
		return;
	}
	
	%SO.writeLine("TMP");
	%SO.close();
	%SO.delete();
	
	// Create the installation
	%oldDwnl                        = $Launcher::Versions::Ver[%cVer];
	%identID                        = addInstall(%cVer, "", %path, !VerGroup.count[%cVer] ? true : false).identID;
	UpdateInstallationsFile();
	$Launcher::Versions::Ver[%cVer] = %oldDwnl;
	%SO                             = VerGroup.identIDLookup[%identID];
	
	// Download it
	versionManagerGui.downloadVersion(%cVer, %SO);
}

function VMG_AddGui_AddVersion(%cfm)
{
	%list = VMG_AddGui.findObjectByInternalName("VersionList", true);
	%path = VMG_AddGui.findObjectByInternalName("PathDlgBox", true).getValue();
	%name = VMG_AddGui.findObjectByInternalName("NameDlgBox", true).getValue();
	%vers = %list.ver[%list.getSelected()];
	
	%path = strReplace(%path, "/", "\\");
	if(getSubStr(%path, strLen(%path) - 1, 1) !$= "\\")
		%path = %path @ "\\";
	
	if (!isFile(%path @ getBlocklandExe(%vers)))
	{
		messageBoxOk("ERROR", "This is not a valid " @ getBlocklandName(%vers) @ " installation.");
		//messageBoxYesNo("ERROR - B4v21 Launcher", "Do you want to install " @ getBlocklandName(%vers) @ " here?", "InstallGame(\"" @ %vers @ "\", \"" @ strReplace(%path, "\\", "/") @ "\");Canvas.popDialog(VMG_AddGui);");
		return;
	}

	%reportedVersion = getBlocklandVersion(%path @ getBlocklandExe(%vers));
	if (!%cfm && %reportedVersion !$= "" && %reportedVersion !$= %vers && (%vers !$= "20-normal" || %reportedVersion !$= "20"))
	{
		messageBoxYesNo("VERSION MISMATCH", "<font:Arial:16>There is an installation version mismatch!<br><br>Version selected:<br><font:Arial Bold:16>" @ getBlocklandName(%vers) @ "<font:Arial:16><br><br>Installation version:<br><font:Arial Bold:16>" @ getBlocklandName(%reportedVersion) @ "<font:Arial:16><br><br>Add anyways?", "VMG_AddGui_AddVersion(true);");
		return;
	}
	
	if(%name $= getBlocklandName(%vers))
		%name = "";
	
	%SO           = addInstall(%vers, %name, %path, !VerGroup.count[%vers] ? true : false);
	%SO.installed = 1;
	
	fetchQuickLaunchers();
	if (%SO.launchBatch $= "")
		messageBoxYesNo("LAUNCH BATCH", "Do you want to create a .bat file in the B4v21 Launcher directory to automatically start " @ getBlocklandName(%vers) @ "?<br><br>It will be created at:<br>" @ getLaunchBatchPath(%SO), "createVersionLaunchBatch(" @ %SO @ ");UpdateInstallationsFile();", "UpdateInstallationsFile();");
	else
		UpdateInstallationsFile();
	
	Canvas.popDialog(VMG_AddGui);
}

function VersMgr_RenameBtnPressed()
{
	Canvas.pushDialog(VMG_RenameGui);
}

function VersMgr_SetPreferBtnPressed(%confirm)
{
	%SO = $Launcher::VersMgr::SelectedSO;
	
	if(%confirm $= "")
	{
		messageBoxYesNo("CONFIRM - B4v21 Launcher", "Are you sure you want to set this installation as your preferred " @ getBlocklandName(%SO.version) @ " installation?<br><br>This means that if you attempt to join a " @ getBlocklandName(%SO.version) @ " server, it will run this version.", "VersMgr_SetPreferBtnPressed(1);");
		return;
	}
	
	for(%i=0;%i<VerGroup.getCount();%i++)
	{
		%o = VerGroup.getObject(%i);
		
		if(%o.version !$= %SO.version) continue;
		%o.preferred = false;
	}
	
	%SO.preferred = true;
	UpdateInstallationsFile();
}

function VersMgr_LaunchBtnPressed(%dedi, %confirm)
{
	%SO        = $Launcher::VersMgr::SelectedSO;
	%cVer      = (%iObj = isObject(%SO)) ? %SO.version : firstWord($Launcher::Versions::Table[$Launcher::VersMgr::Selected]);
	%cPath     = %iObj ? %SO.path : restWords($Launcher::Versions::Table[$Launcher::VersMgr::Selected]);
	%installed = %iObj ? %SO.installed : $Launcher::Versions::Installed[%cVer];
	
	if(!%installed || !isFile(%cPath @ getBlocklandExe(%cVer)))
		return;
	
	if (%SO.updateRequired)
	{
		messageBoxYesNo("UPDATE REQUIRED - B4v21 Launcher", getBlocklandName(%cVer) @ " has a <color:ff0000>mandatory <color:000000>update pending. Are you really sure you want to run the game anyways?<br><br>(YOU MIGHT NOT BE ABLE TO JOIN OTHER B4v21 SERVERS!)", "VersMgr_LaunchBtnPressed(\"" @ %dedi @ "\", true);");
		return;
	}
	
	launchExe(%cPath @ getBlocklandExe(%cVer), "ptlaaxobimwroe" @ (%dedi ? " -dedicated" @ (%dedi == 2 ? "Lan" : "") SPC "-map bedroom" : "") @ (%cVer $= "RTB" ? " -game rtb" : "") @ (%dedi != 0 && %cVer $= "0002" ? " -game fps -mission \"fps/data/missions/bedroom.mis\"" : ""));
	
	// Stop here
	if($Pref::Launcher::CloseOnLaunch)
		quit();
	else messageBoxOk("CONFIRMATION - B4v21 Launcher", (%SO.cName !$= "" ? %SO.cName : getBlocklandName(%cVer)) @ " is now starting up. Please wait.");
}

function VersMgr_RefreshBtnPressed(%cfrm)
{
	fetchVersionListing();
}

function VersMgr_ChangelogBtnPressed()
{
	%SO   = $Launcher::VersMgr::SelectedSO;
	%cVer = (%iObj = isObject(%SO)) ? %SO.version : firstWord($Launcher::Versions::Table[$Launcher::VersMgr::Selected]);
	
	openChangelog(%iObj ? (!versionManagerGui.isInDownloadQueue(%cVer, %SO) && %SO.updateAvailable) : false, getBlocklandName(%cVer), "VersMgr_GameInstallBtnPressed(1);", true);
}

function getLaunchBatchPath(%VerSO, %dediType, %noOverwrite)
{
	if (isObject(%VerSO))
	{
		%cName = stripChars(%VerSO.cName, "/\\:*?\"<>|.");
		%fName = "Launch" SPC (%cName $= "" ? getBlocklandName(%VerSO.version) : %cName) @ (%dediType == 1 ? " (Dedicated)" : (%dediType == 2 ? "(Dedicated Lan)" : ""));
		%path  = getLaunchBatchPath() @ %fName;
		
		if (%noOverwrite && isFile(%path @ ".bat"))
		{
			%i = 0;
			while (true)
			{
				%newPath = %path @ " (1).bat";
				if (!isFile(%newPath))
					break;
			}
			
			%path = %newPath;
		}
		
		return %path @ ".bat";
	}
	
	return isDebugMode() ? GetLauncherAbsolutePath() @ "launch bats/" : GetLauncherContainerPath();
}

function createVersionLaunchBatch(%VerSO)
{
	// Come up with an available file name
	
	%SO = new FileObject();
	
	// Launch button
	if (!%SO.openForWrite(getLaunchBatchPath(%VerSO, 0, true)))
	{
		error("createVersionLaunchBatch() - Failed to create batch for \"" @ %VerSO.version @ "\"; File I/O error");
		%SO.delete();
		return;
	}
	
	%SO.writeLine("@ECHO off");
	%SO.writeLine("");
	%SO.writeLine("REM This batch file launches " @ getBlocklandName(%VerSO.version) @ ". Don't change the following lines:");
	%SO.writeLine("REM ID " @ %VerSO.identID);
	%SO.writeLine("REM TYPE NORM");
	%SO.writeLine("");
	%SO.writeLine("cd \"B4v21 Launcher\"");
	%SO.writeLine("START \"\" \"./B4v21 Launcher.exe\" -launch \"" @ %VerSO.identID @ "\"");
	%SO.writeLine("EXIT");
	%SO.close();
	
	// Dedicated launch button
	if (!%SO.openForWrite(getLaunchBatchPath(%VerSO, 1, true)))
	{
		error("createVersionLaunchBatch() - Failed to create batch for \"" @ %VerSO.version @ "\"; File I/O error");
		%SO.delete();
		return;
	}
	
	%SO.writeLine("@ECHO off");
	%SO.writeLine("");
	%SO.writeLine("REM This batch file launches " @ getBlocklandName(%VerSO.version) @ ". Don't change the following lines:");
	%SO.writeLine("REM ID " @ %VerSO.identID);
	%SO.writeLine("REM TYPE DEDI");
	%SO.writeLine("");
	%SO.writeLine("cd \"B4v21 Launcher\"");
	%SO.writeLine("START \"\" \"./B4v21 Launcher.exe\" -launch \"" @ %VerSO.identID @ "\" -dedicated");
	%SO.writeLine("EXIT");
	
	%SO.close();
	
	// Remove these two lines to enable writing dedicated lan batch
	%SO.delete();
	return;

	// Dedicated lan launch button
	if (!%SO.openForWrite(getLaunchBatchPath(%VerSO, 2, true)))
	{
		error("createVersionLaunchBatch() - Failed to create batch for \"" @ %VerSO.version @ "\"; File I/O error");
		%SO.delete();
		return;
	}

	%SO.writeLine("@ECHO off");
	%SO.writeLine("");
	%SO.writeLine("REM This batch file launches " @ getBlocklandName(%VerSO.version) @ ". Don't change the following lines:");
	%SO.writeLine("REM ID " @ %VerSO.identID);
	%SO.writeLine("REM TYPE DEDILAN");
	%SO.writeLine("");
	%SO.writeLine("cd \"B4v21 Launcher\"");
	%SO.writeLine("START \"\" \"./B4v21 Launcher.exe\" -launch \"" @ %VerSO.identID @ "\" -dedicatedlan");
	%SO.writeLine("EXIT");
	
	%SO.close();
	%SO.delete();
}

function getInstallationPatchVersion(%SO)
{
	if (!isObject(%SO))
		return "";
	
	%iPath = strReplace(%SO.path, "\\", "/") @ "B4v21Patch.ver";
	%FO    = new FileObject();
	
	if (!isFile(%iPath) || !%FO.openForRead(%iPath))
	{
		warn("getInstallationPatchVersion() - Unable to open \"" @ %iPath @ "\".");
		%FO.delete();
		return "";
	}
	
	// Write contents
	%FO.readLine();
	%ver = %FO.readLine();
	
	if (%ver $= "1")
		%ret = %FO.readLine();
	
	%FO.close();
	%FO.delete();
	
	return %ret;
}

function updateInstallationPatchVersion(%SO)
{
	if (!isObject(%SO))
		return;
	
	%realPVer = %SO.patchVersion;
	%filePVer = getInstallationPatchVersion(%SO);
	
	if (%realPVer $= %filePVer)
		return;
	
	%iPath = strReplace(%SO.path, "\\", "/") @ "B4v21Patch.ver";
	%FO    = new FileObject();
	
	if (!%FO.openForWrite(%iPath))
	{
		error("setInstallationPatchVersion() - Unable to open \"" @ %iPath @ "\"!");
		%FO.delete();
		return;
	}
	
	// Write contents
	%FO.writeLine("This file is for the B4v21 Launcher. Don't delete it.");
	%FO.writeLine("1"); // Patch version file number
	%FO.writeLine(%SO.patchVersion);
	
	%FO.close();
	%FO.delete();
}

function openFilesTab()
{
	if (!isObject(FileBrowser))
		exec("./FileBrowser.cs");
	
	fileBrowser.OnOpen();
}