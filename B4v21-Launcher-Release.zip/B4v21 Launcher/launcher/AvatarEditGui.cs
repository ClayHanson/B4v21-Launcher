// Helpers
function RGB2HSV(%rgb)
{
	return mFloatLength(getWord(%rgb, 0) / 255, 3) SPC mFloatLength(getWord(%rgb, 1) / 255, 3) SPC mFloatLength(getWord(%rgb, 2) / 255, 3) SPC mFloatLength(getWord(%rgb, 3) / 255, 3);
}

function HSV2RGB(%rgb)
{
	return mFloor(getWord(%rgb, 0) * 255) SPC mFloor(getWord(%rgb, 1) * 255) SPC mFloor(getWord(%rgb, 2) * 255) SPC mFloor(getWord(%rgb, 3) * 255);
}

function SET_AVATAR_PARTS(%list, %index)
{
	for (%i = 0; %i < getFieldCount(%list); %i++)
		eval(getField(%list, %i) SPC "= \"" @ %index @ "\";");
	
	return %list;
}

function SET_AVATAR_FRAMES(%list, %name, %index)
{
	for (%i = 0; %i < getFieldCount(%list); %i++)
	{
		eval(getField(%list, %i) @ "Color = \"" @ %index @ "\";");
		eval(getField(%list, %i) @ "Name = \"" @ %name @ "\";");
	}
	
	return %list;
}

function SET_AVATAR_COLORS(%list, %color)
{
	for (%i = 0; %i < getFieldCount(%list); %i++)
		eval(getField(%list, %i) SPC "= \"" @ %color @ "\";");
	
	return %list;
}

function GET_AVATAR_FIRST_PART(%list)
{
	return eval("return " @ getField(%list, getFieldCount(%list) - 1) @ ";");
}

function GET_AVATAR_FIRST_PART_COLOR(%list)
{
	return eval("return " @ getField(%list, getFieldCount(%list) - 1) @ ";");
}

function GET_AVATAR_FIRST_IFL_NAME(%list)
{
	return eval("return " @ getField(%list, getFieldCount(%list) - 1) @ "Name;");
}

function GET_AVATAR_FIRST_IFL_INDEX(%list)
{
	return eval("return " @ getField(%list, getFieldCount(%list) - 1) @ "Color;");
}

function AvatarEditGui::onWake(%this)
{
	videoSetGammaCorrection(1);
	setShadowDetailLevel(4);
	setOpenGLTextureCompressionHint(GL_NICEST);
	setOpenGLAnisotropy(1);
	setOpenGLMipReduction(0);
	setOpenGLInteriorMipReduction(0);
	setOpenGLSkyMipReduction(0);
	
	%this.e_PresetList    = %this.findObjectByInternalName("PresetList", true);
	%this.e_PartList      = %this.findObjectByInternalName("PartList", true);
	%this.e_AvatarPreview = %this.findObjectByInternalName("Avatar_Preview", true);
	%this.e_TabBook       = %this.findObjectByInternalName("OurTabs", true);
	%this.e_PresetName    = %this.findObjectByInternalName("Avatar_PresetName", true);
	%this.e_EditTab       = %this.findObjectByInternalName("EditTab", true);
	%this.e_GameName      = %this.findObjectByInternalName("GameName", true);
	%this.debug           = false;
	
	%this.cleanupEditor();
	%this.clearPreviews();
	
	%this.e_TabBook.selectPage(0);
	
	// Load color table
	%this.colorTable[0] = "0.900 0.000 0.000 1.000"; %this.colorTable[1] = "0.900 0.900 0.000 1.000";
	%this.colorTable[2] = "0.000 0.500 0.250 1.000"; %this.colorTable[3] = "0.200 0.000 0.800 1.000";
	%this.colorTable[4] = "0.900 0.900 0.900 1.000"; %this.colorTable[5] = "0.750 0.750 0.750 1.000";
	%this.colorTable[6] = "0.500 0.500 0.500 1.000"; %this.colorTable[7] = "0.200 0.200 0.200 1.000";
	%this.colorTable[8] = "0.220 0.131 0.000 1.000"; %this.colorTable[9] = "0.902 0.341 0.078 1.000";
	%this.colorTable[10] = "0.749 0.180 0.482 1.000"; %this.colorTable[11] = "0.388 0.000 0.118 1.000";
	%this.colorTable[12] = "0.133 0.271 0.271 1.000"; %this.colorTable[13] = "0.000 0.141 0.333 1.000";
	%this.colorTable[14] = "0.106 0.459 0.769 1.000"; %this.colorTable[15] = "1.000 1.000 1.000 1.000";
	%this.colorTable[16] = "0.000 0.000 0.000 1.000"; %this.colorTable[17] = "1.000 1.000 1.000 0.251";
	%this.colorTable[18] = "0.925 0.514 0.678 1.000"; %this.colorTable[19] = "1.000 0.604 0.424 1.000";
	%this.colorTable[20] = "1.000 0.878 0.612 1.000"; %this.colorTable[21] = "0.957 0.878 0.784 1.000";
	%this.colorTable[22] = "0.784 0.922 0.490 1.000"; %this.colorTable[23] = "0.541 0.698 0.553 1.000";
	%this.colorTable[24] = "0.561 0.929 0.961 1.000"; %this.colorTable[25] = "0.698 0.663 0.906 1.000";
	%this.colorTable[26] = "0.878 0.561 0.957 0.200"; %this.colorTable[27] = "0.667 0.000 0.000 0.700";
	%this.colorTable[28] = "1.000 0.500 0.000 0.700"; %this.colorTable[29] = "0.990 0.960 0.000 0.700";
	%this.colorTable[30] = "0.000 0.471 0.196 0.700"; %this.colorTable[31] = "0.000 0.200 0.640 0.700";
	%this.colorTable[32] = "0.596 0.161 0.392 0.698"; %this.colorTable[33] = "0.550 0.700 1.000 0.700";
	%this.colorTable[34] = "0.850 0.850 0.850 0.700"; %this.colorTable[35] = "0.100 0.100 0.100 0.200";
	%this.numColors = 36;
}

function AvatarEditGui::onSleep(%this)
{
	%this.cleanupEditor();
	%this.clearPreviews();
}

function AvatarEditGui::prepareForSave(%this)
{
	%this.debug                 = true;
	%this.e_AvatarPreview.shape = "";
	%this.e_PresetName.setValue("");
	
	%this.cleanupEditor();
	%this.clearPreviews();
}

function AvatarEditGui::open(%this, %verSO, %confirm)
{
	%this.so    = %verSO;
	%moduleFile = "launcher/modules/" @ getBlocklandName(%verSO.version) @ ".cs";
	
	// Unsupported version?
	if (!isFile(%moduleFile))
	{
		messageBoxOk("ERROR - B4v21 Launcher", "Unable to find game module for " @ getBlocklandName(%verSO.version) @ ".<br><br>(This means this version is currently unsupported)");
		return;
		
		if (!%confirm)
		{
			messageBoxYesNo("ERROR - B4v21 Launcher", "We were unable to find " @ getBlocklandName(%verSO.version) @ "'s game data module.<br><br>Do you want to use Blockland v20's module instead?<br><br>(NOTE - This probably won't work.)", %this.getId() @ ".open(" @ %verSO.getId() @ ", true);");
			return;
		}
		else
			%moduleFile = "launcher/modules/Blockland v20.cs";
	}
	
	// New version?
	if (!isFile(filePath(strReplace(%verSO.path, "\\", "/")) @ "/key.dat"))
	{
		messageBoxOk("ERROR - B4v21 Launcher", "Please run the game and authenticate with your key first.");
		return;
	}
	
	// Load the module into memory
	exec(%moduleFile);
	
	// Get the colortable
	%colorsFile = filePath(strReplace(%verSO.path, "\\", "/")) @ strReplace(AEGM_GetColortablePath(), "\\", "/");
	
	// Load the colorset
	if (isFile(%colorsFile))
	{
		// Execute it
		exec(%colorsFile);
		
		// Load it into our colortable
		%this.numColors = 0;
		for (%i = 0; %i < $Avatar::NumColors; %i++)
			%this.colorTable[%i] = $Avatar::Color[%i];
		
		echo("Loaded " @ $Avatar::NumColors @ " color" @ ($Avatar::NumColors == 1 ? "" : "s") @ " from " @ fileBase(%colorsFile) @ ".");
	}
	
	// Push the gui
	if (!%this.isAwake())
		Canvas.pushDialog(%this);
	
	%this.e_PresetList.deleteAll();
	%this.e_GameName.setValue("<font:Palatino Linotype:24><just:right>" @ getBlocklandName(%verSO.version));
	
	// Center the window
	%this.getObject(0).schedule(64, placeInCenter);
	
	// Load game data
	AvatarEditGui.lookupCount     = 0;
	AvatarEditGui.ifl_lookupCount = 0;
	if (!AEGM_loadGameData(%verSO))
	{
		if (isEventPending(%warnMsg))
			cancel(%warnMsg);
		
		messageBoxOk("ERROR - B4v21 Launcher", "The module for " @ getBlocklandName(%verSO.version) @ " failed to load!<br><br>Avatar editor cannot continue.");
		return;
	}
	
	// Load the shape itself
	if (!isObject("mDts" @ %verSO.version))
	{
		eval(AEGM_ConstructPlayerModel(%verSO));
	}
	
	// Load previews
	%list = AEGM_GetAvatarFileList(%verSO);
	for (%i = 0; %i < getRecordCount(%list); %i++)
	{
		%file = getRecord(%list, %i);
		%this.addPreview(removeField(%file, getFieldCount(%file) - 1), getField(%file, getFieldCount(%file) - 1));
	}
	
	if (AEGM_hasFreeAvatarSlot(%verSO))
	{
		%this.addPreview("new");
	}
	
	%this.updatePresetList();
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------

function AvatarEditGui::getPlayerPath(%this)
{
	return AEGM_GetPlayerModelPath(%this.so);
}

function AvatarEditGui::loadFavorite(%this, %file)
{
	if (!isFile(%file))
		return false;
	
	// Set default avatar
	$Pref::Avatar:Accent = "1";
	$Pref::Avatar:AccentColor = "0.990 0.960 0.000 0.700";
	$Pref::Avatar:Chest = 0;
	$Pref::Avatar:ChestColor = "7";
	$Pref::Avatar:DecalColor = "0";
	$Pref::Avatar:DecalName = "base/data/shapes/player/decals/AAA-None.png";
	$Pref::Avatar:FaceColor = "0";
	$Pref::Avatar:FaceName = "smiley";
	$Pref::Avatar:Hat = "0";
	$Pref::Avatar:HatColor = "1 1 1 1";
	$Pref::Avatar:HeadColor = "1 0.878431 0.611765 1";
	$Pref::Avatar:Hip = "0";
	$Pref::Avatar:HipColor = "0.2 0 0.8 1";
	$Pref::Avatar:LArm = "0";
	$Pref::Avatar:LArmColor = "0.9 0 0 1";
	$Pref::Avatar:LHand = "0";
	$Pref::Avatar:LHandColor = "1 0.878431 0.611765 1";
	$Pref::Avatar:LLeg = "0";
	$Pref::Avatar:LLegColor = "0.200 0.000 0.800 1.000";
	$Pref::Avatar:Pack = "0";
	$Pref::Avatar:PackColor = "0.2 0 0.8 1";
	$Pref::Avatar:RArm = "0";
	$Pref::Avatar:RArmColor = "0.9 0 0 1";
	$Pref::Avatar:RHand = "0";
	$Pref::Avatar:RHandColor = "1 0.878431 0.611765 1";
	$Pref::Avatar:RLeg = "0";
	$Pref::Avatar:RLegColor = "0.200 0.000 0.800 1.000";
	$Pref::Avatar:SecondPack = "0";
	$Pref::Avatar:SecondPackColor = "0 0.435323 0.831776 1";
	$Pref::Avatar:TorsoColor = "1 1 1 1";
	
	if (!AEGM_LoadAvatar(%this, %file))
	{
		MessageBoxOk("ERROR - B4v21 Launcher", "Failed to load avatar!");
		return;
	}
	
	return true;
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------

function AvatarEditGui::clearPreviews(%this)
{
	%this.e_PresetList.deleteAll();
}

function AvatarEditGui::loadIflFrames(%this, %name)
{
	%file = filePath(%this.getPlayerPath()) @ "/" @ %name @ ".ifl";
	
	// Init it
	%this.ifl_lookup[-1 + %this.ifl_lookupCount++] = %name;
	%this.ifl_indexTable[%name]                    = %this.ifl_lookupCount - 1;
	%this.ifl_listc[%name]                         = 0;
	
	if (!isFile(%file))
	{
		error("AvatarEditGui::loadIflFrames() - Failed to find file \"" @ %file @ "\"!");
		return;
	}
	
	// Lookup this part's object in the edit menu
	%this.e_P[%name] = %this.findObjectByInternalName("Avatar_" @ %name, true);
	%this.e_C[%name] = %this.findObjectByInternalName("Avatar_C" @ %name, true);
	
	// Attempt to open the file
	%FO = new FileObject();
	%FO.openForRead(%file);
	
	// Read from the file
	while (!%FO.isEOF())
	{
		%line = %FO.readLine();
		
		if (strPos(%line, "//") != -1)
			%line = getSubStr(%line, 0, strPos(%line, "//"));
		
		if ((%line = trim(%line)) $= "")
			continue;
		
		%framePath = filePath(strReplace(%this.so.path, "\\", "/")) @ "/" @ %line;
		if (!isFile(%framePath))
		{
			warn("WARNING: AvatarEditGui::loadIflFrames() - Failed to find frame at \"" @ %framePath @ "\"");
			continue;
		}
		
		%this.ifl_listd[%name, -1 + %this.ifl_listc[%name]++] = %framePath;
		%this.ifl_listl[%name, %framePath]                    = %this.ifl_listc[%name] - 1;
	}
	
	%FO.close();
	%FO.delete();
	
	if (isDebugMode())
	{
		echo("Read " @ %this.ifl_listc[%name] SPC %name @ (getSubStr(%name, strLen(%name) - 1, 1) $= "s" ? (%this.ifl_listc[%name] == 1 ? "" : "'") : (%this.ifl_listc[%name] == 1 ? "" : "s")) @ " from " @ %file @ "!");
	}
}

function AvatarEditGui::loadNodeNames(%this, %type)
{
	%file = filePath(%this.getPlayerPath()) @ "/" @ %type @ ".txt";
	
	if (!isFile(%file))
	{
		error("AvatarEditGui::loadAvatarGui() - Failed to find file \"" @ %file @ "\"!");
		return;
	}
	
	// Init it
	%this.lookup[-1 + %this.lookupCount++] = %type;
	%this.indexTable[%type]                = %this.lookupCount - 1;
	%this.listc[%type]                     = 0;
	
	// Lookup this part's object in the edit menu
	%this.e_P[%type] = %this.findObjectByInternalName("Avatar_P" @ %type, true);
	%this.e_C[%type] = %this.findObjectByInternalName("Avatar_C" @ %type, true);
	
	// Attempt to open the file
	%FO = new FileObject();
	%FO.openForRead(%file);
	
	// Read from the file
	while (!%FO.isEOF())
	{
		%line = %FO.readLine();
		
		if (strPos(%line, "//") != -1)
			%line = getSubStr(%line, 0, strPos(%line, "//"));
		
		if ((%line = trim(%line)) $= "")
			continue;
		
		if (%type $= "accent")
		{
			if (%this.listc[%type] == 0)
			{
				for (%i = 0; %i < getWordCount(%line); %i++)
				{
					%this.listd[%type, -1 + %this.listc[%type]++] = getWord(%line, %i);
					%this.listl[%type, getWord(%line, %i)]        = %this.listc[%type] - 1;
				}
			}
			else
			{
				%this.accents_for_hat[getWord(%line, 0)] = removeWord(%line, 0);
			}
		}
		else
		{
			%this.listd[%type, -1 + %this.listc[%type]++] = getWord(%line, 0);
			%this.listl[%type, getWord(%line, 0)]         = %this.listc[%type] - 1;
		}
	}
	
	// Done with the file
	%FO.close();
	%FO.delete();
	
	if (isDebugMode())
	{
		echo("Read " @ %this.listc[%type] SPC %type @ (getSubStr(%type, strLen(%type) - 1, 1) $= "s" ? (%this.listc[%type] == 1 ? "" : "'") : (%this.listc[%type] == 1 ? "" : "s")) @ " from " @ %file @ "!");
	}
}

function AvatarEditGui::addPreview(%this, %cfgFile, %defaultName)
{
	if (!isFile(%cfgFile) && %cfgFile !$= "new")
	{
		error("AvatarEditGui::addPreview() - Failed to find config file \"" @ %cfgFile @ "\"");
		return;
	}
	
	// Execute the configuration
	if (%cfgFile $= "new")
	{
		for (%i = 0; %i < %this.lookupCount; %i++)
		{
			%partName   = %this.lookup[%i];
			%partObject = %this.e_P[%partName];
			
			SET_AVATAR_PARTS(%partObject.partPrefName, "0");
			SET_AVATAR_COLORS(%partObject.colorPrefName, "0.000 0.000 0.000 1.000");
		}
		
		for (%i = 0; %i < %this.ifl_lookupCount; %i++)
		{
			%iflName    = %this.ifl_lookup[%i];
			%partObject = %this.e_P[%iflName];
			
			SET_AVATAR_FRAMES(%partObject.partPrefName, getSubStr(%this.ifl_listd[%iflName, 0], strLen(filePath(strReplace(%this.so.path, "\\", "/"))) + 1, strLen(%this.ifl_listd[%iflName, 0])), "0");
			SET_AVATAR_COLORS(%partObject.colorPrefName, "0.000 0.000 0.000 1.000");
		}
		
		$Pref::Avatar::ConfigName = "New Avatar...";
	}
	else
	{
		deleteVariables("$Pref::Avatar::*");
		%this.loadFavorite(%cfgFile);
	}
	
	if ($Pref::Avatar::ConfigName $= "")
		$Pref::Avatar::ConfigName = %defaultName;
	
	// Create the control
	%newCtrl = new GuiControl()
	{
		canSaveDynamicFields = "0";
		Profile              = "BlockDefaultProfile";
		HorizSizing          = "right";
		VertSizing           = "bottom";
		position             = "0 0";
		Extent               = "118 160";
		MinExtent            = "8 2";
		canSave              = "1";
		Visible              = "1";
		hovertime            = "1000";
		avatarFile           = %cfgFile;
		
		new GuiControl()
		{
			canSaveDynamicFields = "0";
			Profile              = "BlockDefaultProfile";
			HorizSizing          = "right";
			VertSizing           = "bottom";
			position             = "0 0";
			Extent               = "118 160";
			MinExtent            = "8 2";
			canSave              = "1";
			Visible              = "1";
			hovertime            = "1000";
			
			new GuiBitmapCtrl()
			{
				canSaveDynamicFields = "0";
				Profile              = "BlockDefaultProfile";
				HorizSizing          = "right";
				VertSizing           = "bottom";
				position             = "9 0";
				Extent               = "100 160";
				MinExtent            = "8 2";
				canSave              = "1";
				Visible              = "1";
				hovertime            = "1000";
				bitmap               = "launcher/ui/AvatarBG_Preview";
				wrap                 = "0";
			};
			new GuiBitmapButtonCtrl()
			{
				canSaveDynamicFields = "0";
				Profile              = "BlockButtonProfile";
				HorizSizing          = "right";
				VertSizing           = "bottom";
				position             = "0 130";
				Extent               = "118 30";
				MinExtent            = "8 2";
				canSave              = "1";
				Visible              = "1";
				hovertime            = "1000";
				pitch                = "1";
				text                 = $Pref::Avatar::ConfigName;
				command              = "AvatarEditGui.loadAvatar(\"" @ %cfgFile @ "\");";
				groupNum             = "-1";
				buttonType           = "PushButton";
				bitmap               = "launcher/ui/button1";
				iconIndex            = "0";
				color                = "255 255 255 255";
			};
			new GuiShapeCtrl(AvatarFavoritePreview)
			{
				canSaveDynamicFields  = "0";
				Profile               = "GuiDefaultProfile";
				internalName          = "AvatarShape_" @ strHash(%cfgFile);
				HorizSizing           = "right";
				VertSizing            = "bottom";
				position              = "17 8";
				Extent                = "80 120";
				MinExtent             = "8 2";
				canSave               = "1";
				Visible               = "1";
				hovertime             = "1000";
				applyFilterToChildren = "1";
				cameraZRot            = "150";
				cameraPos             = "0 -3 2";
				forceFOV              = "35";
				shape                 = %this.getPlayerPath();
				lightDirection        = "0.721277 0.57735 0.57735";
				lightColor            = "1.000000 1.000000 1.000000 1.000000";
				ambientColor          = "0.500000 0.500000 0.500000 1.000000";
				minOrbitDist          = "0";
				defaultPosition       = "-2.5455 3.512 2.6619";
				defaultRotation       = "0.1 0 2.6";
				defaultOrbitPos       = "0 0.2214 2";
				defaultOrbitDist      = "3";
				timeBeforeReset       = "2000";
			};
		};
	};
	
	// Add it
	%this.e_PresetList.add(%newCtrl);
	%Shape = %newCtrl.getObject(0).getObject(2);
	%newCtrl.getObject(0).getObject(1).command = "AvatarEditGui.loadAvatar(\"" @ %cfgFile @ "\", " @ %Shape.getId() @ ");";
	%this.customizeShape(%Shape);
	
	if (%cfgFile $= "new")
		%this.randomizeShape(%Shape);
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------

function AvatarEditGui::updateEditTabs(%this)
{
	// Populate the edit menu
	for (%i = 0; %i < %this.lookupCount; %i++)
	{
		%nodeType    = %this.lookup[%i];
		%nodePartUI  = %this.e_P[%nodeType];
		%nodeColorUI = %this.e_C[%nodeType];
		%nodeName    = %this.listd[%nodeType, GET_AVATAR_FIRST_PART(%nodePartUI.partPrefName)];
		%nodeColor   = GET_AVATAR_FIRST_PART_COLOR(%nodePartUI.colorPrefName);
		
		if (%nodeType $= "accent")
		{
			%hatName = %this.listd["Hat", ($Pref::Avatar::Hat $= "" ? 0 : $Pref::Avatar::Hat)];
			if (getWordPos(%this.accents_for_hat[%hatName], %this.listd[%nodeType, GET_AVATAR_FIRST_PART(%nodePartUI.partPrefName)]) == -1)
			{
				SET_AVATAR_PARTS(%nodePartUI.partPrefName, %this.listd[%nodeType, 0]);
				%nodeName = "none";
			}
		}
		
		// Get the part's image
		%partImage = filePath(strReplace(%this.so.path, "\\", "/")) @ "/base/client/ui/avatarIcons/" @ %nodeType @ "/" @ %nodeName @ ".png";
		
		if (getWordCount(%nodeColor) == 3)
			%nodeColor = %nodeColor SPC "1.000";
		else if (getWordCount(%nodeColor) == 1 && %nodeType $= "Chest" && $Pref::Avatar::TorsoColor !$= "")
			%nodeColor = $Pref::Avatar::TorsoColor;
		else if (getWordCount(%nodeColor) == 1)
			%nodeColor = %this.colorTable[%nodeColor];
		
		if (isObject(%nodePartUI))
		{
			%nodePartUI.getObject(0).setBitmap(%partImage);
			%nodePartUI.value                     = %nodeName;
			%nodePartUI.getObject(0).doColorShift = true;
			%nodePartUI.getObject(0).color        = %nodeColor;
		}
		
		if (isObject(%nodeColorUI))
		{
			%nodeColorUI.value                  = %nodeColor;
			%nodeColorUI.getObject(0).fillColor = HSV2RGB(%nodeColor);
		}
	}
	
	// Process ifl frames
	for (%i = 0; %i < %this.ifl_lookupCount; %i++)
	{
		%iflName    = %this.ifl_lookup[%i];
		%iflFrameUI = %this.e_P[%iflName];
		%iflColorUI = %this.e_C[%iflName];
		%iflFrame   = fileBase(GET_AVATAR_FIRST_IFL_NAME(%iflFrameUI.partPrefName));
		%iflColor   = GET_AVATAR_FIRST_PART_COLOR(%iflFrameUI.colorPrefName);
		%iflPath    = filePath(strReplace(%this.so.path, "\\", "/")) @ "/" @ strReplace(GET_AVATAR_FIRST_IFL_NAME(%iflFrameUI.partPrefName), "\\", "/");
		
		if (!isFile(%iflPath) && !isFile(%iflPath @ ".png") && !isFile(%iflPath @ ".jpg") && !isFile(%iflPath @ ".jpeg"))
			%iflPath = filePath(strReplace(%this.so.path, "\\", "/")) @ "/Add-Ons/" @ %iflName @ "_Default/" @ %iflFrame;
		
		if (!isFile(%iflPath) && !isFile(%iflPath @ ".png") && !isFile(%iflPath @ ".jpg") && !isFile(%iflPath @ ".jpeg"))
			%iflPath = filePath(strReplace(%this.getPlayerPath(), "\\", "/")) @ "/" @ %iflName @ "s/" @ %iflFrame;
		
		if (isObject(%iflFrameUI))
		{
			%iflFrameUI.getObject(0).setBitmap(%iflPath);
			%iflFrameUI.value     = %iflFrame;
			%iflFrameUI.fillColor = HSV2RGB(%iflColor);
		}
		
		if (isObject(%iflColorUI))
		{
			%iflColorUI.value                  = %iflColor;
			%iflColorUI.getObject(0).fillColor = HSV2RGB(%iflColor);
		}
	}
}

function AvatarEditGui::customizeShape(%this, %Shape)
{
	if (%Shape.getClassName() $= "GuiShapeCtrl")
	{
		%Shape.setNodeVisible("ALL", false);
		%Shape.setNodeVisible("headSkin", true);
		%Shape.setNodeColor("headSkin", $Pref::Avatar::HeadColor);
	}
	else
	{
		%Shape.setNodeVisible("", "ALL", false);
		%Shape.setNodeVisible("", "headSkin", true);
		%Shape.setNodeColor("", "headSkin", $Pref::Avatar::HeadColor);
	}
	
	// Customize the node types
	for (%i = 0; %i < %this.lookupCount; %i++)
	{
		%nodeType  = %this.lookup[%i];
		%nodeName  = %this.listd[%nodeType, GET_AVATAR_FIRST_PART(%this.e_P[%nodeType].partPrefName)];
		%nodeColor = GET_AVATAR_FIRST_PART_COLOR(%this.e_P[%nodeType].colorPrefName);
		
		if (%nodeType $= "accent")
		{
			%hatName = %this.listd["Hat", ($Pref::Avatar::Hat $= "" ? 0 : $Pref::Avatar::Hat)];
			if (getWordPos(%this.accents_for_hat[%hatName], %this.listd[%nodeType, GET_AVATAR_FIRST_PART(%this.e_P[%nodeType].partPrefName)]) == -1)
				%nodeName = "none";
		}
		
		if (%nodeName $= "none")
			continue;
		
		if (getWordCount(%nodeColor) == 3)
			%nodeColor = %nodeColor SPC "1.000";
		else if (getWordCount(%nodeColor) == 1 && %nodeType $= "Chest" && $Pref::Avatar::TorsoColor !$= "")
			%nodeColor = $Pref::Avatar::TorsoColor;
		else if (getWordCount(%nodeColor) == 1)
			%nodeColor = %this.colorTable[%nodeColor];
		
		%nodeColor = mFloatLength(getWord(%nodeColor, 0), 3) SPC mFloatLength(getWord(%nodeColor, 1), 3) SPC mFloatLength(getWord(%nodeColor, 2), 3) SPC mFloatLength(getWord(%nodeColor, 3), 3);
		
		if (%Shape.getClassName() $= "GuiShapeCtrl")
		{
			%Shape.setNodeVisible(%nodeName, true);
			%Shape.setNodeColor(%nodeName, %nodeColor);
		}
		else
		{
			%Shape.setNodeVisible("", %nodeName, true);
			%Shape.setNodeColor("", %nodeName, %nodeColor);
		}
	}
	
	// Customize the IFL frames
	for (%i = 0; %i < %this.ifl_lookupCount; %i++)
	{
		%iflName   = %this.ifl_lookup[%i];
		%iflFrame  = fileBase(GET_AVATAR_FIRST_IFL_NAME(%this.e_P[%iflName].partPrefName));
		%nodeName  = %this.e_P[%iflName].nodeName;
		%nodeColor = GET_AVATAR_FIRST_PART_COLOR(%this.e_P[%iflName].colorPrefName);
		
		if (%Shape.getClassName() $= "GuiShapeCtrl")
		{
			%Shape.setIflFrame(%iflName, %iflFrame);
		}
		else
		{
			%Shape.setIflFrame("", %iflName, %iflFrame);
		}
	}
	
	AEGM_CustomizeShape(%this, %Shape);
}

function AvatarEditGui::close(%this, %confirm)
{
	if (%this.avatarLoaded && !%confirm && %this.getStateHash() !$= %this.originalHash)
	{
		messageBoxYesNo("CONFIRMATION- B4v21 Launcher", "Are you sure you want to close the Avatar Editor?<br><br>Any unsaved progress will be lost.", "AvatarEditGui.close(true);");
		return;
	}
	
	%this.cleanupEditor();
	%this.clearPreviews();
	
	Canvas.popDialog(%this);
}

function AvatarEditGui::getStateHash(%this)
{
	%toHash = %this.e_PresetName.getValue();
	
	// Build the hash string
	for (%i = 0; %i < %this.lookupCount; %i++)
	{
		%nodeType  = %this.lookup[%i];
		%nodeName  = GET_AVATAR_FIRST_PART(%this.e_P[%nodeType].partPrefName);
		%nodeColor = GET_AVATAR_FIRST_PART_COLOR(%this.e_P[%nodeType].colorPrefName);
		%toHash    = %toHash @ %nodeName @ "-" @ %nodeColor;
	}
	
	// Customize the IFL frames
	for (%i = 0; %i < %this.ifl_lookupCount; %i++)
	{
		%iflName  = %this.ifl_lookup[%i];
		%iflFrame = fileBase(GET_AVATAR_FIRST_IFL_NAME(%this.e_P[%iflName].partPrefName));
		%iflColor = GET_AVATAR_FIRST_PART_COLOR(%this.e_P[%iflName].colorPrefName);
		%toHash   = %toHash @ %iflFrame @ "-" @ %iflColor;
	}
	
	return strHash(%toHash);
}

function AvatarEditGui::cleanupEditor(%this)
{
	%this.avatarLoaded    = false;
	%this.activePartMenu  = "";
	%this.lookupCount     = 0;
	%this.ifl_lookupCount = 0;
	
	%this.e_AvatarPreview.clearParticles();
	%this.e_AvatarPreview.clearShapes();
	
	if (isObject(%this.contextMenu))
		%this.contextMenu.delete();
	
	%this.e_PartList.deleteAll();
	
	if (isObject(%this.TempGroup))
	{
		%this.TempGroup.deleteAll();
		%this.TempGroup.delete();
		%this.TempGroup = "";
	}
}

function AvatarEditGui::gotoEditTab(%this)
{
	if (!%this.avatarLoaded && (!%this.debug || !isDebugMode()))
	{
		messageBoxOk("ERROR - B4v21 Launcher", "You must select an avatar to edit first.");
		%this.e_TabBook.selectPage(0);
		return;
	}
	
	if (!isObject(%this.TempGroup))
		%this.TempGroup = new SimSet();
	
	// Close the current active part / color menu
	if (isObject(%this.activeMenu))
	{
		// Close the other menu.
		%this.activeMenu.setVisible(0);
		%this.activeMenu = "";
	}
	
	// Callback!
	AEGM_OnEditorLoaded(%this.so);
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------

function AvatarEditGui::isSymmetrical(%this)
{
	return %this.e_Symmetry.getValue();
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------

function AvatarEditGui::addPartControl(%this, %type, %newLine, %arg0, %arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
{
	if (%newLine $= "")
		%newLine = false;
	
	switch$(%type)
	{
		case "ifl_selector":
			// (ifl_selector, <string>Ifl Name, <string>Node Name, <string>Color Pref, <bool>Include Color Picker, <string>Tooltip Text)
			
			%iflName     = %arg0;
			%nodeName    = %arg1;
			%colorPref   = %arg2;
			%colorPicker = %arg3;
			%tooltipText = %arg4;
			
			%newCtrl = new GuiSwatchCtrl()
			{
				profile       = "BlockDefaultProfile";
				position      = "0 0";
				extent        = "64 64";
				internalName  = "Avatar_" @ %iflName;
				fill          = "1";
				border        = "0";
				fillColor     = "255 255 255 255";
				colorPrefName = %colorPref;
				partPrefName  = "$Pref::Avatar::" @ %iflName;
				nodeName      = %nodeName;
				
				new GuiBitmapCtrl()
				{
					profile  = "BlockDefaultProfile";
					position = "0 0";
					extent   = "64 64";
					
					new GuiBitmapButtonCtrl()
					{
						profile        = "BlockDefaultProfile";
						position       = "0 0";
						extent         = "64 64";
						bitmap         = "launcher/ui/btnDecalA";
						command        = "AvatarEditGui.openIflMenu(\"" @ %iflName @ "\");";
						tooltipprofile = "BlockDefaultProfile";
						Tooltip        = %tooltipText;
					};
				};
			};
			
			%this.e_P[%iflName] = %newCtrl;
			if (%colorPicker)
			{
				%ctrl = new GuiControl()
				{
					profile      = "BlockDefaultProfile";
					position     = "0 0";
					extent       = "96 64";
				};
				
				%ctrl.add(%newCtrl);
				%newCtrl = %ctrl;
				
				%ctrl = new GuiBitmapButtonCtrl()
				{
					profile       = "BlockDefaultProfile";
					position      = "61 0";
					extent        = "32 32";
					internalName  = "Avatar_C" @ %iflName;
					bitmap        = "launcher/ui/btnPartColor";
					command       = "AvatarEditGui.openColorPicker(\"" @ %iflName @ "\");";
					value         = "255 255 255 255";
					colorPrefName = %colorPref;
					
					new GuiSwatchCtrl()
					{
						profile   = "GuiNoModalProfile";
						position  = "3 3";
						extent    = "26 26";
						fill      = "1";
						border    = "0";
						fillColor = "255 255 255 255";
						fillColor = "255 255 255 255";
					};
				};
				
				%newCtrl.add(%ctrl);
				%this.e_C[%iflName] = %ctrl;
			}
			
		case "part_selector":
			// (part_selector, <string>Part Name, <string>Symmetrical Part Name, <string>Color Pref Name, <string>Tooltip Text)
			
			%partName      = %arg0;
			%symmetryName  = %arg1;
			%colorPrefName = %arg2;
			%tooltipText   = %arg3;
			
			%newCtrl = new GuiControl()
			{
				profile      = "BlockDefaultProfile";
				position     = "0 0";
				extent       = "96 64";
				
				new GuiBitmapCtrl()
				{
					profile         = "BlockDefaultProfile";
					position        = "0 0";
					extent          = "64 64";
					internalName    = "Avatar_P" @ %partName;
					bitmap          = "launcher/ui/btnDecalBG";
					doColorShift    = "0";
					colorPrefName   = (%colorPrefName $= "" ? "$Pref::Avatar::" @ %partName @ "Color" : %colorPrefName);
					symmetricalPart = %symmetryName;
					partPrefName    = "$Pref::Avatar::" @ %partName;
					
					new GuiBitmapCtrl()
					{
						profile  = "BlockDefaultProfile";
						position = "0 0";
						extent   = "64 64";
						
						new GuiBitmapButtonCtrl()
						{
							profile        = "BlockDefaultProfile";
							position       = "0 0";
							extent         = "64 64";
							bitmap         = "launcher/ui/btnDecalA";
							command        = "AvatarEditGui.openPartMenu(\"" @ %partName @ "\");";
							tooltipprofile = "BlockDefaultProfile";
							Tooltip        = %tooltipText;
						};
					};
				};
				
				new GuiBitmapButtonCtrl()
				{
					profile       = "BlockDefaultProfile";
					position      = "61 0";
					extent        = "32 32";
					internalName  = "Avatar_C" @ %partName;
					bitmap        = "launcher/ui/btnPartColor";
					command       = "AvatarEditGui.openColorPicker(\"" @ %partName @ "\");";
					value         = "255 255 255 255";
					colorPrefName = "$Pref::Avatar::" @ %partName @ "Color";
					
					new GuiSwatchCtrl()
					{
						profile   = "GuiNoModalProfile";
						position  = "3 3";
						extent    = "26 26";
						fill      = "1";
						border    = "0";
						fillColor = "255 255 255 255";
						fillColor = "255 255 255 255";
					};
				};
			};
			
			%this.e_P[%partName] = %newCtrl.getObject(0);
			%this.e_C[%partName] = %newCtrl.getObject(1);
		
		case "symmetry_bool":
			%newCtrl = new GuiBitmapCtrl()
			{
				profile      = "BlockDefaultProfile";
				internalName = "Avatar_Symmetry";
				position     = "0 0";
				extent       = "64 64";
				bitmap       = "launcher/ui/btnDecalBG";
				
				new GuiCheckBoxCtrl()
				{
					profile  = "BlockCheckBoxProfile";
					position = "0 0";
					extent   = "64 64";
					text     = "Symmetry";
				};
			};
			
			%this.e_Symmetry = %newCtrl.getObject(0);
		
		default:
			error("ERROR: AvatarEditGui::createControl() - Unknown part control type \"" @ %type @ "\"!");
	}
	
	// Check to see if the object was actually created
	if (!isObject(%newCtrl))
	{
		error("ERROR: AvatarEditGui::createControl() - Failed creating Part-Control of type \"" @ %type @ "\"!");
		return false;
	}
	
	// Apply extra stuff
	%newCtrl.newLine = %newLine;
	
	// Add it to the list
	%this.e_PartList.add(%newCtrl);
	
	// Done!
	return true;
}

function AvatarEditGui::updatePartList(%this)
{
	%list = %this.e_PartList;
	%padX = %list.rowSpacing;
	%padY = %list.columnSpacing;
	%hiLW = 0; // Highest line W
	%hiLH = 0; // Highest line H
	%x    = 0;
	%y    = 0;
	%w    = 0;
	%h    = 0;
	
	for (%i = 0; %i < %list.getCount(); %i++)
	{
		// Get the part
		%part = %list.getObject(%i);
		
		// Position this element
		%part.setPosition(%x, %y);
		
		// Increment to the next position
		if (%part.newLine)
		{
			%h += %part.getHeight() + %padY;
			
			if (%h > %hiLH)
				%hiLH = %h;
			
			%x   += %hiLW + %padX;
			%y    = 0;
			%w   += %hiLW + %padX;
			%h    = 0;
			%hiLW = 0;
		}
		else
		{
			if (%part.getWidth() > %hiLW)
				%hiLW = %part.getWidth();
			
			%y += %part.getHeight() + %padY;
			%h += %part.getHeight() + %padY;
		}
	}

	if (%h > %hiLH)
		%hiLH = %h;
	
	%list.resize(1, 1, %w, %hiLH);
}

function AvatarEditGui::updatePresetList(%this)
{
	%list    = %this.e_PresetList;
	%perLine = 4;
	%padX    = 8;
	%padY    = 8;
	%hiLW    = 0; // Highest line W
	%hiLH    = 0; // Highest line H
	%x       = 0;
	%y       = 0;
	%w       = 0;
	%h       = 0;
	%lineNo  = 0;
	
	%list.getGroup().getGroup().scrollToTop();
	
	// Blank list? Stop here.
	if (%list.getCount() == 0)
	{
		%list.resize(0, 0, 8, 2);
		return;
	}
	
	// Re-sort
	if (%list.getObject(0).avatarFile $= "new")
		%lastScore = 100;
	else
		%lastScore = atoi(fileBase(strReplace(%list.getObject(0).avatarFile, "\\", "/")));
	
	for (%i = 1; %i < %list.getCount(); %i++)
	{
		// Get the part
		%part = %list.getObject(%i);
		%file = fileBase(strReplace(%part.avatarFile, "\\", "/"));
		
		// Determine score
		if (%file $= "new")
		{
			%score = 100;
		}
		else
		{
			%score = atoi(%file);
		}
		
		// Determine if we need to sort backwards
		if (%score < %lastScore)
		{
			%list.reorder(%part, %list.getObject(%i - 1));
			if (%list.getObject(0).avatarFile $= "new")
				%lastScore = 100;
			else
				%lastScore = atoi(fileBase(strReplace(%list.getObject(0).avatarFile, "\\", "/")));
			
			%i = 0;
			continue;
		}
		
		%lastScore = %score;
	}
	
	for (%i = 0; %i < %list.getCount(); %i++)
	{
		// Get the part
		%part = %list.getObject(%i);
		
		// Position this element
		%part.setPosition(%x, %y);
		
		// Increment to the next position
		if (%lineNo == %perLine - 1 || %i == %list.getCount() - 1)
		{
			if (%i == %list.getCount() - 1 && %part.getHeight() > %hiLH)
				%hiLH = %part.getHeight();
			
			%w += %part.getWidth();
			
			if (%w > %hiLW)
				%hiLW = %w;
			
			%lineNo = 0;
			%x      = 0;
			%y     += %hiLH + %padY;
			%w      = 0;
			%h     += %hiLH + %padY;
			%hiLH   = 0;
			
			if (%list.getCount() - (%i + 1) < %perLine)
			{
				// Offset the x offset
				%nextW = 0;
				for (%j = %i + 1; %j < %list.getCount(); %j++)
					%nextW += %list.getObject(%j).getWidth() + (%j == %list.getCount() - 1 ? 0 : %padX);
				
				%x = (%hiLW / 2) - (%nextW / 2);
			}
		}
		else
		{
			if (%part.getHeight() > %hiLH)
				%hiLH = %part.getHeight();
			
			%x += %part.getWidth() + %padX;
			%w += %part.getWidth() + %padX;
			%lineNo++;
		}
	}
	
	%h += %padY * 2;
	if (%w > %hiLW)
		%hiLW = %w;
	
	%list.getGroup().resize(1, 1, %list.getGroup().getGroup().getWidth() - 12, (%h > %list.getGroup().getGroup().getHeight() ? %h : %list.getGroup().getGroup().getHeight()) - 2);
	%list.resize((%list.getGroup().getWidth() / 2) - (%hiLW / 2), (%h < %list.getGroup().getGroup().getHeight() ? (%list.getGroup().getHeight() / 2) - (%h / 2) : %padY), %hiLW, %h);
}

function AvatarEditGui::buildColorMenu(%this)
{
	if (isObject(%newCtrl = %this.TempGroup.ColorMenu))
		return %newCtrl;
	
	// Configuration
	%maxPerRow  = 6;
	%maxPerCol  = 7;
	%btnSize    = 32;
	%colorCount = %this.numColors;
	
	// Calculate the size of the container
	%scroll_width     = (mClamp(%colorCount, 0, %maxPerRow) * %btnSize) + 16;
	%scroll_height    = mClamp(mCeil(%colorCount / %maxPerRow), 1, %maxPerCol) * %btnSize;
	%container_width  = mClamp(%colorCount, 0, %maxPerRow) * %btnSize;
	%container_height = (mCeil(%colorCount / %maxPerRow) * %btnSize) - (%colorCount < %maxPerRow ? 2 : 0);
	
	// Create the container
	%newCtrl = new GuiScrollCtrl(AvatarPartMenu)
	{
		profile    = "BlockScrollProfile";
		vScrollBar = "alwaysOn";
		hScrollBar = "alwaysOff";
		extent     = %scroll_width SPC %scroll_height;
		minExtent  = "8 2";
		visible    = "0";
		
		new GuiSwatchCtrl()
		{
			profile   = "BlockDefaultProfile";
			position  = "0 0";
			extent    = %container_width SPC %container_height;
			minExtent = "8 2";
			fillColor = "0 0 0 255";
		};
	};
	
	// Get the container where all of this will go
	%Container = %newCtrl.getObject(0);
	
	// Populate the list with buttons & images
	for (%i = 0; %i < %colorCount; %i++)
	{
		%color = %this.colorTable[%i];
		
		// Create a new button for this part
		%newButton = new GuiSwatchCtrl()
		{
			profile   = "BlockDefaultProfile";
			position  = ((%i % %maxPerRow) * %btnSize) SPC (mFloor(%i / %maxPerRow) * %btnSize);
			extent    = %btnSize SPC %btnSize;
			minExtent = "8 2";
			fillColor = HSV2RGB(%color);
			
			new GuiBitmapButtonCtrl()
			{
				profile   = "BlockDefaultProfile";
				position  = "0 0";
				extent    = %btnSize SPC %btnSize;
				minExtent = %btnSize SPC %btnSize;
				bitmap    = "launcher/ui/btnColor";
				text      = " ";
				command   = "AvatarEditGui.pickColor(\"" @ %color @ "\");";
				color     = "255 255 255 255";
				wrap      = "1";
			};
		};
		
		// Add the new button to the part menu
		%Container.add(%newButton);
	}
	
	// Link everything
	%this.TempGroup.ColorMenu = %newCtrl;
	%this.TempGroup.add(%newCtrl);
	%this.e_EditTab.add(%newCtrl);
	
	// Done
	return %newCtrl;
}

function AvatarEditGui::buildPartMenu(%this, %partName)
{
	// Get the amount of parts for this part name
	%partIndex = %this.indexTable[%partName];
	%partColor = (isObject(%this.e_C[%partName]) ? %this.e_C[%partName].value : ($Pref::Avatar["::" @ %partName @ "Color"] $= "" ? "1 1 1 1" : $Pref::Avatar["::" @%partName @ "Color"]));
	%nodeCount = %this.listc[%partName];
	
	if (isObject(%ctrl = %this.TempGroup.PartMenu_[%partName]))
	{
		%Container = %ctrl.getObject(0);
		for (%i = 0; %i < %Container.getCount(); %i++)
		{
			%object       = %Container.getObject(%i);
			%object.color = %partColor;
		}
		
		return %ctrl;
	}
	
	// Configuration
	%maxPerRow = 4;
	%maxPerCol = 6;
	%btnSize   = 64;
	
	// Ignore invalid parts
	if (%nodeCount == 0)
		return -1;
	
	// Calculate the size of the container
	%scroll_width     = (mClamp(%nodeCount, 0, %maxPerRow) * %btnSize) + 16;
	%scroll_height    = mClamp(mCeil(%nodeCount / %maxPerRow), 1, %maxPerCol) * %btnSize;
	%container_width  = mClamp(%nodeCount, 0, %maxPerRow) * %btnSize;
	%container_height = (mCeil(%nodeCount / %maxPerRow) * %btnSize) - (%nodeCount < %maxPerRow ? 2 : 0);
	
	// Create the container
	%newCtrl = new GuiScrollCtrl(AvatarPartMenu)
	{
		profile    = "BlockScrollProfile";
		vScrollBar = "alwaysOn";
		hScrollBar = "alwaysOff";
		extent     = %scroll_width SPC %scroll_height;
		minExtent  = "8 2";
		visible    = "0";
		buttonSize = %btnSize;
		maxPerRow  = %maxPerRow;
		maxPerCol  = %maxPerCol;
		
		new GuiBitmapCtrl()
		{
			profile      = "BlockDefaultProfile";
			position     = "0 0";
			extent       = %container_width SPC %container_height;
			minExtent    = "8 2";
			bitmap       = "launcher/ui/btnDecalBG";
		};
	};
	
	// Get the container where all of this will go
	%Container = %newCtrl.getObject(0);
	
	// Populate the list with buttons & images
	for (%i = 0; %i < %nodeCount; %i++)
	{
		%nodeName  = %this.listd[%partName, %i];
		%nodeImage = filePath(strReplace(%this.so.path, "\\", "/")) @ "/base/client/ui/avatarIcons/" @ %partName @ "/" @ %nodeName @ ".png";
		
		// Create a new button for this part
		%newButton = new GuiBitmapCtrl()
		{
			profile      = "BlockDefaultProfile";
			position     = ((%i % %maxPerRow) * %btnSize) SPC (mFloor(%i / %maxPerRow) * %btnSize) - 1;
			extent       = %btnSize SPC %btnSize;
			minExtent    = %btnSize SPC %btnSize;
			bitmap       = %nodeImage;
			doColorShift = "1";
			color        = %partColor;
			nodeName     = %nodeName;
			nodeImage    = %nodeImage;
			
			new GuiBitmapButtonCtrl()
			{
				profile   = "BlockDefaultProfile";
				position  = "0 0";
				extent    = %btnSize SPC %btnSize;
				minExtent = %btnSize SPC %btnSize;
				bitmap    = "launcher/ui/btnDecal";
				text      = " ";
				command   = "AvatarEditGui.pickPart(" @ %partIndex @ ", " @ %i @ ");";
			};
		};
		
		// Add the new button to the part menu
		%Container.add(%newButton);
	}
	
	// Link everything
	%this.TempGroup.PartMenu_[%partName] = %newCtrl;
	%this.TempGroup.add(%newCtrl);
	%this.e_EditTab.add(%newCtrl);
	
	// Done
	return %newCtrl;
}

function AvatarEditGui::buildIflMenu(%this, %partName)
{
	// Configuration
	%maxPerRow = 4;
	%maxPerCol = 6;
	%btnSize   = 64;
	
	// Get the amount of parts for this part name
	%partIndex = %this.ifl_indexTable[%partName];
	%partColor = (%partName $= "Face" ? (isObject(%this.e_C["Face"]) ? %this.e_C["Face"].value : $Pref::Avatar::HeadColor) : (%partName $= "Decal" ? (isObject(%this.e_C["Chest"]) ? %this.e_C["Chest"].value : $Pref::Avatar::TorsoColor) : "1 1 1 1"));
	%nodeCount = %this.ifl_listc[%partName];
	
	if (isObject(%ctrl = %this.TempGroup.PartMenu_[%partName]))
	{
		%ctrl.getObject(0).color = %partColor;
		return %ctrl;
	}
	
	// Ignore invalid parts
	if (%nodeCount == 0)
		return -1;
	
	// Calculate the size of the container
	%scroll_width     = (mClamp(%nodeCount, 0, %maxPerRow) * %btnSize) + 12;
	%scroll_height    = mClamp(mCeil(%nodeCount / %maxPerRow), 1, %maxPerCol) * %btnSize;
	%container_width  = mClamp(%nodeCount, 0, %maxPerRow) * %btnSize;
	%container_height = (mCeil(%nodeCount / %maxPerRow) * %btnSize) - (%nodeCount < %maxPerRow ? 2 : 0);
	
	// Create the container
	%newCtrl = new GuiScrollCtrl(AvatarPartMenu)
	{
		profile    = "BlockScrollProfile";
		vScrollBar = "alwaysOn";
		hScrollBar = "alwaysOff";
		extent     = %scroll_width SPC %scroll_height;
		minExtent  = "8 2";
		visible    = "0";
		buttonSize = %btnSize;
		maxPerRow  = %maxPerRow;
		maxPerCol  = %maxPerCol;
		
		new GuiBitmapCtrl()
		{
			profile      = "BlockDefaultProfile";
			position     = "0 0";
			extent       = %container_width SPC %container_height;
			minExtent    = "8 2";
			bitmap       = "launcher/ui/btnDecalBG";
			doColorShift = "1";
			color        = %partColor;
			wrap         = "1";
		};
	};
	
	// Get the container where all of this will go
	%Container = %newCtrl.getObject(0);
	
	// Populate the list with buttons & images
	for (%i = 0; %i < %nodeCount; %i++)
	{
		%nodeName  = %this.ifl_listd[%partName, %i];
		%nodeImage = strReplace(%nodeName, "\\", "/");
		
		// Create a new button for this part
		%newButton = new GuiBitmapCtrl()
		{
			profile      = "BlockDefaultProfile";
			position     = ((%i % %maxPerRow) * %btnSize) SPC (mFloor(%i / %maxPerRow) * %btnSize);
			extent       = %btnSize SPC %btnSize;
			minExtent    = %btnSize SPC %btnSize;
			bitmap       = %nodeImage;
			nodeName     = %nodeName;
			nodeImage    = %nodeImage;
			
			new GuiBitmapButtonCtrl()
			{
				profile   = "BlockDefaultProfile";
				position  = "0 0";
				extent    = %btnSize SPC %btnSize;
				minExtent = %btnSize SPC %btnSize;
				bitmap    = "launcher/ui/btnDecal";
				text      = " ";
				command   = "AvatarEditGui.pickIflFrame(" @ %partIndex @ ", " @ %i @ ");";
			};
		};
		
		// Add the new button to the part menu
		%Container.add(%newButton);
	}
	
	// Link everything
	%this.TempGroup.PartMenu_[%partName] = %newCtrl;
	%this.TempGroup.add(%newCtrl);
	%this.e_EditTab.add(%newCtrl);
	
	// Done
	return %newCtrl;
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------

function AvatarEditGui::openColorPicker(%this, %partName)
{
	%partObject = %this.e_C[%partName];
	%colorMenu  = %this.buildColorMenu();
	
	if (!isObject(%colorMenu))
	{
		messageBoxOk("ERROR - B4v21 Launcher", "Failed to build a color menu!");
		return;
	}
	
	// Close the current active menu
	if (isObject(%this.activeMenu))
	{
		if (%this.activeMenu.getId() == %colorMenu.getId())
		{
			// It's us! Close ourselves.
			%colorMenu.setVisible(0);
			%this.activeMenu = "";
			return;
		}
		else
		{
			// Close the other menu.
			%this.activeMenu.setVisible(0);
		}
	}
	
	// Set our state
	%this.editingColorPart = %this.e_P[%partName];
	
	// Calculate open position
	%openX = getWord(%partObject.getGlobalPosition(), 0) + %partObject.getWidth();
	%openY = getWord(%partObject.getGlobalPosition(), 1);
	
	// Calculate our parent's rect
	%valid_left   = getWord(%colorMenu.getGroup().getGlobalPosition(), 0);
	%valid_top    = getWord(%colorMenu.getGroup().getGlobalPosition(), 1);
	%valid_right  = %valid_left + %colorMenu.getGroup().getWidth();
	%valid_bottom = %valid_top + %colorMenu.getGroup().getHeight();
	
	// Make sure the entire dialog is visible
	if (%openY + %colorMenu.getHeight() > %valid_bottom)
		%openY -= (%openY + %colorMenu.getHeight()) - %valid_bottom;
	
	// Show ourselves
	%colorMenu.scrollToTop();
	%colorMenu.setPositionGlobal(%openX, %openY);
	%colorMenu.setVisible(1);
	
	// Set our active state
	%this.activeMenu = %colorMenu.getId();
}

function AvatarEditGui::openIflMenu(%this, %iflName)
{
	%iflObject = %this.e_P[%iflName];
	%iflMenu   = %this.buildIflMenu(%iflName);
	
	if (!isObject(%iflMenu))
	{
		messageBoxOk("ERROR - B4v21 Launcher", "Failed to build an IFL menu for \"" @ %iflName @ "\"!");
		return;
	}
	
	// Close the current active ifl / color menu
	if (isObject(%this.activeMenu))
	{
		if (%this.activeMenu.getId() == %iflMenu.getId())
		{
			// It's us! Close ourselves.
			%iflMenu.setVisible(0);
			%this.activeMenu = "";
			return;
		}
		else
		{
			// Close the other menu.
			%this.activeMenu.setVisible(0);
		}
	}
	
	// Calculate open position
	%openX = getWord(%iflObject.getGlobalPosition(), 0) + %iflObject.getWidth();
	%openY = getWord(%iflObject.getGlobalPosition(), 1);
	
	// Calculate our parent's rect
	%valid_left   = getWord(%iflMenu.getGroup().getGlobalPosition(), 0);
	%valid_top    = getWord(%iflMenu.getGroup().getGlobalPosition(), 1);
	%valid_right  = %valid_left + %iflMenu.getGroup().getWidth();
	%valid_bottom = %valid_top + %iflMenu.getGroup().getHeight();
	
	// Make sure the entire dialog is visible
	if (%openY + %iflMenu.getHeight() > %valid_bottom)
		%openY -= (%openY + %iflMenu.getHeight()) - %valid_bottom;
	
	// Show ourselves
	%iflMenu.scrollToTop();
	%iflMenu.setPositionGlobal(%openX, %openY);
	%iflMenu.setVisible(1);
	
	// Set our active state
	%this.activeMenu = %iflMenu.getId();
}

function AvatarEditGui::openPartMenu(%this, %partName)
{
	%partObject = %this.e_P[%partName];
	%partMenu   = %this.buildPartMenu(%partName);
	
	if (!isObject(%partMenu))
	{
		messageBoxOk("ERROR - B4v21 Launcher", "Failed to build a part menu for \"" @ %partName @ "\"!");
		return;
	}
	
	// Close the current active part / color menu
	if (isObject(%this.activeMenu))
	{
		if (%this.activeMenu.getId() == %partMenu.getId())
		{
			// It's us! Close ourselves.
			%partMenu.setVisible(0);
			%this.activeMenu = "";
			return;
		}
		else
		{
			// Close the other menu.
			%this.activeMenu.setVisible(0);
		}
	}
	
	// Calculate open position
	%openX = getWord(%partObject.getGlobalPosition(), 0) + %partObject.getWidth();
	%openY = getWord(%partObject.getGlobalPosition(), 1);
	
	// Calculate our parent's rect
	%valid_left   = getWord(%partMenu.getGroup().getGlobalPosition(), 0);
	%valid_top    = getWord(%partMenu.getGroup().getGlobalPosition(), 1);
	%valid_right  = %valid_left + %partMenu.getGroup().getWidth();
	%valid_bottom = %valid_top + %partMenu.getGroup().getHeight();
	
	// Make sure the entire dialog is visible
	if (%openY + %partMenu.getHeight() > %valid_bottom)
		%openY -= (%openY + %partMenu.getHeight()) - %valid_bottom;
	
	// Show ourselves
	%partMenu.scrollToTop();
	%partMenu.setPositionGlobal(%openX, %openY);
	%partMenu.setVisible(1);
	
	// Set our active state
	%this.activeMenu = %partMenu.getId();
	
	// Use the callback
	AEGM_OnPartMenuOpened(%this, %this.so, %partName, %partMenu);
}

function AvatarEditGui::openColorset(%this)
{
	if (!$InitColorsetEditor)
	{
		$InitColorsetEditor = true;
		exec("launcher/ColorsetGui.Gui");
		exec("launcher/ColorsetGui.cs");
	}
	
	// Close the current active part / color menu
	if (isObject(%this.activeMenu))
	{
		// Close the other menu.
		%this.activeMenu.setVisible(0);
		%this.activeMenu = "";
	}
	
	// Show it!
	Canvas.pushDialog(ColorsetGui);
	ColorsetGui.getObject(0).placeInCenter();
	
	// Populate it with our current color table
	for (%i = 0; %i < %this.numColors; %i++)
		ColorsetGui.addColor(HSV2RGB(%this.colorTable[%i]));
	
	// Finish initialization
	ColorsetGui.updateColorList();
	ColorsetGui.callback = "AvatarEditGui.onColorsetUpdated();";
}

function AvatarEditGui::onColorsetUpdated(%this)
{
	if (isObject(%this.TempGroup.ColorMenu))
		%this.TempGroup.ColorMenu.delete();
	
	%this.numColors = 0;
	for (%i = 0; %i < $Colorset::NumColors; %i++)
	{
		%color                                   = $Colorset::Color[%i];
		%this.colorTable[-1 + %this.numColors++] = RGB2HSV(%color);
	}
}

function AvatarEditGui::randomize(%this)
{
	for (%i = 0; %i < %this.lookupCount; %i++)
	{
		%partName   = %this.lookup[%i];
		%nodeIndex  = getRandom(0, %this.listc[%partName] - 1);
		%nodeColor  = setWord(%this.colorTable[getRandom(0, %this.numColors - 1)], 3, "1.000");
		%partObject = %this.e_P[%partName];
		
		// Do symmetry
		if (%this.isSymmetrical())
		{
			if (%partObject.symmetricalPart !$= "")
			{
				SET_AVATAR_PARTS(%this.e_P[%partObject.symmetricalPart].partPrefName, %nodeIndex);
				SET_AVATAR_COLORS(%this.e_P[%partObject.symmetricalPart].colorPrefName, %nodeColor);
			}
		}
		
		SET_AVATAR_PARTS(%partObject.partPrefName, %nodeIndex);
		SET_AVATAR_COLORS(%partObject.colorPrefName, %nodeColor);
	}
	
	for (%i = 0; %i < %this.ifl_lookupCount; %i++)
	{
		%iflName    = %this.ifl_lookup[%i];
		%iflIndex   = getRandom(0, %this.ifl_listc[%iflName] - 1);
		%iflFrame   = %this.ifl_listd[%iflName, %iflIndex];
		%iflColor   = setWord(%this.colorTable[getRandom(0, %this.numColors - 1)], 3, "1.000");
		%partObject = %this.e_P[%iflName];
		
		SET_AVATAR_FRAMES(%partObject.partPrefName, getSubStr(%iflFrame, strLen(filePath(strReplace(%this.so.path, "\\", "/"))) + 1, strLen(%iflFrame)), %iflIndex);
		SET_AVATAR_COLORS(%partObject.colorPrefName, %iflColor);
	}
	
	// Refresh the preview
	%this.updateEditTabs();
	%this.customizeShape(%this.e_AvatarPreview);
}

function AvatarEditGui::randomizeShape(%this, %Shape)
{
	%Shape.setNodeVisible("ALL", false);
	
	for (%i = 0; %i < %this.lookupCount; %i++)
	{
		%partName  = %this.lookup[%i];
		%nodeIndex = getRandom(0, %this.listc[%partName] - 1);
		%nodeColor = getRandomF(0, 1) SPC getRandomF(0, 1) SPC getRandomF(0, 1) SPC "1"; // setWord(%this.colorTable[getRandom(0, %this.numColors - 1)], 3, "1.000");
		
		if (%this.listd[%partName, %nodeIndex] $= "none")
			continue;
		
		%Shape.setNodeVisible(%this.listd[%partName, %nodeIndex], true);
		%Shape.setNodeColor(%this.listd[%partName, %nodeIndex], %nodeColor);
	}
	
	for (%i = 0; %i < %this.ifl_lookupCount; %i++)
	{
		%iflName  = %this.ifl_lookup[%i];
		%iflIndex = getRandom(0, %this.ifl_listc[%iflName] - 1);
		%iflFrame = %this.ifl_listd[%iflName, %iflIndex];
		%iflColor = getRandomF(0, 1) SPC getRandomF(0, 1) SPC getRandomF(0, 1) SPC "1";
		%nodeName = %this.e_P[%iflName].nodeName;
		
		if (%nodeName !$= "" && %nodeName !$= "none")
			%Shape.setNodeVisible(%nodeName, true);
		
		%Shape.setIflFrame(%iflName, fileBase(%iflFrame));
		%Shape.setNodeColor(%nodeName, %nodeColor);
	}
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------

function AvatarEditGui::pickPart(%this, %partIndex, %nodeIndex)
{
	// Get the new node's name
	%partName   = %this.lookup[%partIndex];
	%partObject = %this.e_P[%partName];
	
	// Set our selected node
	SET_AVATAR_PARTS(%partObject.partPrefName, %nodeIndex);
	
	// Do symmetry
	if (%this.isSymmetrical())
	{
		if (%partObject.symmetricalPart !$= "")
			SET_AVATAR_PARTS(%this.e_P[%partObject.symmetricalPart].partPrefName, %nodeIndex);
	}
	
	// Refresh the preview
	%this.updateEditTabs();
	%this.customizeShape(%this.e_AvatarPreview);
	
	// Hide the menu
	%this.activeMenu.setVisible(0);
	%this.activeMenu = "";
	
	if (isDebugMode())
		echo("We picked node # " @ %nodeIndex @ " (\"" @ %this.listd[%this.lookup[%partIndex], %nodeIndex] @ "\") for part # " @ %partIndex @ " (\"" @ %this.lookup[%partIndex] @ "\")");
}

function AvatarEditGui::pickIflFrame(%this, %iflIndex, %frameIndex)
{
	// Get the new node's name
	%iflName   = %this.ifl_lookup[%iflIndex];
	%iflObject = %this.e_P[%iflName];
	
	// Set our selected node
	SET_AVATAR_FRAMES(%iflObject.partPrefName, getSubStr(%this.ifl_listd[%iflName, %frameIndex], strLen(filePath(strReplace(%this.so.path, "\\", "/"))) + 1, strLen(%this.ifl_listd[%iflName, %frameIndex])), %frameIndex);
	
	// Refresh the preview
	%this.updateEditTabs();
	%this.customizeShape(%this.e_AvatarPreview);
	
	// Hide the menu
	%this.activeMenu.setVisible(0);
	%this.activeMenu = "";
	
	if (isDebugMode())
	{
		echo("We picked face # " @ %frameIndex @ " for IFL # " @ %iflIndex @ " (\"" @ %this.ifl_lookup[%iflIndex] @ "\")");
		echo("  PATH = " @ %this.ifl_listd[%iflName, %frameIndex]);
	}
}

function AvatarEditGui::pickColor(%this, %color)
{
	// Get the new node's name
	%partObject = %this.editingColorPart;
	
	// Set our selected color
	SET_AVATAR_COLORS(%partObject.colorPrefName, %color);
	
	// Do symmetry
	if (%this.isSymmetrical())
	{
		if (%partObject.symmetricalPart !$= "")
			SET_AVATAR_COLORS(%this.e_P[%partObject.symmetricalPart].colorPrefName, %color);
	}
	
	// Refresh the preview
	%this.updateEditTabs();
	%this.customizeShape(%this.e_AvatarPreview);
	
	// Hide the menu
	if (isObject(%this.activeMenu))
		%this.activeMenu.setVisible(0);
	
	%this.editingColorPart = "";
	%this.activeMenu       = "";
	
	if (isDebugMode())
	{
		echo("We picked color \"" @ %color @ "\" for \"" @ %partObject.colorPrefName @ "\"");
	}
	
	// fixme: dirty hack
	if (strPos(%partObject.partPrefName, "::chest") != -1)
	{
		%this.editingColorPart = %this.e_P["decal"];
		%this.pickColor(%color);
	}
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------

function AvatarEditGui::loadAvatar(%this, %file, %Shape, %confirm)
{
	if (!isFile(%file) && %file !$= "new" && %file !$= "new-nobase")
	{
		messageBoxOk("ERROR - B4v21 Launcher", "Avatar file \"" @ %file @ "\" could not be found!");
		return false;
	}
	
	// Delete previous variables
	deleteVariables("$Pref::Avatar::*");
	
	// Set the output file
	%outFile = %file;
	
	if (%file $= "new" || %file $= "new-nobase")
	{
		// Determine the new output file
		for (%i = 0; %i < 10; %i++)
		{
			%outFile = filePath(strReplace(%this.so.path, "\\", "/")) @ "/" @ AEGM_GetAvatarFavoritesPath() @ %i @ ".cs";
			if (isFile(%outFile, true))
			{
				%outFile = "";
				continue;
			}
			
			break;
		}
		
		if (%outFile $= "")
		{
			messageBoxOk("ERROR - B4v21 Launcher", "All of your avatar slots are occupied!<br><br>Edit one of them instead.");
			return;
		}
		
		if (!%confirm)
		{
			messageBoxYesNo("CONFIRMATION - B4v21 Launcher", "We will save this new avatar to \"" @ strReplace(strReplace(%outFile, "\\", "\\\\"), "\"", "\\\"") @ "\" (Slot # " @ %i @ ").<br><br>OK?", "AvatarEditGui.loadAvatar(\"" @ %file @ "\", \"" @ %Shape @ "\", 1);");
			return;
		}
		
		if (%file $= "new")
		{
			for (%i = 0; %i < %this.lookupCount; %i++)
			{
				%partName   = %this.lookup[%i];
				%partObject = %this.e_P[%partName];
				%nodeIndex  = 0;
				%nodeColor  = getRandomF(0, 1) SPC getRandomF(0, 1) SPC getRandomF(0, 1) SPC "1";
				
				for (%j = 0; %j < %this.listc[%partName]; %j++)
				{
					if (%this.listd[%partName, %j] $= "none")
						continue;
					
					if (%Shape.isNodeVisible(%this.listd[%partName, %j]))
					{
						%nodeIndex = %j;
						%nodeColor = %Shape.getNodeColor(%this.listd[%partName, %j]);
						break;
					}
				}
				
				SET_AVATAR_PARTS(%partObject.partPrefName, %nodeIndex);
				SET_AVATAR_COLORS(%partObject.colorPrefName, %nodeColor);
			}
			
			for (%i = 0; %i < %this.ifl_lookupCount; %i++)
			{
				%iflName    = %this.ifl_lookup[%i];
				%partObject = %this.e_P[%iflName];
				%iflIndex   = 0;
				%iflColor   = "0 0 0 0";
				
				for (%j = 0; %j < %this.ifl_listc[%iflName]; %j++)
				{
					if (fileBase(%Shape.getIflFrame(%iflName)) $= fileBase(%this.ifl_listd[%iflName, %j]))
					{
						%iflIndex = %j;
						%iflFrame = %this.ifl_listd[%iflName, %j];
						%iflColor = %Shape.getNodeColor(%partObject.nodeName);
						break;
					}
				}
				
				SET_AVATAR_FRAMES(%partObject.partPrefName, getSubStr(%iflFrame, strLen(filePath(strReplace(%this.so.path, "\\", "/"))) + 1, strLen(%iflFrame)), %iflIndex);
				SET_AVATAR_COLORS(%partObject.colorPrefName, %iflColor);
			}
		}
		else
		{
			AEGM_SetDefaultAvatar();
		}
	}
	else
	{
		// Load it
		if (!%this.loadFavorite(%file))
		{
			messageBoxOk("ERROR - B4v21 Launcher", "Avatar file \"" @ %file @ "\" failed to execute properly!");
			return false;
		}
	}
	
	// Set the preview shape up
	if (%this.e_AvatarPreview.getShapeName("") !$= %this.getPlayerPath())
	{
		%this.e_AvatarPreview.clearShapes();
		%this.e_AvatarPreview.addShape("", %this.getPlayerPath());
		%this.e_AvatarPreview.reorientCamera();
		%this.e_AvatarPreview.forceFOV   = 35;
		%this.e_AvatarPreview.cameraZRot = 150;
		%this.e_AvatarPreview.cameraPos  = "-0.2 -5 1.3";
	}
	
	// Update everything
	%this.updateEditTabs();
	
	// Customize the object
	%this.customizeShape(%this.e_AvatarPreview);
	%this.e_AvatarPreview.ResetView(false);
	%this.e_AvatarPreview.playThread("", 0, "run");
	
	// Set the state
	%this.avatarFile   = %outFile;
	%this.isNewAvatar  = (%file $= "new" || %file $= "new-nobase");
	%this.originalHash = (%file $= "new" || %file $= "new-nobase" ? 0 : %this.getStateHash());
	%this.avatarLoaded = true;
	%this.e_PresetName.setValue($Pref::Avatar::ConfigName $= "" ? "Unnamed Avatar" : $Pref::Avatar::ConfigName);
	
	// Goto the edit page
	%this.e_TabBook.selectPage(1);
	
	return true;
}

function AvatarEditGui::saveAvatar(%this)
{
	if (!%this.avatarLoaded)
	{
		messageBoxOk("ERROR - B4v21 Launcher", "Tried to save an unloaded avatar.");
		return;
	}
	
	if (%this.originalHash $= %this.getStateHash())
	{
		messageBoxOk("ERROR - B4v21 Launcher", "Nothing has been changed; Not saving.");
		return;
	}
	
	if (!AEGM_SaveAvatar(%this, %this.avatarFile, %this.e_PresetName.getValue()))
	{
		messageBoxOk("ERROR - B4v21 Launcher", "Failed to save avatar to \"" @ %this.avatarFile @ "\"!");
		return;
	}
	
	if (%this.isNewAvatar)
	{
		%this.isNewAvatar = false;
		%this.addPreview(%this.avatarFile);
		
		%Shape = %this.findObjectByInternalName("AvatarShape_" @ strHash("new"), true);
		if (isObject(%Shape))
		{
			%this.e_PresetList.remove(%Shape.getGroup().getGroup());
			%this.e_PresetList.add(%Shape.getGroup().getGroup());
		}
		
		%this.updatePresetList();
	}
	else
	{
		%Shape = %this.findObjectByInternalName("AvatarShape_" @ strHash(%this.avatarFile), true);
		if (isObject(%Shape))
		{
			%Shape.getGroup().getObject(1).text = $Pref::Avatar::ConfigName;
			%this.customizeShape(%Shape);
		}
	}
	
	if (!AEGM_hasFreeAvatarSlot(%this.so))
	{
		%Shape = %this.findObjectByInternalName("AvatarShape_" @ strHash("new"), true);
		if (isObject(%Shape))
		{
			%Shape.getGroup().getGroup().delete();
			%this.updatePresetList();
		}
	}
	
	%this.originalHash = %this.getStateHash();
	messageBoxOk("SUCCESS - B4v21 Launcher", "Successfully saved this avatar to \"" @ %this.avatarFile @ "\"!");
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------

function AvatarPartMenu::updateSize(%this)
{
	%Container = %this.getObject(0);
	%nodeCount = 0;
	
	// Count # of visible controls
	for (%i = 0; %i < %Container.getCount(); %i++)
	{
		%child = %Container.getObject(%i);
		if (!%child.isVisible())
			continue;
		
		%nodeCount++;
	}
	
	// Calculate the new size of everything
	%maxPerRow        = %this.maxPerRow;
	%maxPerCol        = %this.maxPerCol;
	%btnSize          = %this.buttonSize;
	%scroll_width     = (mClamp(%nodeCount, 0, %maxPerRow) * %btnSize) + 16;
	%scroll_height    = mClamp(mCeil(%nodeCount / %maxPerRow), 1, %maxPerCol) * %btnSize;
	%container_width  = mClamp(%nodeCount, 0, %maxPerRow) * %btnSize;
	%container_height = (mCeil(%nodeCount / %maxPerRow) * %btnSize) - (%nodeCount < %maxPerRow ? 2 : 0);
	%nodeCount        = -1;
	
	// Apply those sizes
	%this.setExtent(%scroll_width, %scroll_height);
	%Container.setExtent(%container_width, %container_height);
	%Container.setPosition(0, 0);
	
	// Re-position everything
	for (%i = 0; %i < %Container.getCount(); %i++)
	{
		%child = %Container.getObject(%i);
		if (!%child.isVisible())
			continue;
		
		%nodeCount++;
		%child.setPosition((%nodeCount % %maxPerRow) * %btnSize, mFloor(%nodeCount / %maxPerRow) * %btnSize);
	}
}

function AvatarEditGui::deleteFavorite(%this, %file, %object, %confirm)
{
	if (!%confirm)
	{
		messageBoxYesNo("CONFIRMATION - B4v21 Launcher", "Are you sure you want to delete \"" @ %file @ "\"?", "AvatarEditGui.deleteFavorite(\"" @ strReplace(strReplace(%file, "\\", "\\\\"), "\"", "\\\"") @ "\", \"" @ %object @ "\", 1);");
		return;
	}
	
	// Delete it
	fileRealDelete(strReplace(%file, "\\", "/"));
	
	// Check to see if we've deleted it
	if (isFile(%file, true))
	{
		messageBoxOk("ERROR - B4v21 Launcher", "Failed to delete \"" @ %file @ "\"!");
		return;
	}
	
	%object.delete();
	%this.updatePresetList();
	
	if (AEGM_hasFreeAvatarSlot(%this.so) && !isObject(%this.findObjectByInternalName("AvatarShape_" @ strHash("new"), true)))
	{
		%this.addPreview("new");
		%Object = %this.findObjectByInternalName("AvatarShape_" @ strHash("new"), true).getGroup().getGroup();
		%Object.getGroup().pushToBack(%Object);
	}
}

function AvatarEditGui::resetToDefault(%this, %confirm)
{
	if (!%confirm)
	{
		messageBoxYesNo("B4v21 Launcher", "Are you sure you want to reset this avatar? You will lose all progress.", "AvatarEditGui.resetToDefault(1);");
		return;
	}
	
	AEGM_SetDefaultAvatar();
	
	// Update everything
	%this.customizeShape(%this.e_AvatarPreview);
	%this.updateEditTabs();
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------------------

function AvatarFavoritePreview::onMouseUp(%this)
{
	AEGM_PreviewClicked(%this);
}

function AvatarFavoritePreview::onRightMouseUp(%this)
{
	if (!isObject(%CM = AvatarEditGui.contextMenu))
	{
		%CM = new GuiContextMenuCtrl(AvatarEditorContextMenu)
		{
			profile   = "LauncherContextMenuProfile";
			minExtent = "0 0";
			extent    = "1 0";
			autoSize  = "1";
		};
		
		AvatarEditGui.contextMenu = %CM.getId();
	}
	
	// Set the state of the context menu
	%fileName   = %this.getGroup().getGroup().avatarFile;
	%CM.cobject = %this.getId();
	%CM.context = "PREVIEW" @ (%fileName $= "new" ? "_NEW" : "");
	
	// Populate the context menu
	%CM.clearItems();
	if (%fileName $= "new")
	{
		%CM.addItem("Edit", 0);
		%CM.addItem("Create New Avatar", 1);
	}
	else
	{
		%CM.addItem("Edit", 0);
		%CM.addSeperator();
		%CM.addItem("Open File Location", 1);
		%CM.addSeperator();
		%CM.addItem("Delete", 2);
	}
	
	// Show the context menu where the user's cursor is
	if (!%CM.isAwake())
		AvatarEditGui.add(%CM);
	
	%CM.setVisible(true);
	%CM.forceRefit();
	%CM.setPosition(getWord(Canvas.getCursorPos(), 0), getWord(Canvas.getCursorPos(), 1));
}

function AvatarEditorMainPreview::onRightMouseUp(%this)
{
	if (!isObject(%CM = AvatarEditGui.contextMenu))
	{
		%CM = new GuiContextMenuCtrl(AvatarEditorContextMenu)
		{
			profile   = "LauncherContextMenuProfile";
			minExtent = "0 0";
			extent    = "1 0";
			autoSize  = "1";
		};
		
		AvatarEditGui.contextMenu = %CM.getId();
	}
	
	// Set the state of the context menu
	%fileName     = %this.getGroup().getGroup().avatarFile;
	%this.cstart  = 2;
	%this.cstart2 = %this.cstart;
	%CM.cobject   = %this.getId();
	%CM.context   = "MAIN_PREVIEW";
	
	// Populate the context menu
	%CM.clearItems();
	%CM.addItem("Reset Rotation", 0);
	
	// Animation submenu
	if (isObject(%db = ("mDts" @ AvatarEditGui.so.version)))
	{
		%CM.addSeperator();
		%subMenu = %CM.addMenu("Animation");
		%i       = -1;
		while (true)
		{
			%i++;
			
			// Get the sequence from the datablock. We cannot do it w/ square brackets because Torque sucks.
			%sequence = eval("return " @ %db.getId() @ ".sequence" @ %i @ ";");
			
			// We reached the last sequence this datablock has to offer.
			if (%sequence $= "")
				break;
			
			// Get the sequence name
			%name = getWord(%sequence, getWordCount(%sequence) - 1);
			
			// Add to sub menu
			%subMenu.addItem(strUpr(getSubStr(%name, 0, 1)) @ strLwr(getSubStr(%name, 1, strLen(%name))), %this.cstart + %i);
			
			// Increment the start id for the custom options button
			%this.cstart2++;
		}
	}
	
	// Custom options
	AEGM_PopulatePreviewContextMenu(AvatarEditGui.so, %CM, %this.cstart2);
	
	// Other options
	%CM.addSeperator();
	%CM.addItem("Reset to Default", 1);
	
	// Show the context menu where the user's cursor is
	if (!%CM.isAwake())
		AvatarEditGui.add(%CM);
	
	%CM.setVisible(true);
	%CM.forceRefit();
	%CM.setPosition(getWord(Canvas.getCursorPos(), 0), getWord(Canvas.getCursorPos(), 1));
}

function AvatarEditorContextMenu::onSelect(%this, %rowID, %rowText)
{
	switch$(%this.context)
	{
		case "PREVIEW": // Avatar Preview
			switch(%rowID)
			{
				case 0: // Edit
					AvatarEditGui.loadAvatar(%this.cobject.getGroup().getGroup().avatarFile, %this.cobject);
					
				case 1: // Open file location
					openInExplorer(strReplace(filePath(strReplace(%this.cobject.getGroup().getGroup().avatarFile, "\\", "/")), "/", "\\") @ "\\");
					
				case 2: // Delete
					AvatarEditGui.deleteFavorite(%this.cobject.getGroup().getGroup().avatarFile, %this.cobject.getGroup().getGroup());
			}
		case "PREVIEW_NEW": // Avatar Preview ('new avatar' avatar)
			switch(%rowID)
			{
				case 0: // Edit
					AvatarEditGui.loadAvatar("new", %this.cobject);
					
				case 1: // Create New Avatar
					AvatarEditGui.loadAvatar("new-nobase", %this.cobject);
			}
		case "MAIN_PREVIEW": // Editor preview
			switch(%rowID)
			{
				case 0: // Reset Rotation
					%this.cobject.ResetView(1);
					
				case 1: // Reset to Default
					AvatarEditGui.resetToDefault();
					
				default: // Play an animation
					if (%rowID >= %this.cobject.cstart2)
					{
						AEGM_UsePreviewContextMenu(AvatarEditGui.SO, %this.cobject.getId(), %this.getId(), %rowID - %this.cobject.cstart2);
						return;
					}
					
					if (%rowID < %this.cobject.cstart || !isObject(%db = ("mDts" @ AvatarEditGui.so.version)))
						return;
					
					%sequence = eval("return " @ %db.getId() @ ".sequence" @ atoi(%rowID  - %this.cobject.cstart) @ ";");
					%seqName  = getWord(%sequence, getWordCount(%sequence) - 1);
					%this.cobject.playThread("", 0, %seqName);
			}
	}
}