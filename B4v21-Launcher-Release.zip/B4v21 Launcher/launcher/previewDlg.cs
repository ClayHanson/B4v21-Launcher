function joinServerPreviewDlg::onWake(%this)
{
	%window = %this.getObject(0);
	%window.setPosition((getWord(getRes(), 0) / 2) - (getWord(%window.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%window.getExtent(), 1) / 2));
	
	%this.findObjectByInternalName("PlayerList", true).clear();
}

function joinServerPreviewDlg::onSleep(%this)
{
	if (isObject(PreviewTCPObj))
	{
		PreviewTCPObj.disconnect();
		PreviewTCPObj.delete();
	}
}

function joinServerDlg::openPreview(%this)
{
	%this = joinServerPreviewDlg;
	if (!isObject(%o = $Launcher::JoinServerDlg::LastSelectedChild))
		return;
	
	%ver   = getField(%o.getRowTextById(%o.getSelectedId()), 11);
	%ip    = getField(%o.getRowTextById(%o.getSelectedId()), 9);
	%port  = getField(%o.getRowTextById(%o.getSelectedId()), 10);
	%sName = getField(%o.getRowTextById(%o.getSelectedId()), 2);
	
	Canvas.pushDialog(%this);
	%this.findObjectByInternalName("ServerName", true).setText(%sName);
	%this.findObjectByInternalName("ServerVersion", true).setText("Version: " @ %ver);
	%this.findObjectByInternalName("PreviewImage", true).setBitmap("http://image.blockland.us/detail/" @ strReplace(%ip, ".", "-") @ "_" @ %port @ ".jpg");
	%this.getObject(0).setText("Preview " @ %sName @ " - B4v21 Launcher");
	
	FetchPlayerListPreview(%ip, %port);
}

function FetchPlayerListPreview(%ip, %port)
{
	if (isObject(PreviewTCPObj))
	{
		PreviewTCPObj.disconnect();
		PreviewTCPObj.delete();
	}
	
	%TO         = new TCPObject(PreviewTCPObj);
	%TO.count   = 0;
	%TO.list    = joinServerPreviewDlg.findObjectByInternalName("PlayerList", true);
	%TO.headers = true;
	%TO.post    = "c=GETSERVERINFO&arg1=" @ %ip @ "&arg2=" @ %port;
	%TO.cmd     = "POST /api/v1/apiRouter.php?d=APISB HTTP/1.0\r\nHost: b4v21.block.land\r\nUser-Agent: B4v21Launcher-v" @ getLauncherVersion() @ "\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: " @ strLen(%TO.post) @ "\r\nConnection: close\r\n\r\n" @ %TO.post @ "\r\n";
	%TO.connect("b4v21.block.land:80");
}

function PreviewTCPObj::onConnectFailed(%this)
{
	messageBoxOk("ERROR - B4v21 Launcher", "Failed to fetch player list!\n(Connection Failed)");
	%this.list.addRow(%id, "-- Player list not available --");
}

function PreviewTCPObj::onDNSFailed(%this)
{
	messageBoxOk("ERROR - B4v21 Launcher", "Failed to fetch player list!\n(DNS Lookup Failed)");
	%this.list.addRow(%id, "-- Player list not available --");
}

function PreviewTCPObj::onConnected(%this)
{
	%this.send(%this.cmd);
}

function PreviewTCPObj::onDisconnected(%this)
{
	if (%this.count == 0)
		%this.list.addRow(%id, "-- Player list not available --");
}

function PreviewTCPObj::onLine(%this, %line)
{
	if (%this.headers)
	{
		if (%line $= "")
			%this.headers = false;
		
		return;
	}
	
	if (getField(%line, 1) $= "0")
		%this.list.addRow(%id, "-- This server isn't using RTB --");
	
	if (getField(%line, 1) !$= "PLIST")
		return;
	
	%list = strReplace(removeField(removeField(%line, 0), 0), "~", "\t");
	
	if (getFieldCount(%list) == 0 || (getFieldCount(%list) == 1 && %list $= ""))
	{
		%this.list.addRow(%id, "-- Either this server isn't using RTB, or it's empty --");
		return;
	}
	
	for (%i = 0; %i < getFieldCount(%list); %i++)
	{
		%client = strReplace(getField(%list, %i), ";", "\t");
		%name   = getField(%client, 0);
		%score  = getField(%client, 1);
		%rank   = getField(%client, 2);
		%bl_id  = getField(%client, 3);
		
		%this.count++;
		
		// Replace BL_ID with text if necessary
		if (%bl_id == -1)
			%bl_id = "LAN";
		
		// Determine rank
		switch(%rank)
		{
			case 1:  %rank = "A";
			case 2:  %rank = "S";
			case 3:  %rank = "H";
			default: %rank = "-";
		}
		
		%this.list.addRow(%i, %rank TAB %name TAB %score TAB %bl_id);
	}
}