function joinServerPreviewDlg::onWake(%this) {
	%window = %this.getObject(0);
	%window.setPosition((getWord(getRes(), 0) / 2) - (getWord(%window.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%window.getExtent(), 1) / 2));
	
	%this.findObjectByInternalName("PlayerList", true).clear();
	%this.findObjectByInternalName("PlayerList", true).addRow(0, "-- Player list not available --");
}

function joinServerDlg::openPreview(%this) {
	%this = joinServerPreviewDlg;
	
	if(!isObject(%o = $Launcher::JoinServerDlg::LastSelectedChild)) return;
	%ver   = getField(%o.getRowTextById(%o.getSelectedId()), 10);
	%ip    = getField(%o.getRowTextById(%o.getSelectedId()), 8);
	%port  = getField(%o.getRowTextById(%o.getSelectedId()), 9);
	%sName = getField(%o.getRowTextById(%o.getSelectedId()), 2);
	
	Canvas.pushDialog(%this);
	%this.findObjectByInternalName("ServerName", true).setText(%sName);
	%this.findObjectByInternalName("ServerVersion", true).setText("Version: " @ %ver);
	%this.findObjectByInternalName("PreviewImage", true).setBitmap("http://image.blockland.us/detail/" @ strReplace(%ip, ".", "-") @ "_" @ %port @ ".jpg");
	%this.getObject(0).setText("Preview " @ %sName @ " - B4v21 Launcher");
}