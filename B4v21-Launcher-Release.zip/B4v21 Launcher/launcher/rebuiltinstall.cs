// kenko
function InstallRebuilt()
{
	if (isObject(RebuiltBlobQuery))
		RebuiltBlobQuery.delete();
	
	%tcp         = new TCPObject(RebuiltBlobQuery);
	%tcp.authKey = "";
	%tcp.auth    = true;
	%tcp.qa      = false;
	$LauncherKey = "";
	$IsRebuiltQA = false;
	
	%tcp.connect("b4v21.block.land:80");
	
	echo("Reading blob list...");
}

function InstallRebuiltQA()
{
	if (isObject(RebuiltBlobQuery))
		RebuiltBlobQuery.delete();
	
	%tcp         = new TCPObject(RebuiltBlobQuery);
	%tcp.authKey = "";
	%tcp.auth    = true;
	%tcp.qa      = true;
	$LauncherKey = "";
	$IsRebuiltQA = true;
	
	%tcp.connect("b4v21.block.land:80");
	
	echo("Reading blob list...");
}

function RebuiltBlobQuery::onDNSFailed(%this)
{
}

function RebuiltBlobQuery::onConnectFailed(%this)
{
}

function RebuiltBlobQuery::onDisconnect(%this)
{
	if (%this.auth)
	{
		if (%this.authKey $= "")
		{
			error("ERROR: Failed to authenticate correctly with B4v21 services.");
			return;
		}
		
		%this.auth = false;
		%this.connect("b4v21.block.land:80");
		return;
	}
	
	%this.schedule(1, delete);
	echo("Got " @ $Rebuilt::BLOBCOUNT @ " blob(s). Downloading...");
	DownloadRebuiltBlobs();
}

function RebuiltBlobQuery::onConnected(%this)
{
	if (%this.qa)
	{
		if (%this.auth)
		{
			%this.send("GET /api/versions/rebuilt-qa/auth.php HTTP/1.0\r\nHost: b4v21.block.land\r\nUser-Agent: blocklandWIN/2.0\r\nConnection: close\r\n\r\n");
		}
		else
		{
			%this.send("GET /api/versions/rebuilt-qa/update.php HTTP/1.0\r\nHost: b4v21.block.land\r\nUser-Agent: blocklandWIN/2.0\r\nConnection: close\r\n\r\n");
		}
	}
	else
	{
		if (%this.auth)
		{
			%this.send("GET /api/versions/rebuilt/auth.php HTTP/1.0\r\nHost: b4v21.block.land\r\nUser-Agent: blocklandWIN/2.0\r\nConnection: close\r\n\r\n");
		}
		else
		{
			%this.send("GET /api/versions/rebuilt/update.php HTTP/1.0\r\nHost: b4v21.block.land\r\nUser-Agent: blocklandWIN/2.0\r\nConnection: close\r\n\r\n");
		}
	}
	
	deleteVariables("$Rebuilt::DELETE*");
	deleteVariables("$Rebuilt::BLOB*");
	
	%this.headers         = true;
	$Rebuilt::BLOBCOUNT   = 0;
	$Rebuilt::CURRENTBLOB = 0;
}

function RebuiltBlobQuery::onLine(%this, %line)
{
	if (%this.headers)
	{
		if (%line $= "")
			%this.headers = false;
		
		return;
	}
	
	switch$ (getField(%line, 0))
	{
		case "AUTH":
			if (%this.authKey !$= "")
				return;
			
			%this.authKey = removeField(%line, 0);
			$LauncherKey  = %this.authKey;
			
		case "FULLZIP":
			if (%this.auth)
				return;
			
			$Rebuilt::BLOB::FULL_ZIP                       = removeField(%line, 0);
			
		case "BLOB":
			if (%this.auth)
				return;
			
			$Rebuilt::BLOB[-1 + $Rebuilt::BLOBCOUNT++]     = removeField(%line, 0);
			
		case "DELETE":
			if (%this.auth)
				return;
			
			$Rebuilt::DELETE[-1 + $Rebuilt::DELETECOUNT++] = removeField(%line, 0);
			
		case "ERROR":
			error("Rebuilt Update ERROR: \"" @ removeField(%line, 0) @ "\"");
			
		case "DOWNLOADURL":
			if (%this.auth)
				return;
			
			%url  = getField(%line, 1);
			%url  = getSubStr(%url, strStr(%url, "://") != -1 ? strStr(%url, "://") + 3 : 0, strLen(%url));
			%url  = strReplace(%url, "/", "\t");
			%host = getField(%url, 0);
			%path = strReplace(removeField(%url, 0), "\t", "/");
			
			$Rebuilt::BLOBHOST = %host;
			$Rebuilt::BLOBPATH = "/" @ %path @ "/";
	}
}

function onRebuiltBlobDownloadStart(%id)
{
	onVersionDownloadStart(%id);
	if (!$QuickLaunch)
	{
		$Launcher::VersMgr::CurrentlyDownloading.downloadId = %id;
		$Launcher::VersMgr::CurrentlyDownloading.hasStarted = true;
	}
}

function onRebuiltBlobDownloadFailed(%reason)
{
	if (!$Rebuilt::INSTALLZIP)
		CancelRebuiltBlobs();
	
	if ($QuickLaunch)
	{
		MiniLauncherDlg.findObjectByInternalName("ProgressText", true).setText("<font:Consolas:18><just:center>Download Failed - \"" @ %reason @ "\"");
		MiniLauncherDlg.findObjectByInternalName("ProgressBar", true).setValue(-1);
		return;
	}
	
	onVersionDownloadFailed(%reason);
}

function onRebuiltBlobDownloadDone()
{
	$Rebuilt::CURRENTBLOB++;
	
	if ($Rebuilt::CURRENTBLOB >= $Rebuilt::BLOBCOUNT)
		onVersionDownloadDone($Rebuilt::INSTALLPATH @ getBlocklandExe("rebuilt" @ ($IsRebuiltQA ? "qa" : "")));
}

function onRebuiltBlobDownloadProgress(%curr, %max, %transferRate)
{
	if ($QuickLaunch)
	{
		%pText = (%curr >= %max ? getFancyByteString(%curr) : getFancyByteString(%curr) @ " / " @ getFancyByteString(%max));
		
		MiniLauncherDlg.findObjectByInternalName("ProgressText", true).setText("<font:Consolas:18><just:center>Downloading " @ $Rebuilt::CURRENTBLOB @ " / " @ $Rebuilt::BLOBCOUNT @ " @ " @ getFancyByteString(%transferRate) @ " (" @ %pText @ ")");
		MiniLauncherDlg.findObjectByInternalName("ProgressBar", true).setValue(%curr >= %max ? -1 : %curr / %max);
		return;
	}
	
	if (!isObject($Launcher::VersMgr::CurrentlyDownloading))
		return;
	
	%cVer = ($QuickLaunch ? $QuickLaunchVersion : $Launcher::VersMgr::CurrentlyDownloading.version);
	%cIdx = ($QuickLaunch ? -1 : $Launcher::VersMgr::CurrentlyDownloading.versionIdx);
	
	// Little detail
	%dotTime = 600;
	%dots    = getSubStr("...", 0, mFloor((getSimTime() % (%dotTime * 4)) / %dotTime));
	$Launcher::VersMgr::CurrentlyDownloading.getObject(2).setText("<color:000000><font:Palatino Linotype:18>DOWNLOADING" @ %dots);
	
	%pBar = (!versionManagerGui.isAwake() ? PortableProgressWindow.getObject(0) : versionManagerGui.findObjectByInternalName("ProgressBar", true));
	
	if (!versionManagerGui.isAwake() && PortableProgressWindow.getGroup() != Canvas.getObject(Canvas.getCount() - 1))
	{
		Canvas.getObject(Canvas.getCount() - 1).add(PortableProgressWindow);
		
		if (!PortableProgressWindow.isVisible())
		{
			PortableProgressWindow.setVisible(1);
			PortableProgressWindow.setPosition(getWord(getRes(), 0) - getWord(PortableProgressWindow.getExtent(), 0), getWord(getRes(), 1) - getWord(PortableProgressWindow.getExtent(), 1));
		}
	}
	else if (versionManagerGui.isAwake() && PortableProgressWindow.getGroup() != versionManagerGui.getId())
	{
		versionManagerGui.add(PortableProgressWindow);
		PortableProgressWindow.setVisible(0);
	}
	
	%pText = "<font:Consolas:18><just:center>";
	%pText = %pText @ (%curr >= %max ? getFancyByteString(%curr) : getFancyByteString(%curr) @ " / " @ getFancyByteString(%max));
	%pText = %pText SPC "@ " @ getFancyByteString(%transferRate) @ "/s" @ ($Rebuilt::BLOBCOUNT == 1 ? "" : " [" @ $Rebuilt::CURRENTBLOB @ " / " @ $Rebuilt::BLOBCOUNT @ "]");
	
	%pBar.setValue((%curr >= %max ? $Rebuilt::CURRENTBLOB / $Rebuilt::BLOBCOUNT : %curr /  %max));
	%pBar.getObject(0).setText(%pText);
}

function CancelRebuiltBlobs()
{
	if ($Rebuilt::INSTALLZIP)
	{
		cancelDownload($Rebuilt::BLOB[0]);
	}
	else
	{
		for (%i = $Rebuilt::BLOBCOUNT - 1; %i >= 0; %i--)
			cancelDownload(getField($Rebuilt::BLOB[%i], 3));
	}
	
	deleteVariables("$Rebuilt::BLOB*");
}

function DownloadRebuiltBlobs()
{
	if ($QuickLaunch)
		%installPath = $QuickLaunch_Rebuilt_Path;
	else if ($Launcher::VersMgr::CurrentlyDownloading.customPath !$= "")
		%installPath = $Launcher::VersMgr::CurrentlyDownloading.customPath;
	else if ($Launcher::VersMgr::CurrentlyDownloading.customDownloadPath !$= "")
		%installPath = $Launcher::VersMgr::CurrentlyDownloading.customDownloadPath;
	else
		%installPath = $pref::Launcher::Location @ "Blockland Rebuilt" @ ($IsRebuiltQA ? " QA" : "") @ "\\";
	
	%downloadCount = 0;
	%blobCount     = 0;
	
	// Delete files marked for deletion, first
	for (%i = 0; %i < $Rebuilt::DELETECOUNT; %i++)
	{
		%deleteInfo = strReplace($Rebuilt::DELETE[%i], "/", "\\");
		%filePath   = %installPath @ getField(%deleteInfo, 0);
		%fileCrc    = getField(%deleteInfo, 1);
		
		// File does not exist.
		if (!isFile(%filePath))
			continue;
		
		// File matches the CRC? Delete it!
		if (%fileCrc $= getFileCRC(%filePath))
		{
			echo("Deleted deprecated file \"" @ %filePath @ "\"");
			fileRealDelete(%filePath);
		}
	}
	
	// Download files
	for (%i = 0; %i < $Rebuilt::BLOBCOUNT; %i++)
	{
		%currentBlob = strReplace($Rebuilt::BLOB[%i], "/", "\\");
		%fileCRC     = getField(%currentBlob, 0);
		%fileBlob    = getField(%currentBlob, 1);
		%filePath    = getField(%currentBlob, 2);
		%fileInstall = %installPath @ %filePath;
		%fileName    = fileName(%filePath);
		
		// DON'T replace config files
		if (strPos(strLwr(%filePath), "config") != -1 && isFile(%fileInstall))
			continue;
		
		if ($Rebuilt::verbose)
			echo("Checking \"" @ %filePath @ "\"...");
		
		%fileCurrCrc = getFileCRC(%fileInstall);
		if (!isFile(%fileInstall))
		{
			if ($Rebuilt::verbose)
				echo("   > File does not exist; downloading...");
		}
		else if (%fileCurrCrc $= %fileCRC)
		{
			if ($Rebuilt::verbose)
				echo("   > Up-to-date, not downloading");
			
			continue;
		}
		else
		{
			if ($Rebuilt::verbose)
				echo("   > CRC mismatch! Expected " @ %fileCRC @ ", but we have " @ %fileCurrCrc @ "!");
		}
		
		%blobs[-1 + %blobCount++] = $Rebuilt::BLOB[%i];
	}
	
	if ($Rebuilt::BLOBCOUNT == %blobCount)
	{
		// Download the zip instead
		%host    = getField($Rebuilt::BLOB::FULL_ZIP, 0);
		%port    = getField($Rebuilt::BLOB::FULL_ZIP, 1);
		%path    = getField($Rebuilt::BLOB::FULL_ZIP, 2);
		%FileCRC = getField($Rebuilt::BLOB::FULL_ZIP, 3);
		%zipFile = strReplace(%installPath @ "archive.zip", "\\", "/");
		
		$Rebuilt::INSTALLPATH = %installPath;
		$Rebuilt::INSTALLZIP  = true;
		
		deleteVariables("$Rebuilt::BLOB*");
		
		if (isFile(%zipFile) && getFileCRC(%zipFile) $= %FileCRC)
		{
			onVersionDownloadDone($Rebuilt::INSTALLPATH @ getBlocklandExe("rebuilt" @ ($IsRebuiltQA ? "qa" : "")));
			return;
		}
		
		createPath("&" @ filePath(%zipFile) @ "/");
		$Rebuilt::BLOB[-1 + $Rebuilt::BLOBCOUNT++] = downloadFile((%port == 443 ? "https://" : "http://") @ %host @ %path, %zipFile, "onRebuiltBlobDownloadDone", "onRebuiltBlobDownloadProgress", "onRebuiltBlobDownloadStart", "onVersionDownloadFailed");
		return;
	}
	
	$Rebuilt::INSTALLPATH = %installPath;
	$Rebuilt::INSTALLZIP  = false;
	%host                 = $Rebuilt::BLOBHOST;
	%path                 = $Rebuilt::BLOBPATH;
	
	deleteVariables("$Rebuilt::BLOB*");
	
	for (%i = 0; %i < %blobCount; %i++)
	{
		%currentBlob = strReplace(%blobs[%i], "/", "\\");
		%fileCRC     = getField(%currentBlob, 0);
		%fileBlob    = getField(%currentBlob, 1);
		%filePath    = getField(%currentBlob, 2);
		%fileInstall = %installPath @ %filePath;
		%fileName    = fileName(strReplace(%filePath, "\\", "/"));
		
		createPath("&" @ filePath(strReplace(%fileInstall, "\\", "/")) @ "/");
		%id                                        = downloadFile("http://" @ %host @ %path @ %fileBlob, filePath(strReplace(%fileInstall @ "/" @ %fileName, "\\", "/")), "onRebuiltBlobDownloadDone", "onRebuiltBlobDownloadProgress", "onRebuiltBlobDownloadStart", "onVersionDownloadFailed");
		$Rebuilt::BLOB[-1 + $Rebuilt::BLOBCOUNT++] = %blobs[%i] TAB %id;
		%downloadCount++;
	}
	
	if (!%downloadCount)
		onVersionDownloadDone(%installPath @ getBlocklandExe("rebuilt" @ ($IsRebuiltQA ? "qa" : "")));
	else
		echo("Downloading " @ %downloadCount @ " blob" @ (%downloadCount == 1 ? "" : "s"));
}