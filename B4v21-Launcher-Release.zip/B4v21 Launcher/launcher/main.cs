// B4v21 Launcher

function fileRename(%file, %newName)
{
	%oldPath = strReplace(%file, "\\", "/");
	%newPath = filePath(%oldPath) @ "/" @ %newName;
	
	if (%file $= "" || !isFile(%oldPath))
		return;
	
	fileCopy(strReplace(%oldPath, "/", "\\"), strReplace(%newPath, "/", "\\"));
	fileRealDelete(strReplace(%oldPath, "/", "\\"));
}

function GetLauncherAbsolutePath()
{
	%ret = filePath(strReplace($Game::Argv[0], "\\", "/"));
	return %ret @ "/";
}

function GetLauncherContainerPath()
{
	%ret = filePath(filePath(strReplace($Game::Argv[0], "\\", "/")));
	return %ret @ "/";
}

if (isDebugMode())
	enableWinConsole(true);

// Audio
$GuiAudioType     = 1;
$SimAudioType     = 2;
$MessageAudioType = 3;

new AudioDescription(AudioGui) {
   volume   = 0.7;
   isLooping= false;
   is3D     = false;
   type     = $GuiAudioType;
};

new AudioDescription(AudioMessage) {
   volume   = 0.7;
   isLooping= false;
   is3D     = false;
   type     = $MessageAudioType;
};

// Variables
$Pref::Launcher::CloseOnLaunch = false;
$Pref::Launcher::AutoUpdate    = true;
$Pref::Launcher::Location      = GetLauncherContainerPath() @ "versions/";
$Pref::Net::DesiredExperience  = 1;

$Pref::Audio::MainMenuButtons = 1;
$pref::Net::LagThreshold = 400;

$pref::shadows           = "2";
$pref::HudMessageLogSize = 40;
$pref::ChatHudLength     = 1;

$pref::Input::LinkMouseSensitivity = 1;
$pref::Input::KeyboardEnabled      = 1;
$pref::Input::MouseEnabled         = 1;

$pref::Video::displayDevice       = "OpenGL";
$pref::Video::clipHigh            = "0";
$pref::Video::allowOpenGL         = 1;
$pref::Video::allowD3D            = 1;
$pref::Video::preferOpenGL        = 1;
$pref::Video::appliedPref         = 1;
$pref::Video::disableVerticalSync = 1;
$pref::Video::deleteContext       = 1;
$pref::Video::monitorNum          = 0;
$pref::Video::windowedRes         = "1280 720";
$pref::Video::resolution          = "1280 720 32";
$pref::Video::screenShotFormat    = "PNG";

$pref::OpenGL::allowTexGen          = "1";
$pref::OpenGL::noEnvColor           = "1";
$pref::OpenGL::force16BitTexture    = "0";
$pref::OpenGL::forcePalettedTexture = "0";
$pref::OpenGL::maxHardwareLights    = 3;
$pref::VisibleDistanceMod           = 1;

$pref::Audio::driver                 = "OpenAL";
$pref::Audio::forceMaxDistanceUpdate = 0;
$pref::Audio::environmentEnabled     = 0;
$pref::Audio::masterVolume           = 0.8;
$pref::Audio::channelVolume1         = 0.8;
$pref::Audio::channelVolume2         = 0.8;
$pref::Audio::channelVolume3         = 0.8;
$pref::Audio::channelVolume4         = 0.8;
$pref::Audio::channelVolume5         = 0.8;
$pref::Audio::channelVolume6         = 0.8;
$pref::Audio::channelVolume7         = 0.8;
$pref::Audio::channelVolume8         = 0.8;

$QuickLaunch = false;

//-----------------------------------------------------------------------------
// Package overrides to initialize the game
function onStart() {
	// Initialize the client and the server
	initClient();
}

function onExit() {
	// Save off our current preferences for next time
}

//-----------------------------------------------------------------------------
// Simple pref handlers
function ApplyNetExperience() {
	%exp = $Pref::Net::DesiredExperience;
	
	switch(%exp) {
		case 0: // Fast
			$TCPQuery::StepsPerRead = 16;
			$TCPQuery::SizePerRead  = $TCPQuery::MaxSizePerRead;
		case 1: // Moderate
			$TCPQuery::StepsPerRead = 8;
			$TCPQuery::SizePerRead  = $TCPQuery::MaxSizePerRead / 2;
		case 2: // Slow
			$TCPQuery::StepsPerRead = 2;
			$TCPQuery::SizePerRead  = $TCPQuery::MaxSizePerRead / 4;
	}
}

//-----------------------------------------------------------------------------

function DoesQuickLaunchMatch(%rawVer, %SO)
{
	if (isObject($QuickLaunchSO) && %SO != $QuickLaunchSO)
		return false;
	
	if (isObject(%SO))
		return (%so.identID $= $QuickLaunchVersion || (%so.cName !$= "" && $QuickLaunchVersion $= %so.cName) || $QuickLaunchVersion $= %rawVer || $QuickLaunchVersion $= getBlocklandName(%rawVer));
	
	return ($QuickLaunchVersion $= %rawVer || $QuickLaunchVersion $= getBlocklandName(%rawVer));
}

function onQuickLaunchSuccess()
{
	%SO        = $QuickLaunchSO;
	%cVer      = %SO.version;
	%cPath     = %SO.path;
	%installed = %SO.installed;
	
	if (!isFile(%cPath @ getBlocklandExe(%cVer)))
		return;
	
	echo("QUICKLAUNCH: Done! Game is up-to-date. Launching...");
	
	launchExe(%cPath @ getBlocklandExe(%cVer), "ptlaaxobimwroe" @ ($QuickLaunchDedicated ? " -dedicated" @ ($QuickLaunchDedicated == 2 ? "Lan" : "") SPC "-map bedroom" : "") @ (%cVer $= "RTB" ? " -game rtb" : "") @ ($QuickLaunchDedicated != 0 && %cVer $= "0002" ? " -game fps -mission \"fps/data/missions/bedroom.mis\"" : ""));
	quit();
}

function onQuickLaunchFail()
{
	%BLName = getBlocklandName($QuickLaunchVersion);
	switch$($QuickLaunchFail) {
		case "NEWER_VERSION":
			echo("QUICKLAUNCH: Version " @ $QuickLauncherVersion @ " has an update available!");
			if (!$Quiet)
			{
				%result = realMessageBox("UPDATE - B4v21 Launcher", %BLName @ " has an older patch version than what is currently available. Do you want to revert to the current version?", "YESNO ICONQUESTION DEFBUTTON2");
				if (%result $= "NO")
				{
					onQuickLaunchSuccess();
					return;
				}
			}
			
			if (!$Quiet)
			{
				%result = realMessageBox("CONFIRMATION - B4v21 Launcher", "Are you sure you want to revert " @ %BLName @ " to Patch Version v" @ $QuickLaunchSO.newPatchVersion @ "?", "YESNO ICONQUESTION DEFBUTTON2");
				if (%result $= "NO")
				{
					onQuickLaunchSuccess();
					return;
				}
			}
			
			initQuickLaunchGUI();
			exec("./launcherUpdate.cs");
			updateVersion($QuickLaunchSO.path);
			return;
			
		case "SPECIAL":
			error("QUICKLAUNCH ERROR: Version " @ $QuickLaunchVersion @ " shouldn't be managed by this launcher!");
			realMessageBox("ERROR - B4v21 Launcher", "Please use the real Blockland Auto-updator to launch Blockland v21.");
			quit();
			return;
			
		case "UPDATE_REQUIRED":
			warn("QUICKLAUNCH: Version " @ $QuickLauncherVersion @ " requires an update!");
			if (!$Quiet)
			{
				%result = realMessageBox("MANDATORY UPDATE - B4v21 Launcher", %BLName @ " has a mandatory update available. Do you want to install it?\r\n\r\nWARNING: Continuing without updating is NOT recommended!", "YESNO ICONQUESTION DEFBUTTON1");
				if (%result $= "NO")
				{
					onQuickLaunchSuccess();
					return;
				}
			}
			
			initQuickLaunchGUI();
			exec("./launcherUpdate.cs");
			updateVersion($QuickLaunchSO.path);
			return;
			
		case "UPDATE_AVAILABLE":
			echo("QUICKLAUNCH: Version " @ $QuickLauncherVersion @ " has an update available!");
			if (!$Quiet)
			{
				%result = realMessageBox("UPDATE - B4v21 Launcher", %BLName @ " has an update available. Do you want to install it?", "YESNO ICONQUESTION DEFBUTTON1");
				if (%result $= "NO")
				{
					onQuickLaunchSuccess();
					return;
				}
			}
			
			initQuickLaunchGUI();
			exec("./launcherUpdate.cs");
			updateVersion($QuickLaunchSO.path);
			return;
			
		case "DOES_NOT_EXIST":
			error("QUICKLAUNCH ERROR: Unable to find any version / installation that goes by the name \"" @ $QuickLaunchVersion @ "\".");
			realMessageBox("ERROR - B4v21 Launcher", "We were unable to find any version / installations that go by the name \"" @ %BLName @ "\".", "OK ICONHALT DEFBUTTON1");
			quit();
			return;
			
		case "NOT_INSTALLED":
			error("QUICKLAUNCH ERROR: Version " @ $QuickLaunchVersion @ " is not installed!");
			if (!$Quiet)
			{
				%result = realMessageBox("ERROR - B4v21 Launcher", %BLName @ " is not installed. Do you want to install it?", "YESNO ICONQUESTION DEFBUTTON1");
				if (%result $= "NO")
				{
					quit();
					return;
				}
			}
			
			initQuickLaunchGUI();
			exec("./launcherUpdate.cs");
			updateVersion($pref::Launcher::Location @ getBlocklandName($QuickLaunchVersion) @ "\\");
			return;
			
		case "NOT_INSTALLED_DISCONNECTED":
			error("QUICKLAUNCH ERROR: Version " @ $QuickLaunchVersion @ " is not installed!");
			realMessageBox("ERROR - B4v21 Launcher", %BLName @ " is not installed, and there is no internet connection. The laucher cannot continue.", "OK ICONHALT DEFBUTTON1");
			quit();
			
		case "LAUNCHER_OUT_OF_DATE":
			error("QUICKLAUNCH ERROR: The launcher is out of date!");
			if (!$Quiet)
			{
				%result = realMessageBox("ERROR - B4v21 Launcher", "The B4v21 launcher is out of date! Do you want to install it now? (Selecting 'NO' will quit)", "YESNO ICONQUESTION DEFBUTTON1");
				if (%result $= "NO")
				{
					quit();
					return;
				}
			}
			
			if (!$Renamed)
			{
				%SO = new FileObject();
				%SO.openForWrite("./../LUpdate.bat");
				%SO.writeLine("@ECHO OFF");
				%SO.writeLine("TASKKILL /IM " @ fileName(strReplace($Game::Argv[0], "\\", "/")) @ " /F");
				%SO.writeLine("TIMEOUT /T 2");
				%SO.writeLine("RENAME \"" @ $Game::Argv[0] @ "\" OldLauncher.exe");
				%SO.writeLine("START \"\" \"OldLauncher.exe\" -launch 20 -quiet -renamed");
				%SO.writeLine("DEL LUpdate.bat");
				%SO.writeLine("EXIT");
				%SO.close();
				%SO.delete();
				schedule(100, 0, launchExe, strReplace(filePath(strReplace($Game::Argv[0], "\\", "/")), "/", "\\") @ "\\LUpdate.bat", "");
				schedule(500, 0, quit);
				return;
			}
			
			initQuickLaunchGUI();
			if ($Quiet)
			{
				exec("./launcherUpdate.cs");
				updateLauncher();
			}
			else
			{
				openChangelog(true, "exec(\"launcher/launcherUpdate.cs\");updateLauncher();");
			}
			
			return;
		case "EXTRACT_ERROR":
			error("QUICKLAUNCH ERROR: Version " @ $QuickLaunchVersion @ " failed to extract!");
			realMessageBox("ERROR - B4v21 Launcher", %BLName @ " failed to be properly extracted.", "OK ICONHALT DEFBUTTON1");
			quit();
			return;
	}
}

function initQuickLaunchGUI()
{
	initBaseVideo("640 480");
	
	// Load scripts
	exec("./profiles.cs");
	exec("./v21install.cs");
	exec("./MiniLauncherDlg.gui");
	
	// Start up the main menu...
	Canvas.setContent(MiniLauncherDlg);
	Canvas.setCursor(DefaultCursor);

	// For debugging the release build
	globalActionMap.bindCmd(keyboard, "ctrl d", "enableWinConsole(true);", "");
}

function initBaseVideo(%customRes)
{
	// Load prefs
	if(isFile("./prefs.cs"))
		exec("./prefs.cs");
	
	// Init canvas
	videoSetGammaCorrection($pref::OpenGL::gammaCorrection);
	
	if(%customRes !$= "")
	{
		%oldRes                   = $pref::Video::windowedRes;
		%oldRes2                  = $pref::Video::resolution;
		$pref::Video::windowedRes = %customRes;
		$pref::Video::resolution  = %customRes SPC "32";
	}
	
	%canvasCreate = createCanvas("B4v21 Launcher");
	if(%customRes !$= "")
	{
		$pref::Video::windowedRes = %oldRes;
		$pref::Video::resolution  = %oldRes2;
	}

	setOpenGLTextureCompressionHint($pref::OpenGL::compressionHint);
	setOpenGLAnisotropy($pref::OpenGL::textureAnisotropy);
	setOpenGLMipReduction($pref::OpenGL::mipReduction);
	setOpenGLInteriorMipReduction($pref::OpenGL::interiorMipReduction);
	setOpenGLSkyMipReduction($pref::OpenGL::skyMipReduction);
	
	// Init audio
	OpenALShutdownDriver();
	OpenALInitDriver();
	
	alxListenerf(AL_GAIN_LINEAR, 1);
	for(%channel=1; %channel <= 8; %channel++)
		alxSetChannelVolume(%channel, $pref::Audio::masterVolume);
	
	// Setup RNG
	setRandomSeed(getRealTime());
	
	// Copy saved script prefs into C++ code.
	setShadowDetailLevel($pref::shadows);
	setDefaultFov($pref::Player::defaultFov);
	setZoomSpeed($pref::Player::zoomSpeed);
	
	// For debugging the release build
	globalActionMap.bindCmd(keyboard, "ctrl d", "enableWinConsole(true);", "");
	if (isDebugMode())
		globalActionMap.bindCmd(keyboard, "alt enter", "setDisplayDevice(\"" @ $pref::Video::displayDevice @ "\", 1920, 1080, 32, 1);", "");
}

function openChangelog(%forceUpdate, %updateVer, %updateEval, %backButton)
{
	$lChangeGui::ForceUpdate   = %forceUpdate;
	$lChangeGui::UpdateEval    = %updateEval;
	$lChangeGui::UpdateVersion = %updateVer $= "" ? "B4v21 Launcher" : %updateVer;
	$lChangeGui::CanBackOut    = %backButton $= "" ? false : %backButton;
	
	if (!isObject(lChangeGui))
	{
		exec("launcher/lChangeGui.gui");
		exec("launcher/launcherChangelog.cs");
	}
	
	Canvas.pushDialog(lChangeGui);
}

function initClient() {
	// Default quick launch
	setLogMode(2);
	
	// Parse arguments
	for (%i = 1; %i < $Game::argc; %i++)
	{
		%arg = $Game::Argv[%i];
		
		if (%arg $= "-quiet")
		{
			$Quiet = true;
		}
		else if (%arg $= "-launch")
		{
			$QuickLaunch        = true;
			$QuickLaunchVersion = "";
			%i++;
			
			if (%i >= $Game::Argc)
			{
				error("ERROR: The '-launch' command requires an argument!");
				echo("EXAMPLE: -launch \"My Installation Name\"");
				
				$QuickLaunch = false;
				continue;
			}
			
			if (getSubStr($Game::Argv[%i], 0, 1) $= "\"" && getSubStr($Game::Argv[%i], strLen($Game::Argv[%i]) - 1, 1) $= "\"")
			{
				$QuickLaunchVersion = getSubStr($Game::Argv[%i], 1, strLen($Game::Argv[%i]) - 2);
			}
			else if (getSubStr($Game::Argv[%i], 0, 1) $= "\"")
			{
				// Find the end quote
				%arg = $Game::Argv[%i];
				for (%j=%i + 1;%j<$Game::Argc;%j++)
				{
					%arg = %arg SPC $Game::Argv[%j];
					if (getSubStr($Game::Argv[%j], strLen($Game::Argv[%j]) - 1, 1) $= "\"")
					{
						%i = %j;
						break;
					}
				}
				
				// Remove the quotes from the name
				$QuickLaunchVersion = getSubStr(%arg, 1, strLen(%arg) - 2);
			}
			else
			{
				$QuickLaunchVersion = $Game::Argv[%i];
			}
			
			// Convert strings like "v20" into real versions
			if (getSubStr($QuickLaunchVersion, 0, 1) $= "v")
			{
				%vNum = getSubStr($QuickLaunchVersion, 1, strLen($QuickLaunchVersion) - 1);
				if (stripChars(%vNum, ".0123456789") $= "")
					$QuickLaunchVersion = %vNum;
			}
		}
		else if (%arg $= "-dedicated")
		{
			$QuickLaunchDedicated = 1;
		}
		else if (%arg $= "-dedicatedlan")
		{
			$QuickLaunchDedicated = 2;
		}
		else if (%arg $= "-renamed")
		{
			$Renamed = true;
		}
		else if (%arg $= "-help" || %arg $= "--help" || %arg $= "/?")
		{
			%help = true;
		}
		else
		{
			echo("Unrecognized command line argument \"" @ %arg @ "\"");
		}
	}
	
	if (%help)
	{
		enableWinConsole(true);
		echo("");
		echo("B4v21 Launcher command line options:");
		echo("  -quiet                         Quiet mode, do not ask if ok to update launcher / version while in QuickLaunch mode.");
		echo("  -launch <Version/InstallName>  QuickLaunch the version / installation provided, and update it if necessary. Use quotes for names w/ spaces in them.");
		echo("  -dedicated                     QuickLaunch the version / installation in dedicated server mode.");
		echo("  -dedicatedlan                  QuickLaunch the version / installation in dedicated-lan server mode.");
		echo("  -help                          Shows this dialog.");
		echo("");
		quit();
		return;
	}
	
	echo("\n--------- Initializing B4v21 Launcher ---------");
	
	// Evaluate arguments
	if ($QuickLaunch)
	{
		exec("./DownloadQueue.cs");
		exec("./versionMgr.cs");
		
		// Do special launch procedures
		fetchVersionListing();
		
		return;
	}
	
	initBaseVideo();
	
	// Load scripts
	exec("./profiles.cs");
	exec("./versionMgr.cs");
	exec("./launcherGui.gui");
	exec("./versionManagerGui.gui");
	exec("./VMG_RenameGui.gui");
	exec("./VMG_AddGui.gui");
	exec("./message.cs");
	exec("./DownloadQueue.cs");
	exec("./v21install.cs");
	
	// Start up the main menu...
	Canvas.setContent(launcherGui);
	Canvas.setCursor(DefaultCursor);
	
	// Show the current version
	LauncherVersionText.setText("Version: " @ getLauncherVersion());
	
	// Apply the net experience
	ApplyNetExperience();
	
	// Load versions
	fetchVersionListing();
}

function openJoinserverDlg() {
	if(!$alreadyOpenedJoinDlg) {
		$alreadyOpenedJoinDlg = true;
		
		exec("./joinServerPreviewDlg.gui");
		exec("./joinServerDlg.gui");
		exec("./joinServerDlg.cs");
		exec("./previewDlg.cs");
	}
	
	Canvas.pushDialog(joinServerDlg);
}

function openHelpDlg() {
	// Loading these here so the startup time of the launcher isn't so long
	// (and the credits GUI isn't all that necessary, so it shouldn't be loaded on startup)
	if(!$alreadyOpenedHelpDlg) {
		$alreadyOpenedHelpDlg = true;
		setModPaths("launcher");
		
		exec("./HelpDlg.gui");
		exec("./HelpDlg.cs");
	}
	
	Canvas.pushDialog(HelpDlg);
}

function openOptions() {
	// Loading these here so the startup time of the launcher isn't so long
	if(!$alreadyOpenedOptionsDlg) {
		$alreadyOpenedOptionsDlg = true;
		
		exec("./optionsDlg.gui");
		exec("./optionsDlg.cs");
	}
	
	Canvas.pushDialog(OptionsDlg);
}