function FancyStringToBytes(%str)
{
	%result = strMatch("/^(\\d+(?:\\.\\d+)?)\\s*(mb|kb|bytes?|b)$/i", %str, "match");
	if (!%result)
	{
		messageBoxOk("ERROR - B4v21 Launcher", "Invalid memory size string! Must be formatted like \"104.32 MB\", and only 'kb' and 'mb' are allowed.");
		return -1;
	}
	
	%num  = removeField(removeField(%match[1], 0), 0);
	%type = strLwr(removeField(removeField(%match[2], 0), 0));
	
	if (%type $= "kb") return %num * 1024;
	else if (%type $= "mb") return (%num * 1048576) | 0;
	
	return %num;
}

function BytesToFancyString(%num)
{
	if (%num >= 1048576) return (%num / 1048576) SPC "MB";
	else if (%num >= 1024) return (%num / 1024) SPC "KB";
	else return %num SPC "bytes";
}

function optionsDlg::onWake(%this)
{
	%window = %this.getObject(0);
	%window.setPosition((getWord(getRes(), 0) / 2) - (getWord(%window.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%window.getExtent(), 1) / 2));
	
	(%rL = %this.findObjectByInternalName("ResList", true)).clear();
	
	%list = getResolutionList("OpenGL");
	for (%i = 0; %i < getWordCount(%list); %i += 3)
	{
		%res = getWord(%list, %i) SPC getWord(%list, %i + 1);
		
		if (%res $= getWords(getRes(), 0, 1)) %sel = %i / 3;
		if (getWord(%res, 0) < 800 || getWord(%res, 1) < 600) continue;
		
		%rL.add(getWord(%list, %i) @ "x" @ getWord(%list, %i + 1), %i / 3);
	}
	
	// Populate the display driver list
	%dList = getDisplayDeviceList();
	%vList = optionsDlg.findObjectByInternalName("DispList", true);
	%selId = -1;
	
	%vList.clear();
	for (%i = 0; %i < getFieldCount(%dList); %i++)
	{
		if (%selId == -1 && $pref::Video::displayDevice $= getField(%dList, %i))
			%selId = %i;
		
		%vList.add(getField(%dList, %i), %i);
	}
	%vList.setSelected(%selId);
	
	// Setup misc
	%this.findObjectByInternalName("downloadThrottle", true).setValue(BytesToFancyString($Pref::Launcher::Downloader::BytesPerRead));
	
	// Setup audio
	%this.findObjectByInternalName("MasterVolume", true).setValue($pref::Audio::masterVolume);
	%this.findObjectByInternalName("AudioList", true).clear();
	%this.findObjectByInternalName("AudioList", true).add("OpenAL", 0);
	%this.findObjectByInternalName("AudioList", true).setSelected(0);
	
	%rL.setSelected(%sel);
	%this.findObjectByInternalName("PlayMMBtnSounds", true).setValue($Pref::Audio::MainMenuButtons);
	%this.findObjectByInternalName("TabBook", true).selectPage(0);
}

function optionsDlg::apply(%this)
{
	%throttleAmt = FancyStringToBytes(%this.findObjectByInternalName("downloadThrottle", true).getValue());
	if (%throttleAmt == -1)
		return;
	
	%newDriver = %this.findObjectByInternalName("DispList", true).getText();
	
	// Apply display stuff
	if (%newDriver !$= $pref::Video::displayDevice)
	{
		$pref::Video::displayDevice = %newDriver;
		setDisplayDevice(%newDriver, getWord(getRes(), 0), getWord(getRes(), 1), getWord(getRes(), 2), false);
	}
	
	// Set new resolution
	%newRes = strReplace(%this.findObjectByInternalName("ResList", true).getTextById(%this.findObjectByInternalName("ResList", true).getSelected()), "x", " ");
	if (%newRes !$= getWords(getRes(), 0, 1))
		setRes(getWord(%newRes, 0), getWord(%newRes, 1));
	
	// Apply audio settings
	$pref::Audio::masterVolume                 = %this.findObjectByInternalName("MasterVolume", true).getValue();
	$Pref::Audio::MainMenuButtons              = %this.findObjectByInternalName("PlayMMBtnSounds", true).getValue();
	BlockMainMenuButtonProfile.soundButtonOver = ($Pref::Audio::MainMenuButtons ? "mmButtonHoverSound" : "");
	alxSetChannelVolume(1, $pref::Audio::masterVolume);
	
	if (stripChars(getSubStr($pref::Launcher::Location, strLen($pref::Launcher::Location) - 1, 1), "/\\") !$= "") $pref::Launcher::Location = $pref::Launcher::Location @ "\\";
	if (getDirectoryFileCount($pref::Launcher::Location) == 0) createPath($pref::Launcher::Location);
	
	$Pref::Net::DesiredExperience             = $Desired::NetUsageOption;
	$Pref::Launcher::Downloader::BytesPerRead = %throttleAmt;
	
	// Save prefs
	export("$pref::*", "launcher/prefs.cs");
	
	// We're done!
	Canvas.popDialog(optionsDlg);
}