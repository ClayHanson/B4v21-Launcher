//--- OBJECT WRITE BEGIN ---
new GuiControl(MsgBoxYesNoGui) {
   canSaveDynamicFields = "0";
   Profile = "GuiDefaultProfile";
   HorizSizing = "right";
   VertSizing = "bottom";
   position = "0 0";
   Extent = "1024 768";
   MinExtent = "8 2";
   canSave = "1";
   Visible = "1";
   hovertime = "1000";

   new GuiWindowCtrl(MsgBoxYesNoDlg) {
      canSaveDynamicFields = "0";
      Profile = "BlockWindowProfile";
      HorizSizing = "right";
      VertSizing = "bottom";
      position = "424 307";
      Extent = "300 133";
      MinExtent = "300 119";
      canSave = "1";
      Visible = "1";
      hovertime = "1000";
      text = "Test";
      maxLength = "1024";
      resizeWidth = "0";
      resizeHeight = "0";
      canMove = "1";
      canClose = "0";
      canMinimize = "0";
      canMaximize = "0";
      minSize = "50 50";

      new GuiMLTextCtrl() {
         canSaveDynamicFields = "0";
         internalName = "DisplayText";
         Profile = "GuiMLTextProfile";
         HorizSizing = "width";
         VertSizing = "bottom";
         position = "32 39";
         Extent = "236 14";
         MinExtent = "236 14";
         canSave = "1";
         Visible = "1";
         hovertime = "1000";
         lineSpacing = "2";
         allowColorChars = "0";
         maxChars = "-1";
         text = "<just:center>test";
      };
      new GuiBitmapButtonCtrl() {
         canSaveDynamicFields = "0";
         Profile = "BlockButtonProfile";
         HorizSizing = "right";
         VertSizing = "top";
         position = "49 78";
         Extent = "91 38";
         MinExtent = "8 2";
         canSave = "1";
         Visible = "1";
         Command = "MessageYesNoCallback(0);";
         hovertime = "1000";
         text = "NO";
         groupNum = "-1";
         buttonType = "PushButton";
         bitmap = "./ui/Button2";
      };
      new GuiBitmapButtonCtrl() {
         canSaveDynamicFields = "0";
         Profile = "BlockButtonProfile";
         HorizSizing = "right";
         VertSizing = "top";
         position = "163 78";
         Extent = "91 38";
         MinExtent = "8 2";
         canSave = "1";
         Visible = "1";
         Command = "MessageYesNoCallback(1);";
         hovertime = "1000";
         text = "YES";
         groupNum = "-1";
         buttonType = "PushButton";
         bitmap = "./ui/Button2";
      };
   };
};
//--- OBJECT WRITE END ---

//--- OBJECT WRITE BEGIN ---
new GuiControl(MsgBoxOkGui) {
   canSaveDynamicFields = "0";
   Profile = "GuiDefaultProfile";
   HorizSizing = "right";
   VertSizing = "bottom";
   position = "0 0";
   Extent = "1024 768";
   MinExtent = "8 2";
   canSave = "1";
   Visible = "1";
   hovertime = "1000";

   new GuiWindowCtrl(MsgBoxOkDlg) {
      canSaveDynamicFields = "0";
      Profile = "BlockWindowProfile";
      HorizSizing = "right";
      VertSizing = "bottom";
      position = "424 307";
      Extent = "300 133";
      MinExtent = "300 119";
      canSave = "1";
      Visible = "1";
      hovertime = "1000";
      text = "Test";
      maxLength = "1024";
      resizeWidth = "0";
      resizeHeight = "0";
      canMove = "1";
      canClose = "0";
      canMinimize = "0";
      canMaximize = "0";
      minSize = "50 50";

      new GuiMLTextCtrl() {
         canSaveDynamicFields = "0";
         internalName = "DisplayText";
         Profile = "GuiMLTextProfile";
         HorizSizing = "width";
         VertSizing = "bottom";
         position = "32 39";
         Extent = "236 14";
         MinExtent = "236 14";
         canSave = "1";
         Visible = "1";
         hovertime = "1000";
         lineSpacing = "2";
         allowColorChars = "0";
         maxChars = "-1";
         text = "<just:center>test";
      };
      new GuiBitmapButtonCtrl() {
         canSaveDynamicFields = "0";
         Profile = "BlockButtonProfile";
         HorizSizing = "center";
         VertSizing = "top";
         position = "104 78";
         Extent = "91 38";
         MinExtent = "8 2";
         canSave = "1";
         Visible = "1";
         Command = "MessageOkCallback();";
         hovertime = "1000";
         text = "OK";
         groupNum = "-1";
         buttonType = "PushButton";
         bitmap = "./ui/Button2";
      };
   };
};
//--- OBJECT WRITE END ---


function messageBoxYesNo(%title, %message, %yesCall, %noCall) {
	%object  = MsgBoxYesNoDlg;
	%group   = %object.getGroup();
	%textObj = %object.findObjectByInternalName("DisplayText");
	
	%object.noCallback  = %noCall;
	%object.yesCallback = %yesCall;
	
	Canvas.pushDialog(MsgBoxYesNoGui);
	%textObj.setText("<just:center>" @ %message);
	%textObj.forceReflow();
	%object.setExtent(getWord(%object.minExtent, 0), getWord(%object.minExtent, 1) + (getWord(%textObj.getExtent(), 1) - %textObj.profile.textSize));
	%object.setText(%title);
	
	%object.setPosition((getWord(getRes(), 0) / 2) - (getWord(%object.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%object.getExtent(), 1) / 2));
}

function MessageYesNoCallback(%val) {
	%object = MsgBoxYesNoDlg;
	Canvas.popDialog(MsgBoxYesNoGui);
	
	%evalStr = (%val ? %object.yesCallback : %object.noCallback);
	if(%evalStr !$= "") eval(%evalStr);
}

function MessageBoxOk(%title, %message, %callBack) {
	%object  = MsgBoxOkDlg;
	%group   = %object.getGroup();
	%textObj = %object.findObjectByInternalName("DisplayText");
	
	MsgBoxOkGui.callback = %callBack;
	
	Canvas.pushDialog(MsgBoxOkGui);
	%textObj.setText("<just:center>" @ %message);
	%textObj.forceReflow();
	%object.setExtent(getWord(%object.minExtent, 0), getWord(%object.minExtent, 1) + (getWord(%textObj.getExtent(), 1) - %textObj.profile.textSize));
	%object.setText(%title);
	
	%object.setPosition((getWord(getRes(), 0) / 2) - (getWord(%object.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%object.getExtent(), 1) / 2));
}

function MessagePopup(%title, %message)
{
	if (!isObject(MessagePopupDlg))
		exec("./MessagePopupDlg.gui");
	
	%object  = MessagePopFrame;
	%group   = %object.getGroup();
	%textObj = MessagePopText;
	
	Canvas.pushDialog(MessagePopupDlg);
	%textObj.setText("<just:center>" @ %message);
	%textObj.forceReflow();
	%object.setExtent(getWord(%object.minExtent, 0), getWord(%object.minExtent, 1) + (getWord(%textObj.getExtent(), 1) - %textObj.profile.textSize));
	%object.setText(%title);
	
	%object.setPosition((getWord(getRes(), 0) / 2) - (getWord(%object.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%object.getExtent(), 1) / 2));
}

function CloseMessagePopup()
{
	Canvas.popDialog(MessagePopupDlg);
}

function MessageOkCallback() {
	Canvas.popDialog(%object = MsgBoxOkGui);
	if(%object.callback !$= "") eval(%object.callBack);
}