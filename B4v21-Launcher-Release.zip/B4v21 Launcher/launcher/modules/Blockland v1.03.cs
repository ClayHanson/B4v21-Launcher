exec("./Blockland v20.cs");

// Should return a list delimited by '\n'
// Format: "Complete File Path" TAB "Default Name (if there is no avatar name for this avatar)"
function AEGM_GetAvatarFileList(%SO)
{
	%list       = "";
	%AvatarPath = strReplace(%SO.path, "\\", "/") @ "base/config/client/AvatarFavorites/";
	for (%i = 0; %i < 10; %i++)
	{
		%file = %AvatarPath @ %i @ ".cs";
		if (!isFile(%file, true))
			continue;
		
		%list = (%list $= "" ? "" : %list @ "\n") @ %file TAB "Favorite # " @ %i;
	}
	
	return %list;
}

function AEGM_hasFreeAvatarSlot(%SO)
{
	%list       = "";
	%AvatarPath = strReplace(%SO.path, "\\", "/") @ "base/config/client/AvatarFavorites/";
	for (%i = 0; %i < 10; %i++)
	{
		%file = %AvatarPath @ %i @ ".cs";
		if (isFile(%file, true))
			continue;
		
		return true;
	}
	
	return false;
}

// Set default avatar preferences.
function AEGM_SetDefaultAvatar()
{
	// Blockhead
	$pref::Player::Accent = "2";
	$pref::Player::AccentColor = "0.850 0.850 0.850 0.700";
	$pref::Player::Authentic = 0;
	$pref::Player::Chest = "0";
	$pref::Player::ChestColor = "7";
	$pref::Player::DecalColor = "0";
	$pref::Player::DecalName = "base/data/shapes/player/decals/AAA-None.png";
	$pref::Player::FaceColor = "0";
	$pref::Player::FaceName = "base/data/shapes/player/faces/smiley.png";
	$pref::Player::Hat = "0";
	$pref::Player::HatColor = "0.392157 0.196078 0 1";
	$pref::Player::HeadColor = "1 0.878431 0.611765 1";
	$pref::Player::Hip = "0";
	$pref::Player::HipColor = "0 0 1 1";
	$pref::Player::LArm = "0";
	$pref::Player::LArmColor = "0.900 0.000 0.000 1.000";
	$pref::Player::LHand = "0";
	$pref::Player::LHandColor = "1 0.878431 0.611765 1";
	$pref::Player::LLeg = "0";
	$pref::Player::LLegColor = "0 0 1 1";
	$pref::Player::Pack = "0";
	$pref::Player::PackColor = "0 0.435323 0.831776 1";
	$pref::Player::RArm = "0";
	$pref::Player::RArmColor = "0.900 0.000 0.000 1.000";
	$pref::Player::RHand = "0";
	$pref::Player::RHandColor = "1 0.878431 0.611765 1";
	$pref::Player::RLeg = "0";
	$pref::Player::RLegColor = "0 0 1 1";
	$pref::Player::SecondPack = "0";
	$pref::Player::SecondPackColor = "0 1 0 1";
	$pref::Player::Symmetry = "";
	$pref::Player::TorsoColor = "1 1 1 1";
}

function AEGM_LoadAvatar(%gui, %file)
{
	%lineNo = -1;
	%SO     = new FileObject();
	%SO.openForRead(%file);
	while (!%SO.isEOF())
	{
		%line = %SO.readLine();
		%line = setWord(%line, 0, strReplace(strLwr(getWord(%line, 0)), "$pref::player::", "$pref::Player::"));
		%lineNo++;
		
		%result = 0;
		eval(%line @ "%result=1;");
		
		if (%result == 0)
		{
			error("ERROR: Syntax error on line # " @ %lineNo @ " in " @ %file @ "!");
			%SO.close();
			%SO.delete();
			return false;
		}
	}
	
	%SO.close();
	%SO.delete();
	
	return true;
}

function AEGM_SaveAvatar(%gui, %file, %avatarName)
{
	$pref::Player::ConfigName = %avatarName;
	export("$pref::Player::*", %file);
	
	%SO     = new FileObject();
	%SO.openForRead(%file);
	while (!%SO.isEOF())
	{
		%line = %SO.readLine();
		
		%pref[-1 + %prefCount++] = %line;
	}
	%SO.close();
	%SO.openForWrite(%file);
	for (%i = 0; %i < %prefCount; %i++)
	{
		echo(%pref[%i]);
		%pref[%i] = strIReplace(%pref[%i], "$pref::Player::", "$Pref::Player::");
		
		%SO.writeLine(%pref[%i]);
	}
	%SO.close();
	%SO.delete();
	
	return true;
}

// Actual module functions
function AEGM_LoadGameData(%SO)
{
	AvatarEditGui.loadNodeNames("hat");
	AvatarEditGui.loadNodeNames("pack");
	AvatarEditGui.loadNodeNames("accent");
	AvatarEditGui.loadNodeNames("chest");
	AvatarEditGui.loadNodeNames("hip");
	AvatarEditGui.loadNodeNames("LArm");
	AvatarEditGui.loadNodeNames("LHand");
	AvatarEditGui.loadNodeNames("RArm");
	AvatarEditGui.loadNodeNames("RHand");
	AvatarEditGui.loadNodeNames("LLeg");
	AvatarEditGui.loadNodeNames("RLeg");
	AvatarEditGui.loadNodeNames("secondPack");
	AvatarEditGui.loadIflFrames("face", "base/data/shapes/player/");
	AvatarEditGui.loadIflFrames("decal", "base/data/shapes/player/");
	
	// Populate the parts list
	AvatarEditGui.addPartControl("ifl_selector",	false,	"Face",		"headSkin",	"$Pref::Avatar::HeadColor", true, "");
	AvatarEditGui.addPartControl("ifl_selector",	false,	"Decal",	"chest",	"$Pref::Avatar::TorsoColor", false, "");
	AvatarEditGui.addPartControl("part_selector",	false,	"chest",	"");
	AvatarEditGui.addPartControl("symmetry_bool",	false);
	AvatarEditGui.addPartControl("part_selector",	true,	"hip",		"");
	AvatarEditGui.addPartControl("part_selector",	false,	"hat",		"");
	AvatarEditGui.addPartControl("part_selector",	false,	"pack",		"");
	AvatarEditGui.addPartControl("part_selector",	false,	"RArm",		"LArm");
	AvatarEditGui.addPartControl("part_selector",	false,	"RHand",	"LHand");
	AvatarEditGui.addPartControl("part_selector",	true,	"RLeg",		"LLeg");
	AvatarEditGui.addPartControl("part_selector",	false,	"accent",	"");
	AvatarEditGui.addPartControl("part_selector",	false,	"secondPack",	"");
	AvatarEditGui.addPartControl("part_selector",	false,	"LArm",		"RArm");
	AvatarEditGui.addPartControl("part_selector",	false,	"LHand",	"RHand");
	AvatarEditGui.addPartControl("part_selector",	true,	"LLeg",		"RLeg");
	AvatarEditGui.updatePartList();
	
	return true;
}