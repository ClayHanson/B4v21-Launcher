// AEGM (Avatar Editor Gui Module) Loader

// Helper functions
function __SUB_RESET_SHAPE__(%Shape)
{
	if (!%Shape.alteredState)
		return;
	
	%Shape.setNodeColor("headSkin", %Shape.__oldHeadSkinColor);
	%Shape.setIflFrame("Face", %Shape.__oldFaceName);
	%Shape.alteredState = false;
}

function __SUB_SAVE_STATE__(%Shape)
{
	if (%Shape.alteredState)
		return;
	
	%Shape.__oldHeadSkinColor = %Shape.getNodeColor("headSkin");
	%Shape.__oldFaceName      = fileBase(%Shape.getIflFrame("Face"));
	%Shape.alteredState       = true;
}

// Actual module functions
function AEGM_LoadGameData(%SO)
{
	AvatarEditGui.loadNodeNames("hat");
	AvatarEditGui.loadNodeNames("pack");
	AvatarEditGui.loadNodeNames("accent");
	AvatarEditGui.loadNodeNames("chest");
	AvatarEditGui.loadNodeNames("hip");
	AvatarEditGui.loadNodeNames("LArm");
	AvatarEditGui.loadNodeNames("LHand");
	AvatarEditGui.loadNodeNames("RArm");
	AvatarEditGui.loadNodeNames("RHand");
	AvatarEditGui.loadNodeNames("LLeg");
	AvatarEditGui.loadNodeNames("RLeg");
	AvatarEditGui.loadNodeNames("secondPack");
	AvatarEditGui.loadIflFrames("face");
	AvatarEditGui.loadIflFrames("decal");
	
	// Populate the parts list
	AvatarEditGui.addPartControl("ifl_selector",	false,	"Face",		"headSkin",	"$Pref::Avatar::HeadColor", true, "");
	AvatarEditGui.addPartControl("ifl_selector",	false,	"Decal",	"chest",	"$Pref::Avatar::TorsoColor", false, "");
	AvatarEditGui.addPartControl("part_selector",	false,	"chest",	"");
	AvatarEditGui.addPartControl("symmetry_bool",	false);
	AvatarEditGui.addPartControl("part_selector",	true,	"hip",		"");
	AvatarEditGui.addPartControl("part_selector",	false,	"hat",		"");
	AvatarEditGui.addPartControl("part_selector",	false,	"pack",		"");
	AvatarEditGui.addPartControl("part_selector",	false,	"RArm",		"LArm");
	AvatarEditGui.addPartControl("part_selector",	false,	"RHand",	"LHand");
	AvatarEditGui.addPartControl("part_selector",	true,	"RLeg",		"LLeg");
	AvatarEditGui.addPartControl("part_selector",	false,	"accent",	"");
	AvatarEditGui.addPartControl("part_selector",	false,	"secondPack",	"");
	AvatarEditGui.addPartControl("part_selector",	false,	"LArm",		"RArm");
	AvatarEditGui.addPartControl("part_selector",	false,	"LHand",	"RHand");
	AvatarEditGui.addPartControl("part_selector",	true,	"LLeg",		"RLeg");
	AvatarEditGui.updatePartList();
	
	return true;
}

function AEGM_OnEditorLoaded(%SO)
{
	%ParticlePath = filePath(strReplace(%SO.path, "\\", "/")) @ "/base/data/particles/";
	
	AvatarEditGui.e_AvatarPreview.createParticleType("T0", %ParticlePath @ "cloud.png", 0, 5);
	AvatarEditGui.e_AvatarPreview.createParticleType("T1", %ParticlePath @ "chunk.png", 5, 0);
}

// Return the local path of avatarColors.cs
function AEGM_GetColortablePath()
{
	return "config/client/avatarColors.cs";
}

// Return the local path of the place to save avatar favorites
function AEGM_GetAvatarFavoritesPath()
{
	return "config/client/AvatarFavorites/";
}

// Set default avatar preferences.
function AEGM_SetDefaultAvatar()
{
	// Blockhead
	$pref::Avatar::Accent = "2";
	$pref::Avatar::AccentColor = "0.850 0.850 0.850 0.700";
	$pref::Avatar::Authentic = 0;
	$Pref::Avatar::Chest = "0";
	$pref::Avatar::ChestColor = "7";
	$pref::Avatar::DecalColor = "0";
	$Pref::Avatar::DecalName = "base/data/shapes/player/decals/AAA-None.png";
	$pref::Avatar::FaceColor = "0";
	$Pref::Avatar::FaceName = "base/data/shapes/player/faces/smiley.png";
	$pref::Avatar::Hat = "0";
	$pref::Avatar::HatColor = "0.392157 0.196078 0 1";
	$pref::Avatar::HeadColor = "1 0.878431 0.611765 1";
	$Pref::Avatar::Hip = "0";
	$pref::Avatar::HipColor = "0 0 1 1";
	$Pref::Avatar::LArm = "0";
	$pref::Avatar::LArmColor = "0.900 0.000 0.000 1.000";
	$Pref::Avatar::LHand = "0";
	$pref::Avatar::LHandColor = "1 0.878431 0.611765 1";
	$Pref::Avatar::LLeg = "0";
	$pref::Avatar::LLegColor = "0 0 1 1";
	$pref::Avatar::Pack = "0";
	$pref::Avatar::PackColor = "0 0.435323 0.831776 1";
	$Pref::Avatar::RArm = "0";
	$pref::Avatar::RArmColor = "0.900 0.000 0.000 1.000";
	$Pref::Avatar::RHand = "0";
	$pref::Avatar::RHandColor = "1 0.878431 0.611765 1";
	$Pref::Avatar::RLeg = "0";
	$pref::Avatar::RLegColor = "0 0 1 1";
	$Pref::Avatar::SecondPack = "0";
	$pref::Avatar::SecondPackColor = "0 1 0 1";
	$pref::Avatar::Symmetry = "";
	$pref::Avatar::TorsoColor = "1 1 1 1";
}

// Should return a list delimited by '\n'
// Format: "Complete File Path" TAB "Default Name (if there is no avatar name for this avatar)"
function AEGM_GetAvatarFileList(%SO)
{
	%list       = "";
	%AvatarPath = strReplace(%SO.path, "\\", "/") @ "config/client/AvatarFavorites/";
	for (%i = 0; %i < 10; %i++)
	{
		%file = %AvatarPath @ %i @ ".cs";
		if (!isFile(%file, true))
			continue;
		
		%list = (%list $= "" ? "" : %list @ "\n") @ %file TAB "Favorite # " @ %i;
	}
	
	return %list;
}

function AEGM_hasFreeAvatarSlot(%SO)
{
	%list       = "";
	%AvatarPath = strReplace(%SO.path, "\\", "/") @ "config/client/AvatarFavorites/";
	for (%i = 0; %i < 10; %i++)
	{
		%file = %AvatarPath @ %i @ ".cs";
		if (isFile(%file, true))
			continue;
		
		return true;
	}
	
	return false;
}

function AEGM_GetPlayerModelPath(%SO)
{
	return filePath(strReplace(%SO.path, "\\", "/")) @ "/base/data/shapes/player/m.dts";
}

function AEGM_ConstructPlayerModel(%SO)
{
	%ShapePath = filePath(strReplace(AEGM_GetPlayerModelPath(%SO), "\\", "/"));
	
	%TEVAL =          "datablock TSShapeConstructor(mDts" @ %SO.version @ ")";
	%TEVAL = %TEVAL @ "{";
	%TEVAL = %TEVAL @ 	"baseShape = \"" @ %ShapePath @ "/m.dts\";";
	%TEVAL = %TEVAL @ 	"sequence0 = \"" @ %ShapePath @ "/m_root.dsq root\";";
	%TEVAL = %TEVAL @ 	"sequence1 = \"" @ %ShapePath @ "/m_run.dsq run\";";
	%TEVAL = %TEVAL @ 	"sequence2 = \"" @ %ShapePath @ "/m_sit.dsq sit\";";
	%TEVAL = %TEVAL @ 	"sequence3 = \"" @ %ShapePath @ "/m_activate2.dsq activate2\";";
	%TEVAL = %TEVAL @ 	"sequence4 = \"" @ %ShapePath @ "/m_talk.dsq talk\";";
	%TEVAL = %TEVAL @ 	"sequence5 = \"" @ %ShapePath @ "/m_armReadyLeft.dsq armReadyLeft\";";
	%TEVAL = %TEVAL @ 	"sequence6 = \"" @ %ShapePath @ "/m_armReadyRight.dsq armReadyRight\";";
	%TEVAL = %TEVAL @ 	"sequence7 = \"" @ %ShapePath @ "/m_headup.dsq headUp\";";
	%TEVAL = %TEVAL @ 	"bone0  = \"Head	$Pref::Avatar::HeadColor	-	-0.01526 0 0.4006\";";
	%TEVAL = %TEVAL @ 	"bone1  = \"RightArm	$Pref::Avatar::RArmColor	-	0.03089 -0.05099 -0.04438\";";
	%TEVAL = %TEVAL @ 	"bone2  = \"LeftArm	$Pref::Avatar::LArmColor	-	-0.03089 0.05617 0.04426\";";
	%TEVAL = %TEVAL @ 	"bone3  = \"RightHand	$Pref::Avatar::RHandColor	-	-0.00806 0.23258 0.06307\";";
	%TEVAL = %TEVAL @ 	"bone4  = \"LeftHand	$Pref::Avatar::LHandColor	-	0.00761 -0.23265 -0.06299\";";
	%TEVAL = %TEVAL @ 	"bone5  = \"Torso	$Pref::Avatar::TorsoColor	-	-0.00681 0 0.23291\";";
	%TEVAL = %TEVAL @ 	"bone6  = \"Hip 	$Pref::Avatar::HipColor 	-	-0.01070 0 0.19199\";";
	%TEVAL = %TEVAL @ 	"bone7  = \"LeftLeg	$Pref::Avatar::LLegColor	-	0.07708 0.31479 -0.60967\";";
	%TEVAL = %TEVAL @ 	"bone8  = \"RightLeg	$Pref::Avatar::RLegColor	-	0.07708 -0.31432 -0.60967\";";
	%TEVAL = %TEVAL @ 	"bone9  = \"Mount5	$Pref::Avatar::HatColor 	$Pref::Avatar::Hat	0 0 0\";";
	%TEVAL = %TEVAL @ 	"bone10 = \"Torso	$Pref::Avatar::PackColor	$Pref::Avatar::Pack	-0.45416 0 0.27674\";";
	%TEVAL = %TEVAL @ 	"bone11 = \"Head	$Pref::Avatar::SecondPackColor	$Pref::Avatar::SecondPack	0 0 0\";";
	%TEVAL = %TEVAL @ "};";
	
	return %TEVAL;
}

function AEGM_CustomizeShape(%gui, %Shape)
{
	if ($Pref::Avatar::Pack == 0 && $Pref::Avatar::SecondPack == 0)
	{
		if (%Shape.headUp != 1)
		{
			%Shape.headUp = 1;
			if (%Shape.getClassName() $= "GuiShapeCtrl")
			{
				%Shape.playThread(2, "root");
			}
			else
			{
				%Shape.playThread("", 2, "root");
			}
		}
	}
	else
	{
		if (%Shape.headUp != 2)
		{
			%Shape.headUp = 2;
			if (%Shape.getClassName() $= "GuiShapeCtrl")
			{
				%Shape.playThread(2, "headUp");
			}
			else
			{
				%Shape.playThread("", 2, "headUp");
			}
		}
	}
	
	if ($Pref::Avatar::Hip == 1)
	{
		if (%Shape.getClassName() $= "GuiShapeCtrl")
		{
			%Shape.setNodeVisible("LPeg", false);
			%Shape.setNodeVisible("LShoe", false);
			%Shape.setNodeVisible("RPeg", false);
			%Shape.setNodeVisible("RShoe", false);
			%Shape.setNodeVisible("SkirtTrimRight", true);
			%Shape.setNodeVisible("SkirtTrimLeft", true);
			%Shape.setNodeColor("SkirtTrimRight", $Pref::Avatar::RLegColor);
			%Shape.setNodeColor("SkirtTrimLEft", $Pref::Avatar::LLegColor);
		}
		else
		{
			%Shape.setNodeVisible("", "LPeg", false);
			%Shape.setNodeVisible("", "LShoe", false);
			%Shape.setNodeVisible("", "RPeg", false);
			%Shape.setNodeVisible("", "RShoe", false);
			%Shape.setNodeVisible("", "SkirtTrimRight", true);
			%Shape.setNodeVisible("", "SkirtTrimLeft", true);
			%Shape.setNodeColor("", "SkirtTrimRight", $Pref::Avatar::RLegColor);
			%Shape.setNodeColor("", "SkirtTrimLEft", $Pref::Avatar::LLegColor);
		}
	}
	
	if (%Shape.getClassName() $= "GuiShapeCtrl")
		return;
	
	// Spawn particles for changed shit
	%i = -1;
	while(true)
	{
		%i++;
		
		%boneData = eval("return " @ ("mDts" @ %gui.so.version).getId() @ ".bone" @ %i @ ";");
		if (%boneData $= "")
			break;
		
		%boneName  = trim(getField(%boneData, 0));
		%boneCPref = trim(getField(%boneData, 1));
		%bonePref  = trim(getField(%boneData, 2));
		%offset    = trim(getField(%boneData, 3));
		%boneColor = eval("return " @ %boneCPref @ ";");
		%boneValue = (%bonePref $= "-" ? 1 : eval("return " @ %bonePref @ ";"));
		
		if ($CACHE::_[%boneCPref] $= %boneColor)
			continue;
		
		%oldPref              = $CACHE::_[%boneCPref];
		$CACHE::_[%boneCPref] = %boneColor;
		
		if (%oldPref $= "" || %boneValue == 0)
			continue;
		
		AEGM_SpawnParticles(%Shape, %boneColor, VectorAdd(%Shape.getNodeOffset("", %boneName), %offset));
	}
}

function AEGM_SpawnParticles(%Shape, %color, %Position)
{
	%totalLoops = getRandom(5, 10);
	%maxChunks  = mFloor(%totalLoops / getRandomF(2, 4));
	
	if (getWordCount(%color) == 3)
		%color = %color SPC "1";
	else
		%color = setWord(%color, 3, 1);
	
	// Spawn particles
	for (%i = 0; %i < %totalLoops; %i++)
	{
		if (%i < %maxChunks)
		{
			%vel        = (getRandom(0, 1) == 0 ? getRandomF(-5, -10) : getRandomF(5, 10)) SPC (getRandom(0, 1) == 0 ? getRandomF(-5, -10) : getRandomF(5, 10)) SPC (getRandom(0, 1) == 0 ? getRandomF(-5, -10) : getRandomF(5, 10));
			%lifeTime   = getRandom(300, 1000);
			%startSize  = "0.1 0.1 0.1";
			%endSize    = "0.1 0.1 0.1";
			%startAlpha = getRandomF(0.8, 1);
			%endAlpha   = 0;
			
			%Shape.spawnParticle("T1", %position, %lifeTime, %vel, %startSize, %endSize, %startAlpha, %endAlpha, %color);
		}
		
		%vel        = getRandomF(-4, 4) SPC getRandomF(-4, 4) SPC getRandomF(-4, 4);
		%endVel     = "0 0 0";
		%lifeTime   = getRandom(300, 1000);
		%startSize  = (%a = getRandomF(0.1, 0.4)) SPC %a SPC %a;
		%endSize    = (%a = getRandomF(getWord(%startSize, 0), getWord(%startSize, 0) + 0.4)) SPC %a SPC %a;
		%startAlpha = getRandomF(0.6, 1);
		%endAlpha   = 0;
		
		%Shape.spawnParticle("T0", %position, %lifeTime, %vel, %startSize, %endSize, %startAlpha, %endAlpha, %color);
	}
}

// Called when a preview avatar is clicked
function AEGM_PreviewClicked(%Shape)
{
	if (%Shape.getGroup().getGroup().avatarFile $= "new")
	{
		AvatarEditGui.randomizeShape(%Shape);
		%Shape.playThread(0, "talk", 1);
		
		cancel(%Shape.normalAnim);
		%Shape.normalAnim = %Shape.schedule(100, playThread, 0, "root", 1);
		return;
	}
	
	if (getSimTime() - %Shape.lastClickTime >= 1000)
		%Shape.clickAmount = 0;
	
	%Shape.lastClickTime = getSimTime();
	%Shape.clickAmount++;
	if (%Shape.clickAmount >= 20)
	{
		__SUB_SAVE_STATE__(%Shape);
		
		%Shape.setNodeColor("headSkin", "1 0 0 1");
		%Shape.playThread(0, "talk", 1);
		%Shape.playThread(1, "activate2", 1);
		%Shape.setIflFrame("Face", "Orc");
		
		cancel(%Shape.resetSchedule);
		%Shape.resetSchedule = schedule(5000, 0, __SUB_RESET_SHAPE__, %Shape);
		
		cancel(%Shape.normalAnim);
		%Shape.normalAnim = %Shape.schedule(100, playThread, 0, "root", 1);
	}
	else if (%Shape.clickAmount >= 10)
	{
		__SUB_SAVE_STATE__(%Shape);
		
		%Shape.playThread(0, "talk", 1);
		%Shape.setIflFrame("Face", "memeYaranika");
		
		cancel(%Shape.resetSchedule);
		%Shape.resetSchedule = schedule(2000, 0, __SUB_RESET_SHAPE__, %Shape);
		
		cancel(%Shape.normalAnim);
		%Shape.normalAnim = %Shape.schedule(100, playThread, 0, "root", 1);
	}
	else
	{
		%Shape.playThread(0, "talk", 1);
		
		cancel(%Shape.normalAnim);
		%Shape.normalAnim = %Shape.schedule(100, playThread, 0, "root", 1);
	}
}

function AEGM_OnPartMenuOpened(%gui, %SO, %partName, %menuObject)
{
	if (%partName !$= "accent")
		return;
	
	%hatName    = %gui.listd["Hat", eval("return " @ %gui.e_P["Hat"].partPrefName @ ";")];
	%accentList = %gui.accents_for_hat[%hatName];
	%Container  = %menuObject.getObject(0);
	
	for (%i = 0; %i < %Container.getCount(); %i++)
	{
		%child = %Container.getObject(%i);
		%child.setVisible(getWordPos(%accentList, %child.nodeName) != -1);
	}
	
	%menuObject.updateSize();
}

function AEGM_LoadAvatar(%gui, %file)
{
	deleteVariables("$CACHE::_*");
	
	%lineNo = -1;
	%SO     = new FileObject();
	%SO.openForRead(%file);
	while (!%SO.isEOF())
	{
		%line = %SO.readLine();
		%line = setWord(%line, 0, strReplace(strLwr(getWord(%line, 0)), "$pref::player::", "$pref::avatar::"));
		%lineNo++;
		
		%result = 0;
		eval(%line @ "%result=1;");
		
		if (%result == 0)
		{
			error("ERROR: Syntax error on line # " @ %lineNo @ " in " @ %file @ "!");
			%SO.close();
			%SO.delete();
			return false;
		}
	}
	
	%SO.close();
	%SO.delete();
	
	return true;
}

function AEGM_SaveAvatar(%gui, %file, %avatarName)
{
	$Pref::Avatar::ConfigName = %avatarName;
	
	export("$Pref::Avatar::*", %file);
	return true;
}

function AEGM_PopulatePreviewContextMenu(%SO, %CMenu, %StartID)
{
	%SM = %CMenu.addMenu("Item");
	%SM.addItem("None",    ((%StartID += 1) - 1));
	%SM.addItem("Hammer",  ((%StartID += 1) - 1));
	%SM.addItem("Wrench",  ((%StartID += 1) - 1));
	%SM.addItem("Printer", ((%StartID += 1) - 1));
}

function AEGM_UsePreviewContextMenu(%SO, %CObject, %CMenu, %rowID)
{
	switch(%rowID)
	{
		case 0: // None
			if (%CObject.isShape("item"))
				%CObject.removeShape("item");
			
			%CObject.playThread("", 1, "root");
			
		case 1: // Hammer
			if (%CObject.isShape("item"))
				%CObject.removeShape("item");
			
			%CObject.addShape("item", filePath(strReplace(%SO.path, "\\", "/")) @ "/base/data/shapes/hammer.dts");
			%CObject.playThread("", 1, "armReadyRight");
			%CObject.mountObject("item", "", 5);
			%CObject.setNodeColor("item", "ALL", "0.2 0.2 0.2 1");
			%CObject.setShapeTransform("item", "0 0.3 0.3");
			
		case 2: // Wrench
			if (%CObject.isShape("item"))
				%CObject.removeShape("item");
			
			%CObject.addShape("item", filePath(strReplace(%SO.path, "\\", "/")) @ "/base/data/shapes/wrench.dts");
			%CObject.playThread("", 1, "armReadyRight");
			%CObject.mountObject("item", "", 5);
			%CObject.setNodeColor("item", "ALL", "0.471 0.471 0.471 1");
			%CObject.setShapeTransform("item", "0 0.3 0.4");
			
		case 3: // Printer
			if (%CObject.isShape("item"))
				%CObject.removeShape("item");
			
			%CObject.addShape("item", filePath(strReplace(%SO.path, "\\", "/")) @ "/base/data/shapes/printGun.dts");
			%CObject.playThread("", 1, "armReadyRight");
			%CObject.mountObject("item", "", 5);
			%CObject.setNodeColor("item", "ALL", "0.996 0.996 0.91 1");
			%CObject.setShapeTransform("item", "0 0.3 0.2");
	}
}