exec("./Blockland v20.cs");

function AEGM_LoadAvatar(%gui, %file)
{
	%lineNo = -1;
	%SO     = new FileObject();
	%SO.openForRead(%file);
	while (!%SO.isEOF())
	{
		%line = %SO.readLine();
		%line = setWord(%line, 0, strReplace(strLwr(getWord(%line, 0)), "$pref::player::", "$pref::avatar::"));
		%lineNo++;
		
		%result = 0;
		eval(%line @ "%result=1;");
		
		if (%result == 0)
		{
			error("ERROR: Syntax error on line # " @ %lineNo @ " in " @ %file @ "!");
			%SO.close();
			%SO.delete();
			return false;
		}
	}
	
	%SO.close();
	%SO.delete();
	
	return true;
}

function AEGM_SaveAvatar(%gui, %file, %avatarName)
{
	$Pref::Avatar::ConfigName = %avatarName;
	export("$Pref::Avatar::*", %file);
	
	%SO     = new FileObject();
	%SO.openForRead(%file);
	while (!%SO.isEOF())
	{
		%line = %SO.readLine();
		
		%pref[-1 + %prefCount++] = %line;
	}
	%SO.close();
	%SO.openForWrite(%file);
	for (%i = 0; %i < %prefCount; %i++)
	{
		echo(%pref[%i]);
		%pref[%i] = strIReplace(%pref[%i], "$Pref::Avatar::", "$Pref::Player::");
		
		%SO.writeLine(%pref[%i]);
	}
	%SO.close();
	%SO.delete();
	
	return true;
}