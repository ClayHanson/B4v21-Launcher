// Columns (tabs):
//  00 - Passworded?
//  01 - Dedicated?
//  02 - Server Name
//  03 - Players
//  04 - Slash between playercount and maxplayercount
//  05 - Max players
//  06 - # Bricks
//  07 - Map
//  08 - IP
//  09 - Port
//  10 - Version

function JoinServerDlg::onWake(%this)
{
	if (!%this.hasQueriedOnce) %this.queryWebMaster();
}

function JoinServerDlg::getVersionCategoryList(%this, %ver)
{
	%o = JS_Frame;
	for (%i=0;%i<%o.getCount();%i++)
	{
		%cat = %o.getObject(%i);
		if (%cat.version !$= %ver)
			continue;
		
		return %cat.getObject(0);
	}
	
	// Doesn't exist; make it.
	%newO = new GuiPaneControl()
	{
		profile     = "BlockPaneCtrl";
		horizSizing = "width";
		vertSizing  = "height";
		extent      = getWord(%o.getGroup().getExtent(), 0) SPC (getWord(%o.getGroup().getExtent(), 1) / 2);
		version     = %ver;
		Caption     = "v" @ %ver @ " Servers";
		
		new GuiTextListCtrl(JS_ServerListChild)
		{
			profile        = "ServerListProfile";
			horizSizing    = "width";
			extent         = getWord(%o.getGroup().getExtent(), 0) SPC (getWord(%o.getGroup().getExtent(), 1) / 2);
			columns        = "0 34 65 340 385 404 415 445 510 9000 9000 620";
			fitParentWidth = false;
			clipColumnText = true;
		};
	};
	
	%o.add(%newO);
	
	%newO.setCollapsed(1);
	return %newO.getObject(0);
}

function JS_ServerListChild::onSelect(%this, %rowID, %rowText)
{
	%o = JS_Frame;
	
	for (%i=0;%i<%o.getCount();%i++)
	{
		%cat = %o.getObject(%i);
		if (%cat.getObject(0) == %this)
			continue;
		
		%cat.getObject(0).clearSelection();
	}

	// Handle double click
	if ($Launcher::JoinServerDlg::LastSelectedChild == %this && $Launcher::JoinServerDlg::LastSelectedRow == %rowID && getSimTime() - $Launcher::JoinServerDlg::LastSelTime < 1000)
		joinServerDlg.join();
	
	$Launcher::JoinServerDlg::LastSelTime       = getSimTime();
	$Launcher::JoinServerDlg::LastSelectedChild = %this;
	$Launcher::JoinServerDlg::LastSelectedRow   = %rowID;
}

function JoinServerDlg::join(%this, %confirm)
{
	if (!isObject(%o = $Launcher::JoinServerDlg::LastSelectedChild))
		return;
	
	%ver  = getField(%o.getRowTextById(%o.getSelectedId()), 11);
	%ip   = getField(%o.getRowTextById(%o.getSelectedId()), 9);
	%port = getField(%o.getRowTextById(%o.getSelectedId()), 10);
	%pass = (getField(%o.getRowTextById(%o.getSelectedId()), 0) $= "Yes");
	%SO   = getPreferredInstallation(%ver);
	
	if (isDebugMode() && !%pass && %ver !$= "0002" && stripChars(%ver, "0123456789") $= "" && !%confirm)
	{
		messageBoxYesNo("ADD-ON DOWNLOADING", "[DEBUG MODE] Do you want to download the add-on manifest from this server?<br>This will make loading in much faster.", "startServerBlobDownload();", "joinServerDlg.join(2);");
		return;
	}
	
	if (!isObject(%SO))
	{
		%SO = getInstallation(%ver);
		if (isObject(%SO))
		{
			if (!%confirm || %confirm == 2)
			{
				messageBoxOk("NOTICE - B4v21 Launcher", getBlocklandName(%ver) SPC "is installed, but no installation is set as 'perferred'. Please correct this by going to the Version Manager, selecting one of the installations for this version, and clicking 'Set Preferred'. Click \"OK\" to continue.", "JoinServerDlg.join(1);");
				return;
			}
		}
		else
		{
			messageBoxYesNo("NOT INSTALLED - B4v21 Launcher", "You do not have " @ getBlocklandName(%ver) SPC (%inst == 1 ? "completely " : "") @ "installed. Do you want to open the Version Management window?", "Canvas.pushDialog(versionManagerGui);");
			return;
		}
	}
	
	%path = %SO.path;
	if (((%ver >= 1 && %ver <= 20) ||  %ver $= "20s") && %ver !$= "0002" && %ver !$= "RTB" && !isFile(%path @ "key.dat"))
	{
		messageBoxOk("ERROR - B4v21 Launcher", "You need to authenticate in " @ getBlocklandName(%ver) @ " before you can use the launcher to join servers.");
		return;
	}
	
	launchExe(%path @ getBlocklandExe(%ver), "ptlaaxobimwroe -connect " @ %ip @ ":" @ %port @ (%ver $= "RTB" ? " -game rtb" : ""));
	if ($Pref::Launcher::CloseOnLaunch)
		quit();
	else
		messageBoxOk("CONFIRMATION - B4v21 Launcher", getBlocklandName(%ver) @ " is now starting up. Please wait.");
}

function JoinServerDlg::queryLan(%this)
{
}

function JS_sortNumList(%col, %defaultDescending)
{
	%o = JS_Frame;
	if (!isObject(%sorter = JS_ServerOverallSorter))
		%sorter = new GuiTextListCtrl(JS_ServerOverallSorter) { columns = "0 34 65 385 404 415 445 510 9000 9000 620"; };
	
	%o.lastSortNum  = true;
	%o.lastSortCol  = %col;
	%o.lastSortDesc = %defaultDescending;
	%sorter.clear();
	
	%o.sortedNumerical = 1;
	if (%o.sortedBy == %col)
	{
		%o.sortedAsc ^= 1;
		%o.sortedBy   = %col;
	}
	else
	{
		%o.sortedBy  = %col;
		%o.sortedAsc = (%defaultDescending ? 0 : 1);
	}
	
	while (%o.getCount() != 0)
	{
		%cat  = %o.getObject(0);
		%list = %cat.getObject(0);
		
		%list.sortNumerical(%o.sortedBy, %o.sortedAsc);
		
		%sorter.addRow(%cat.getId(), %list.getRowText(0));
		%o.remove(%cat);
	}
	
	// Sort the overall sorter object
	%sorter.sortNumerical(%o.sortedBy, %o.sortedAsc);
	
	// Rearrange the objects accordingly
	for (%i=0;%i<%sorter.rowCount();%i++)
	{
		%o.add(%sorter.getRowId(%i));
		%sorter.getRowId(%i).getObject(0).sortNumerical(%o.sortedBy, %o.sortedAsc);
	}
	
	// All servers category must come first
	%o.remove(%allObj = JoinServerDlg.getVersionCategoryList("All").getGroup());
	%o.add(%allObj);
}

function JS_sortList(%col, %defaultDescending)
{
	%o = JS_Frame;
	if (!isObject(%sorter = JS_ServerOverallSorter))
		%sorter = new GuiTextListCtrl(JS_ServerOverallSorter) { columns = "0 34 65 340 385 404 415 445 510 9000 9000 620"; };
	
	%o.lastSortNum  = false;
	%o.lastSortCol  = %col;
	%o.lastSortDesc = %defaultDescending;
	%sorter.clear();
	
	%o.sortedNumerical = 0;
	if (%o.sortedBy == %col)
	{
		%o.sortedAsc ^= 1;
		%o.sortedBy   = %col;
	}
	else
	{
		%o.sortedBy  = %col;
		%o.sortedAsc = (%defaultDescending ? 0 : 1);
	}
	
	while (%o.getCount() != 0)
	{
		%cat  = %o.getObject(0);
		%list = %cat.getObject(0);
		
		%list.sort(%o.sortedBy, %o.sortedAsc);
		
		%sorter.addRow(%cat.getId(), %list.getRowText(0));
		%o.remove(%cat);
	}
	
	// Sort the overall sorter object
	%sorter.sort(%o.sortedBy, %o.sortedAsc);
	
	// Rearrange the objects accordingly
	// This is very hacky and ugly. lol
	for (%i=0;%i<%sorter.rowCount();%i++)
	{
		%o.add(%sorter.getRowId(%i));
		%sorter.getRowId(%i).getObject(0).sort(%o.sortedBy, %o.sortedAsc);
	}
	
	// All servers category must come first
	%o.remove(%allObj = JoinServerDlg.getVersionCategoryList("All").getGroup());
	%o.add(%allObj);
}

function JoinServerDlg::queryWebMaster(%this)
{
	for (%i=0;%i<JS_Frame.getCount();%i++)
	{
		%o                             = JS_Frame.getObject(%i);
		JS_Frame.collapsed[%o.version] = %o.isCollapsed();
	}
	
	if (!$PortInit)
	{
		$PortInit = true;
		%port     = 16633;
		while (!setNetPort(%port))
		{
			%port++;
			if (%port >= 16700)
			{
				error("Couldn't find a suitable port");
				break;
			}
		}
	}
	
	deleteVariables("$JoinServerDlg::Cache::Ping*");
	$JoinServerDlg::Cache::PingIndex = 0;
	$JoinServerDlg::Cache::PingCount = 0;
	%this.hasQueriedOnce = 1;
	
	%this.findObjectByInternalName("BackBtn", true).setActive(0);
	%this.findObjectByInternalName("QueryLanBtn", true).setActive(0);
	%this.findObjectByInternalName("QueryInternetBtn", true).setActive(0);
	%this.findObjectByInternalName("LoadGif", true).setVisible(1);
	%this.findObjectByInternalName("JoinServerBtn", true).setActive(0);
	%this.findObjectByInternalName("PreviewServerBtn", true).setActive(0);
	JS_window.canClose = 0;
	
	JS_Frame.deleteAll();
	%list = %this.getVersionCategoryList("All");
	%list.getGroup().text = "All Servers";
	
	JoinServerDlg.lastQueryTime = getSimTime();
	$JoinNetServer       = true;
	$MasterQueryCanceled = false;
	
	if (isObject(%o = queryMasterTCPObj)) %o.delete();
	%o = new TCPObject(queryMasterTCPObj);
	
	%o.reading  = 0;
	%o.site     = "b4v21.block.land";
	%o.port     = 80;
	%o.cmd      = "GET /master/index.php HTTP/1.1\r\nUser-Agent: B4v21Launcher-v" @ getLauncherVersion() @ "\r\nHost: " @ %o.site @ "\r\nConnection: close\r\n\r\n";
	%o.connect(%o.site @ ":" @ %o.port);
}

function queryMasterTCPObj::onDNSFailed(%this) {
	MessageBoxOK("Query Master Server Failed", "<just:left>DNS Failed during master server query.\n\n" @ "1.  Verify your internet connection\n\n" @ "2.  Make sure any security software you have is set to allow Blockland.exe to connect to the internet.");
	
	%gui = JoinServerDlg;
	%gui.findObjectByInternalName("BackBtn", true).setActive(1);
	%gui.findObjectByInternalName("QueryLanBtn", true).setActive(1);
	%gui.findObjectByInternalName("QueryInternetBtn", true).setActive(1);
	%gui.findObjectByInternalName("LoadGif", true).setVisible(0);
	%gui.findObjectByInternalName("JoinServerBtn", true).setActive(1);
	%gui.findObjectByInternalName("PreviewServerBtn", true).setActive(1);
	JS_window.canClose = 1;
}

function queryMasterTCPObj::onConnectFailed(%this) {
	MessageBoxOK("Query Master Server Failed", "<just:left>Connection failed during master server query.\n\n" @ "1.  Verify your internet connection\n\n" @ "2.  Make sure any security software you have is set to allow Blockland.exe to connect to the internet.");
	
	%gui = JoinServerDlg;
	%gui.findObjectByInternalName("BackBtn", true).setActive(1);
	%gui.findObjectByInternalName("QueryLanBtn", true).setActive(1);
	%gui.findObjectByInternalName("QueryInternetBtn", true).setActive(1);
	%gui.findObjectByInternalName("LoadGif", true).setVisible(0);
	%gui.findObjectByInternalName("JoinServerBtn", true).setActive(1);
	%gui.findObjectByInternalName("PreviewServerBtn", true).setActive(1);
	JS_window.canClose = 1;
}

function queryMasterTCPObj::onConnected(%this) {
	%this.send(%this.cmd);
}

function queryMasterTCPObj::onDisconnect(%this) {
	%gui = JoinServerDlg;
	
	if (%this.site !$= "master3.blockland.us")
	{
		%this.reading  = 0;
		%this.site     = "master3.blockland.us";
		%this.port     = 80;
		%this.cmd      = "GET / HTTP/1.0\r\nHost: " @ %this.site @ "\r\nConnection: close\r\n\r\n";
		%this.schedule(1, connect, %this.site @ ":" @ %this.port);
		return;
	}
	
	%gui.findObjectByInternalName("BackBtn", true).setActive(1);
	%gui.findObjectByInternalName("QueryLanBtn", true).setActive(1);
	%gui.findObjectByInternalName("QueryInternetBtn", true).setActive(1);
	%gui.findObjectByInternalName("LoadGif", true).setVisible(0);
	%gui.findObjectByInternalName("JoinServerBtn", true).setActive(1);
	%gui.findObjectByInternalName("PreviewServerBtn", true).setActive(1);
	JS_window.canClose = 1;
	
	for (%i=0;%i<JS_Frame.getCount();%i++) {
		%o      = JS_Frame.getObject(%i);
		%pCount = (%o.version $= "All" ? %this.totalPlayers : %this.players[%o.version]);
		%sCount = %o.getObject(0).rowCount();
		%stats  = "(" @ %sCount @ " Server" @ (%sCount == 1 ? "" : "s") @ ", " @ %pCount @ " Player" @ (%pCount == 1 ? "" : "s") @ ")";
		
		%o.caption = (%o.version $= "All" ? "All" : "v" @ %o.version) SPC "Servers " @ %stats;
		%o.setCollapsed(0);
		%o.setExtent(getWord(%o.getExtent(), 0), (%o.getObject(0).profile.fontSize + 2) * (%o.getObject(0).rowCount() + 1));
		%o.setCollapsed(JS_Frame.collapsed[%o.version] $= "" ? 1 : JS_Frame.collapsed[%o.version]);
	}
	
	// Re-sort to the last sort type
	if (JS_Frame.lastSortCol !$= "")
	{
		if (JS_Frame.lastSortNum)
		{
			JS_sortNumList(JS_Frame.lastSortCol, JS_Frame.lastSortDesc);
			JS_sortNumList(JS_Frame.lastSortCol, JS_Frame.lastSortDesc);
		}
		else
		{
			JS_sortList(JS_Frame.lastSortCol, JS_Frame.lastSortDesc);
			JS_sortList(JS_Frame.lastSortCol, JS_Frame.lastSortDesc);
		}
	}
	
	ServerInfoSO_StartPingAll();
}

function queryMasterTCPObj::onLine(%this, %line) {
	if (!%this.reading) {
		switch$(firstWord(%line)) {
			case "SIMPLENOTE":
				warn("Note: " @ removeWord(%line, 0));
			case "ERROR":
				error("Error: " @ removeWord(%line, 0));
				messageBoxOk("ERROR", "This service reported an error:<br><br>\"" @ removeWord(%line, 0) @ "\"");
			case "START":
				%this.reading = 1;
		}
		
		return;
	}
	
	if (strStr(%line, "END") == 0) {
		%this.reading = 0;
		return;
	}
	
	if (%this.site $= "master3.blockland.us")
	{
		%ip          = getField(%line, 0);
		%port        = getField(%line, 1);
		%passworded  = getField(%line, 2);
		%dedicated   = getField(%line, 3);
		%serverName  = getField(%line, 4);
		%playerCount = getField(%line, 5);
		%maxPlayers  = getField(%line, 6);
		%mapName     = getField(%line, 7);
		%brickCount  = getField(%line, 8);
		%version     = "21";
		%adminName   = getField(%line, 10);
		%serverName  = %adminName @ (getSubStr(%adminName, strLen(%adminName) - 1, 1) $= "s" ? "'" : "'s") SPC %serverName;
	}
	else
	{
		%ip          = getField(%line, 0);
		%port        = getField(%line, 1);
		%passworded  = getField(%line, 2);
		%dedicated   = getField(%line, 3);
		%serverName  = getField(%line, 4);
		%playerCount = getField(%line, 5);
		%maxPlayers  = getField(%line, 6);
		%mapName     = getField(%line, 7);
		%brickCount  = getField(%line, 8);
		%version     = getField(%line, 9);
	}
	
	%str = (%passworded $= "1" ? "\c2" : (%playerCount >= %maxPlayers ? "\c3" : "")); // Passworded? Set color to this, then.
	%str = %str @ (%passworded $= "1" ? "Yes" : "No"); // Passworded?
	%str = %str TAB (%dedicated $= "1" ? "Yes" : "No"); // Dedicated?
	%str = %str TAB (%version !$= "21" ? restWords(%serverName) : %serverName); // Server name
	%str = %str TAB "???"; // Ping
	%str = %str TAB %playerCount TAB "/" TAB %maxPlayers; // Player count
	%str = %str TAB %brickCount; // Brickcount
	%str = %str TAB %mapName; // Map
	%str = %str TAB %ip; // IP
	%str = %str TAB %port; // Port
	%str = %str TAB %version; // Version
	
	%this.players[%version] += %playerCount;
	%this.totalPlayers      += %playerCount;
	
	%list = JoinServerDlg.getVersionCategoryList(%version);
	%list.addRow(%list.rowCount(), %str);
	
	// Add to the ping var
	$JoinServerDlg::Cache::Ping[$JoinServerDlg::Cache::PingCount] = %ip @ ":" @ %port NL %list.getId() TAB %list.rowCount() - 1;
	
	%list = JoinServerDlg.getVersionCategoryList("All");
	%list.addRow(%list.rowCount(), %str);
	
	// Ping this server
	$JoinServerDlg::Cache::Ping[$JoinServerDlg::Cache::PingCount] = $JoinServerDlg::Cache::Ping[$JoinServerDlg::Cache::PingCount] NL %list.getId() TAB %list.rowCount() - 1;
	$JoinServerDlg::Cache::PingCount++;
}

function ServerInfoSO_StartPingAll()
{
	echo("\r\n\c5Pinging Servers...");
	if ($Pref::Net::MaxPings <= 0)
		$Pref::Net::MaxPings = 10;
	
	$JoinServerDlg::Cache::PingIndex = 0;
	
	// Ping the servers
	for (%i = 0; %i < $Pref::Net::MaxPings; %i++)
	{
		if (%i >= $JoinServerDlg::Cache::PingCount)
			break;
		
		%data = $JoinServerDlg::Cache::Ping[%i];
		%addr = getRecord(%data, 0);
		
		$JoinServerDlg::Cache::PingSLOT[%i] = %data;
		schedule(10 * (%i + 1), 0, pingSingleServer, %addr, %i);
		$JoinServerDlg::Cache::PingIndex++;
	}
}

function ServerInfoSO_PingNext(%slot)
{
	if (!$MasterQueryCanceled)
	{
		if ($JoinServerDlg::Cache::PingIndex >= $JoinServerDlg::Cache::PingCount)
			return;
		
		%ip = getRecord(%data = $JoinServerDlg::Cache::Ping[$JoinServerDlg::Cache::PingIndex], 0);
		$JoinServerDlg::Cache::PingSLOT[%slot] = %data;
		pingSingleServer(%ip, %slot);
		$JoinServerDlg::Cache::PingIndex++;
	}
}

function onSimplePingReceived(%ip, %ping, %slot)
{
	%rData = $JoinServerDlg::Cache::PingSLOT[%slot];
	
	// Update all lists
	for (%i = 1; %i < getRecordCount(%rData); %i++)
	{
		%data  = getRecord(%rData, %i);
		%list  = getField(%data, 0);
		%rowId = getField(%data, 1);
		
		%list.setRowById(%rowId, setField(%list.getRowTextById(%rowId), 3, %ping));
	}
	
	ServerInfoSO_PingNext(%slot);
}

function onSimplePingTimeout(%ip, %slot)
{
	%rData = $JoinServerDlg::Cache::PingSLOT[%slot];

	// Update all lists
	for (%i = 1; %i < getRecordCount(%rData); %i++)
	{
		%data  = getRecord(%rData, %i);
		%list  = getField(%data, 0);
		%rowId = getField(%data, 1);
		
		%list.setRowById(%rowId, setField(%list.getRowTextById(%rowId), 3, "---"));
	}
	
	ServerInfoSO_PingNext(%slot);
}