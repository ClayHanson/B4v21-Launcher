function getBlocklandName(%ver) {
	if(%ver $= "RTB") return "Return To Blockland";
	if(%ver $= "20s") return "Blockland v20 Steam Edition";
	
	return "Blockland v" @ %ver;
}

function getFancyByteString(%num) {
	%suffix = "B";
	
	if(%num >= 1024) {
		%num /= 1024;
		%suffix = "KB";
	}
	if(%num >= 1024) {
		%num /= 1024;
		%suffix = "MB";
	}
	if(%num >= 1024) {
		%num /= 1024;
		%suffix = "GB";
	}
	
	return mFloatLength(%num, 2) SPC %suffix;
}

function fetchScreenshots() {
	%count = 0;
	
	launcherGui.clearSlides();
	
	for(%i=0;%i<$Launcher::Versions::Count;%i++) {
		%path = $Launcher::Versions::Ver[%ver = firstWord($Launcher::Versions::Table[%i])];
		%inst = $Launcher::Versions::Installed[%ver];
		
		if(%inst != 2) continue;
		
		for(%file=getFirstDirectoryFile(%path @ "screenshots\\");%file !$= "";%file = getNextDirectoryFile()) {
			%count++;
			launcherGui.addSlide(strReplace(%file, "\\", "/"));
		}
	}
	
	if(%count == 0) {
		// Failsafe
		launcherGui.addSlide("./launcher/ui/DefaultBackground.jpg");
	}
}

function fetchVersionListing() {
	versionManagerGui.findObjectByInternalName("RefreshBtn", true).setActive(0);
	versionManagerGui.findObjectByInternalName("VersionList", true).clear();
	deleteVariables("$Launcher::Versions::*");
	
	$Launcher::VersMgr::Selected = "";
	versionManagerGui.updateVersionInformation();
	
	// Get local installations first
	if(isFile(%verFile = ("launcher/verInfo.cfg"))) {
		%SO = new FileObject();
		%SO.openForRead(%verFile);
		
		while(!%SO.isEOF()) {
			%line    = %SO.readLine();
			%version = getField(%line, 0);
			%verPath = getField(%line, 1);
			
			// Sanity check
			if(getSubStr(%verPath, strLen(%verPath) - 1, 1) !$= "/" && getSubStr(%verPath, strLen(%verPath) - 1, 1) !$= "\\") {
				warn("Please don't mess with the verInfo.cfg file directly...");
				%verPath = %verPath @ "\\";
			}
			
			if(!isFile(%verPath @ "Blockland.exe")) {
				error(getBlocklandName(%version) SPC "does not have a Blockland.exe -- probably deleted");
				continue;
			}
			
			$Launcher::Versions::Table[-1 + $Launcher::Versions::Count++] = %version SPC %verPath;
			$Launcher::Versions::Ver[%version]			      = %verPath;
			$Launcher::Versions::Installed[%version]                      = (isFile(%verPath @ "archive.zip") && isZipValid(%verPath @ "archive.zip") && !isFile(%verPath @ "Blockland.exe") ? 1 : 2);
			
			versionManagerGui.findObjectByInternalName("VersionList", true).addRow($Launcher::Versions::Count - 1, getBlocklandName(%version) SPC "(installed)" TAB %version);
		}
		
		%SO.close();
		%SO.delete();
		
		fetchScreenshots();
	} else {
		launcherGui.addSlide("./launcher/ui/DefaultBackground.jpg");
	}
	
	// Now get a list from the B4v21 website
	if(isObject(%o = VersionsFetcherTCP)) %o.delete();
	%o = new TCPObject(VersionsFetcherTCP);
	
	%o.site     = "b4v21.block.land";
	%o.port     = 80;
	%o.cmd      = "GET /api/newLauncher.php HTTP/1.1\r\nHost: " @ %o.site @ "\r\nConnection: close\r\n\r\n";
	%o.connect(%o.site @ ":" @ %o.port);
}

function VersionsFetcherTCP::onDisconnect(%this) {
	versionManagerGui.findObjectByInternalName("RefreshBtn", true).setActive(1);
}

function VersionsFetcherTCP::onConnected(%this) {
	%this.send(%this.cmd);
}

function VersionsFetcherTCP::onLine(%this, %line) {
	%act  = firstWord(%line);
	%line = restWords(%line);
	
	switch$(%act) {
		case "VER":
			%ver = getField(%line, 0);
			
			if($Launcher::Versions::Ver[%ver] $= "") {
				$Launcher::Versions::Table[-1 + $Launcher::Versions::Count++] = %ver SPC removeField(%line, 0);
				$Launcher::Versions::Ver[%ver] 				      = removeField(%line, 0);
				$Launcher::Versions::Installed[%ver]			      = 0;
				
				versionManagerGui.findObjectByInternalName("VersionList", true).addRow($Launcher::Versions::Count - 1, getBlocklandName(%ver) TAB %ver);
			}
		case "LAUNCHER_VERSION":
			if($Launcher::Version !$= %line) {
				error("New version of B4v21 Launcher is available!");
				messageBoxOk("UPDATE - B4v21 Launcher", "There is a new version of B4v21 Launcher!\nGo download it at http://b4v21.block.land/\n\nTo make sure everyone stays up-to-date, you will not be able to use the updater until you update it.", "quit();");
			}
	}
}

function versionManagerGui::onWake(%this) {
	%window = %this.getObject(0);
	%window.setPosition((getWord(getRes(), 0) / 2) - (getWord(%window.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%window.getExtent(), 1) / 2));
	
	$Launcher::VersMgr::Selected = "";
	%this.updateVersionInformation();
	%this.findObjectByInternalName("TabBook", true).selectPage(0);
}

function versionManagerGui::updateVersionInformation(%this) {
	%sel = $Launcher::VersMgr::Selected;
	
	if(%sel $= "" || %sel < 0 || %sel >= $Launcher::Versions::Count) {
		%this.findObjectByInternalName("InfoHeader", true).setText("<font:Impact:32>Select something!<font:Impact:18><br>");
		%this.findObjectByInternalName("LaunchBtn", true).setActive(0);
		%this.findObjectByInternalName("LaunchDediBtn", true).setActive(0);
		%this.findObjectByInternalName("GameInstallBtn", true).setActive(0);
		%this.findObjectByInternalName("GameInstallBtn", true).setText("Install");
		%this.findObjectByInternalName("TabBook", true).selectPage(0);
		%this.findObjectByInternalName("InfoText", true).setText("<font:Arial:16>N/A<br>N/A");
		return;
	}
	
	%cVer      = firstWord(%data = $Launcher::Versions::Table[%sel]);
	%cPath     = restWords(%data);
	%installed = $Launcher::Versions::Installed[%cVer];
	
	%this.findObjectByInternalName("InfoHeader", true).setText("<font:Impact:32>" @ getBlocklandName(%cVer) @ "<font:Impact:18><br>(" @ ($Launcher::VersionInstalling $= %cVer ? "Installing..." : (%installed ? "Installed" : "Not Installed")) @ ")");
	%this.findObjectByInternalName("LaunchBtn", true).setActive(%installed == 2);
	%this.findObjectByInternalName("LaunchDediBtn", true).setActive(%installed == 2);
	%this.findObjectByInternalName("GameInstallBtn", true).setText((%installed == 2 ? "De-associate" : (%installed == 1 ? "Extract" : "Install")));
	%this.findObjectByInternalName("GameInstallBtn", true).setActive(true);
	
	%infoTxt = "<font:Arial:16>";
	%infoTxt = %infoTxt @  (%installed ? (%installed == 1 ? "<color:aaaa00>Needs to be extracted<color:000000>" : %cPath) : ($Launcher::VersionInstalled $= %cVer ? "<color:aaaa00>Installing...<color:000000>" : "<color:aa0000>Not Installed<color:000000>"));
	%infoTxt = %infoTxt NL "0";
	
	%this.findObjectByInternalName("InfoText", true).setText(%infoTxt);
		
	if($Launcher::VersionInstalling !$= "") {
		%this.findObjectByInternalName("GameInstallBtn", true).setActive(0);
		%this.findObjectByInternalName("RefreshBtn", true).setText("Stop Download");
	} else {
		%this.findObjectByInternalName("GameInstallBtn", true).setValue(%installed ? "Un-install" : "Install");
		%this.findObjectByInternalName("RefreshBtn", true).setText("Refresh");
	}
}

function VerList::onSelect(%this, %rowID, %rowText) {
	if($Launcher::Versions::Table[%rowID] $= "") {
		messageBoxOk("WHAT DO YOU THINK YOU ARE DOING - B4v21 Launcher", ":heyareyoucrashingtbeserver:");
		return;
	}
	
	$Launcher::VersMgr::Selected = %rowID;
	versionManagerGui.updateVersionInformation();
	
	versionManagerGui.findObjectByInternalName("TabBook", true).selectPage(0);
}

function VersMgr_GameInstallBtnPressed(%cfrm) {
	%btn = versionManagerGui.findObjectByInternalName("GameInstallBtn", true);
	
	%cVer      = firstWord($Launcher::Versions::Table[$Launcher::VersMgr::Selected]);
	%cPath     = restWords($Launcher::Versions::Table[$Launcher::VersMgr::Selected]);
	%installed = $Launcher::Versions::Installed[%cVer];
	
	if(%cVer $= getWord(%s = "RTB 20 ", $Launcher::Secret::Pos) && $Launcher::Secret::Pos < getWordCount(%s)) {
		if($Launcher::Secret::Pos++ >= getWordCount(%s)) {
			messageBoxOK("HANSONBOT - B4v21 Launcher", "what are you doing there, friend");
		}
	}
	
	if(%installed == 1) {
		if(!%cfrm) {
			messageBoxYesNo("CONFIRM - B4v21 Launcher", "Are you sure you want to extract " @ getBlocklandName(%cVer) @ "?", "VersMgr_GameInstallBtnPressed(true);");
			return;
		}
		
		extractVersion(%cVer, $Launcher::VersMgr::Selected);
	} else if(%installed == 2) {
		if(!%cfrm) {
			messageBoxYesNo("CONFIRM - B4v21 Launcher", "Are you sure you want to de-associate " @ getBlocklandName(%cVer) @ "?<br>This only removes this option from the launcher; It does not actually delete the installation.", "VersMgr_GameInstallBtnPressed(true);");
			return;
		}
		
		$Launcher::Versions::Installed[%cVer] = false;
		UpdateInstallationsFile();
		fetchVersionListing();
	} else {
		%installPath = $pref::Launcher::Location @ getBlocklandName(%cVer) @ "\\";
		if(!%cfrm) {
			messageBoxYesNo("CONFIRM - B4v21 Launcher", "Are you sure you want to install " @ getBlocklandName(%cVer) @ "?\nIt will be installed in \"" @ %installPath @ "\".", "VersMgr_GameInstallBtnPressed(true);");
			return;
		}
		
		$Launcher::Installer::AvgTransferRate = 0;
		$Launcher::VersionInstalling    = %cVer;
		$Launcher::VersionInstallingIdx = $Launcher::VersMgr::Selected;
		
		if(isFile(%installPath @ "archive.zip") && isZipValid(%installPath @ "archive.zip") && %cfrm != 2) {
			messageBoxYesNo("SKIP DOWNLOAD? - B4v21 Launcher", "B4v21 Launcher detected an already-downloaded archive in the install directory. Do you want to skip the download and just extract this instead?", "onVersionDownloadDone(\"" @ %installPath @ "\\archive.zip\");", "VersMgr_GameInstallBtnPressed(2);");
			return;
		}
		
		createPath(strReplace(%installPath, "\\", "/"));
		$Launcher::Versions::Installed[%cVer] = 1;
		
		// Download archive
		%host = getField(%cPath, 0);
		%port = getField(%cPath, 1);
		%path = getField(%cPath, 2);
		
		// Download
		$Launcher::VersionInstalling::LastDLId = tcpDownload(strReplace(%installPath, "\\", "/") @ "archive.zip", %host, %path, %port, "onVersionDownloadDone", "onVersionDownloadProgress", "onVersionDownloadStart");
		if($Launcher::VersionInstalling::LastDLId == -1) {
			messageBoxOk("ERROR - B4v21 Launcher", "Failed to download " @ getBlocklandName(%cVer) @ "<br>(tcpDownload failed)");
			$Launcher::VersionInstalling = "";
		}
		
		versionManagerGui.updateVersionInformation();
	}
}

function extractVersion_Progress(%curr, %max) {
	versionManagerGui.findObjectByInternalName("ProgressBar", true).setValue(%curr / %max);
	versionManagerGui.findObjectByInternalName("ProgressBar", true).getObject(0).setText("<font:Consolas:18><just:center>Extracting " @ %curr @ " / " @ %max @ " (" @ mFloor((%curr / %max) * 100) @ "%)");
}

function extractVersion(%cVer, %cIdx) {
	if($Launcher::Versions::Ver[%cVer] $= "") return;
	
	versionManagerGui.findObjectByInternalName("ProgressBar", true).getObject(0).setText("<font:Consolas:18><just:center>Extracting...");
	Canvas.repaint();
	
	%installPath = $pref::Launcher::Location @ getBlocklandName(%cVer) @ "\\";
	if(exportZip(strReplace(%installPath @ "archive.zip", "\\", "/"), strReplace(%installPath, "\\", "/"), true, true, "extractVersion_Progress")) {
		$Launcher::Versions::Table[%cIdx]     = %cVer SPC %installPath;
		$Launcher::Versions::Ver[%cVer]       = %installPath;
		$Launcher::Versions::Installed[%cVer] = 2;
		
		UpdateInstallationsFile();
		fetchVersionListing();
		error("mate");
	} else {
		messageBoxOK("FAIL - B4v21 Launcher", "The zip archive \"" @ %installPath @ "archive.zip\" is missing or corrupted.");
	}
	
	versionManagerGui.findObjectByInternalName("ProgressBar", true).getObject(0).setText("<font:Consolas:18><just:center>Ready");
}

function onVersionDownloadDone(%fileName) {
	versionManagerGui.findObjectByInternalName("ProgressBar", true).setValue(0);
	versionManagerGui.findObjectByInternalName("ProgressBar", true).getObject(0).setText("<font:Consolas:18><just:center>Ready");
	versionManagerGui.findObjectByInternalName("RefreshBtn", true).setActive(1);
	
	%cVer = $Launcher::VersionInstalling;
	%cIdx = $Launcher::VersionInstallingIdx;
	
	$Launcher::VersionInstallingCurr = 0;
	$Launcher::VersionInstalling     = "";
	$Launcher::VersionInstallingIdx  = "";
	
	deleteVariables("$Launcher::Installer::Avg*");
	schedule(1, 0, extractVersion, %cVer, %cIdx);
}

function onVersionDownloadProgress(%curr, %max) {
	%cVer = $Launcher::VersionInstalling;
	%cIdx = $Launcher::VersionInstallingIdx;
	
	if(getSimTime() - $Launcher::Installer::LastAvgTime >= 1000) {
		$Launcher::Installer::LastAvgTime = getSimTime();
		
		for(%i=0;%i<$Launcher::Installer::AvgSize;%i++) %sum += $Launcher::Installer::Avg[%i];
		%sum /= $Launcher::Installer::AvgSize;
		
		deleteVariables("$Launcher::Installer::Avg*");
		$Launcher::Installer::AvgTransferRate = %sum;
	}
	
	$Launcher::Installer::Avg[-1 + $Launcher::Installer::AvgSize++] = %curr - $Launcher::VersionInstallingCurr;
	$Launcher::VersionInstallingCurr = %curr;
	
	%pText = "<font:Consolas:18><just:center>";
	%pText = %pText @ (%curr >= %max ? getFancyByteString(%curr) : getFancyByteString(%curr) @ " / " @ getFancyByteString(%max));
	%pText = %pText SPC "@ " @ getFancyByteString($Launcher::Installer::AvgTransferRate) @ "/s";
	
	versionManagerGui.findObjectByInternalName("ProgressBar", true).setValue((%curr >= %max ? -1 : %curr /  %max));
	versionManagerGui.findObjectByInternalName("ProgressBar", true).getObject(0).setText(%pText);
	
	// Update row
	if(%curr >= %max)
		versionManagerGui.findObjectByInternalName("VersionList", true).setRowById(%cIdx, getBlocklandName(%cVer));
	else
		versionManagerGui.findObjectByInternalName("VersionList", true).setRowById(%cIdx, getBlocklandName(%cVer) SPC "(" @ mFloor((%curr / %max) * 100) @ "%)");
}

function UpdateInstallationsFile() {
	%verFile = "launcher/verInfo.cfg";
	
	%SO = new FileObject();
	%SO.openForWrite(%verFile);
	
	for(%i=0;%i<$Launcher::Versions::Count;%i++) {
		%data = $Launcher::Versions::Table[%i];
		%ver  = firstWord(%data);
		%path = $Launcher::Versions::Ver[%ver];
		%dwnl = $Launcher::Versions::Installed[%ver];
		
		if(!%dwnl) continue;
		
		%SO.writeLine(%ver TAB %path);
	}
	
	%SO.close();
	%SO.delete();
	
	fetchVersionListing();
}

function VMG_AddGui::onWake(%this) {
	%list = %this.findObjectByInternalName("VersionList", true);
	
	// Populate versions list
	%list.clear();
	for(%i=0;%i<$Launcher::Versions::Count;%i++) {
		%data = $Launcher::Versions::Table[%i];
		%ver  = firstWord(%data);
		%path = restWords(%data);
		%dwnl = $Launcher::Versions::Installed[%ver];
		
		// Don't want to add already existing installations!
		if(%dwnl == 1) continue;
		
		%list.ver[%i] = %ver;
		%list.add(getBlocklandName(%ver), %i);
	}
	%list.setSelected(0);
	
	// Clean path box
	%this.findObjectByInternalName("PathDlgBox", true).setValue(getMyDocumentsPath() @ "\\B4v21\\");
	
	// Center window
	%w = %this.getObject(0);
	%w.setPosition((getWord(getRes(), 0) / 2) - (getWord(%w.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%w.getExtent(), 1) / 2));
}

function VMG_AddGui_AddVersion() {
	%list = VMG_AddGui.findObjectByInternalName("VersionList", true);
	%path = VMG_AddGui.findObjectByInternalName("PathDlgBox", true).getValue();
	%vers = %list.ver[%list.getSelected()];
	
	%path = strReplace(%path, "/", "\\");
	if(getSubStr(%path, strLen(%path) - 1, 1) !$= "\\") %path = %path @ "\\";
	
	if(!isFile(%path @ "Blockland.exe")) {
		messageBoxOk("ERROR - B4v21 Launcher", "This is not a valid Blockland installation.");
		return;
	}
	
	$Launcher::Versions::Ver[%vers]       = %path;
	$Launcher::Versions::Installed[%vers] = true;
	UpdateInstallationsFile();
	
	Canvas.popDialog(VMG_AddGui);
}

function VersMgr_LaunchBtnPressed(%dedi) {
	%cVer      = firstWord($Launcher::Versions::Table[$Launcher::VersMgr::Selected]);
	%cPath     = restWords($Launcher::Versions::Table[$Launcher::VersMgr::Selected]);
	%installed = $Launcher::Versions::Installed[%cVer];
	
	if(!%installed) return;
	if(!isFile(%cPath @ "Blockland.exe")) return;
	
	launchExe(%cPath @ "Blockland.exe", "ptlaaxobimwroe" @ (%dedi ? " -dedicated" : ""));
}

function VersMgr_RefreshBtnPressed(%cfrm) {
	if($Launcher::VersionInstalling !$= "") {
		if(!%cfrm) {
			messageBoxYesNo("STOP DOWNLOAD? - B4v21 Launcher", "Are you sure you want to stop downloading " @ getBlocklandName($Launcher::VersionInstalling) @ "?", "VersMgr_RefreshBtnPressed(1);");
			return;
		}
		
		versionManagerGui.findObjectByInternalName("ProgressBar", true).setValue(0);
		versionManagerGui.findObjectByInternalName("ProgressBar", true).getObject(0).setText("<font:Consolas:18><just:center>Ready");
		versionManagerGui.findObjectByInternalName("RefreshBtn", true).setActive(1);
		versionManagerGui.findObjectByInternalName("VersionList", true).setRowById($Launcher::VersionInstallingIdx, getBlocklandName($Launcher::VersionInstalling));
		
		$Launcher::VersionInstallingCurr = 0;
		$Launcher::VersionInstalling     = "";
		$Launcher::VersionInstallingIdx  = "";
		
		deleteVariables("$Launcher::Installer::Avg*");
		
		tcpCancelDownload($Launcher::VersionInstalling::LastDLId);
		versionManagerGui.updateVersionInformation();
	} else fetchVersionListing();
}