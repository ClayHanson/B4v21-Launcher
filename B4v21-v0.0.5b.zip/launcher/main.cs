// B4v21 Launcher

enableWinConsole(true);

// Audio
$GuiAudioType     = 1;
$SimAudioType     = 2;
$MessageAudioType = 3;

new AudioDescription(AudioGui) {
   volume   = 1.0;
   isLooping= false;
   is3D     = false;
   type     = $GuiAudioType;
};

new AudioDescription(AudioMessage) {
   volume   = 1.0;
   isLooping= false;
   is3D     = false;
   type     = $MessageAudioType;
};

// Cursors
new GuiCursor(DefaultCursor) {
	hotSpot = "1 1";
	renderOffset = "0 0";
	bitmapName = "launcher/ui/CUR_3darrow.png";
};

// Variables
$Launcher::Version = "0.0.5b";
$pref::Launcher::Location = getMyDocumentsPath() @ "\\B4v21\\";

$pref::Player::Name       = "BlockHead";
$pref::Player::defaultFov = 90;
$pref::Player::zoomSpeed  = 0;

$pref::Net::LagThreshold = 400;

$pref::shadows           = "2";
$pref::HudMessageLogSize = 40;
$pref::ChatHudLength     = 1;

$pref::Input::LinkMouseSensitivity = 1;
$pref::Input::KeyboardEnabled      = 1;
$pref::Input::MouseEnabled         = 1;
$pref::Input::JoystickEnabled      = 0;
$pref::Input::KeyboardTurnSpeed    = 0.1;

$pref::sceneLighting::cacheSize            = 20000;
$pref::sceneLighting::purgeMethod          = "lastCreated";
$pref::sceneLighting::cacheLighting        = 1;
$pref::sceneLighting::terrainGenerateLevel = 1;

$pref::Terrain::DynamicLights = 1;
$pref::Interior::TexturedFog  = 0;

$pref::Video::displayDevice       = "OpenGL";
$pref::Video::allowOpenGL         = 1;
$pref::Video::allowD3D            = 1;
$pref::Video::preferOpenGL        = 1;
$pref::Video::appliedPref         = 0;
$pref::Video::disableVerticalSync = 1;
$pref::Video::monitorNum          = 0;
$pref::Video::windowedRes         = "1280 720";
$pref::Video::screenShotFormat    = "PNG";

$pref::OpenGL::force16BitTexture    = "0";
$pref::OpenGL::forcePalettedTexture = "0";
$pref::OpenGL::maxHardwareLights    = 3;
$pref::VisibleDistanceMod           = 1;

$pref::Audio::driver                 = "OpenAL";
$pref::Audio::forceMaxDistanceUpdate = 0;
$pref::Audio::environmentEnabled     = 0;
$pref::Audio::masterVolume           = 0.8;
$pref::Audio::channelVolume1         = 0.8;
$pref::Audio::channelVolume2         = 0.8;
$pref::Audio::channelVolume3         = 0.8;
$pref::Audio::channelVolume4         = 0.8;
$pref::Audio::channelVolume5         = 0.8;
$pref::Audio::channelVolume6         = 0.8;
$pref::Audio::channelVolume7         = 0.8;
$pref::Audio::channelVolume8         = 0.8;

//-----------------------------------------------------------------------------
// Package overrides to initialize the game
function onStart() {
	// Initialize the client and the server
	initClient();
}

function onExit() {
	// Save off our current preferences for next time
}

//-----------------------------------------------------------------------------

function initClient() {
	echo("\n--------- Initializing B4v21 Launcher ---------");
	
	// Init canvas
	videoSetGammaCorrection($pref::OpenGL::gammaCorrection);
	
	%canvasCreate = createCanvas("B4v21 Launcher");
	setOpenGLTextureCompressionHint($pref::OpenGL::compressionHint);
	setOpenGLAnisotropy($pref::OpenGL::textureAnisotropy);
	setOpenGLMipReduction($pref::OpenGL::mipReduction);
	setOpenGLInteriorMipReduction($pref::OpenGL::interiorMipReduction);
	setOpenGLSkyMipReduction($pref::OpenGL::skyMipReduction);
	
	// Init audio
	OpenALShutdownDriver();
	OpenALInitDriver();
	
	alxListenerf(AL_GAIN_LINEAR, 1);
	for(%channel=1; %channel <= 8; %channel++) alxSetChannelVolume(%channel, 1);
	
	// Load scripts
	exec("./profiles.cs");
	exec("./launcherGui.gui");
	exec("./manualJoin.gui");
	exec("./versionManagerGui.gui");
	exec("./joinServerDlg.gui");
	exec("./joinServerDlg.cs");
	exec("./message.cs");
	exec("./versionMgr.cs");
	exec("./VMG_AddGui.gui");
	
	// Copy saved script prefs into C++ code.
	setShadowDetailLevel($pref::shadows);
	setDefaultFov($pref::Player::defaultFov);
	setZoomSpeed($pref::Player::zoomSpeed);
	
	// Start up the main menu...
	Canvas.setContent(launcherGui);
	Canvas.setCursor(DefaultCursor);
	
	LauncherVersionText.setText("Version: " @ $Launcher::Version);
	
	// Load versions
	fetchVersionListing();
}