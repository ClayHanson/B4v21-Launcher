function optionsDlg::onWake(%this) {
	%window = %this.getObject(0);
	%window.setPosition((getWord(getRes(), 0) / 2) - (getWord(%window.getExtent(), 0) / 2), (getWord(getRes(), 1) / 2) - (getWord(%window.getExtent(), 1) / 2));
	
	$Desired::NetUsageOption = $Pref::Net::DesiredExperience;
	%this.findObjectByInternalName("BWidth_" @ $Desired::NetUsageOption, true).performClick();
	
	(%rL = %this.findObjectByInternalName("ResList", true)).clear();
	
	%list = getResolutionList("OpenGL");
	for(%i=0;%i<getWordCount(%list);%i += 3) {
		%res = getWord(%list, %i) SPC getWord(%list, %i + 1);
		
		if(%res $= getWords(getRes(), 0, 1)) %sel = %i / 3;
		if(getWord(%res, 0) < 800 || getWord(%res, 1) < 600) continue;
		
		%rL.add(getWord(%list, %i) @ "x" @ getWord(%list, %i + 1), %i / 3);
	}
	
	%rL.setSelected(%sel);
	%this.findObjectByInternalName("PlayMMBtnSounds", true).setValue($Pref::Audio::MainMenuButtons);
	%this.findObjectByInternalName("TabBook", true).selectPage(0);
}

function optionsDlg::apply(%this) {
	// Set new resolution
	%newRes = strReplace(%this.findObjectByInternalName("ResList", true).getTextById(%this.findObjectByInternalName("ResList", true).getSelected()), "x", " ");
	if(%newRes !$= getWords(getRes(), 0, 1)) setRes(getWord(%newRes, 0), getWord(%newRes, 1));
	
	// Apply audio settings
	$Pref::Audio::MainMenuButtons              = %this.findObjectByInternalName("PlayMMBtnSounds", true).getValue();
	BlockMainMenuButtonProfile.soundButtonOver = ($Pref::Audio::MainMenuButtons ? "mmButtonHoverSound" : "");
	
	if(stripChars(getSubStr($pref::Launcher::Location, strLen($pref::Launcher::Location) - 1, 1), "/\\") !$= "") $pref::Launcher::Location = $pref::Launcher::Location @ "\\";
	if(getDirectoryFileCount($pref::Launcher::Location) == 0) createPath($pref::Launcher::Location);
	
	$Pref::Net::DesiredExperience = $Desired::NetUsageOption;
	
	// Save prefs
	export("$pref::*", "launcher/prefs.cs");
	
	// Apply the experience
	ApplyNetExperience();
	
	// We're done!
	Canvas.popDialog(optionsDlg);
}